<?php
/**
 * Open a notification
 *
 * Marks the notification as read and sends the user to the page it
 * refers to (when there is one).
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireLogin();

$notificationId = (int) ($_GET['id'] ?? 0);

$notification = Database::fetch(
    'SELECT * FROM notifications WHERE id = :id AND user_id = :user_id',
    ['id' => $notificationId, 'user_id' => $_SESSION['user_id']]
);

if (!$notification) {
    setFlash('error', 'Notification not found.');
    redirect('src/notifications/index.php');
}

Database::execute(
    'UPDATE notifications SET is_read = 1 WHERE id = :id',
    ['id' => $notificationId]
);

$link = (string) ($notification['link'] ?? '');

if ($link !== '' && (strpos($link, SORMS_URL) === 0 || preg_match('#^https?://#i', $link))) {
    header('Location: ' . $link);
    exit;
}

redirect('src/notifications/index.php');
