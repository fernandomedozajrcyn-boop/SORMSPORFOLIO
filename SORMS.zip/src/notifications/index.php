<?php
/**
 * Notifications Page
 *
 * Lists the notifications of the signed in user.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_all_read') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Your session expired. Please try again.');
    } else {
        Database::execute(
            'UPDATE notifications SET is_read = 1 WHERE user_id = :user_id AND is_read = 0',
            ['user_id' => $_SESSION['user_id']]
        );
        setFlash('success', 'All notifications marked as read.');
    }

    redirect('src/notifications/index.php');
}

$notifications = Database::query(
    'SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 100',
    ['user_id' => $_SESSION['user_id']]
);

$unreadCount = getUnreadNotificationCount();

$page_title = 'Notifications';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Notifications</h1>
        <p class="description">Updates about campaigns and applications</p>
    </div>
    <?php if ($unreadCount > 0): ?>
    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="action" value="mark_all_read">
        <button type="submit" class="btn btn-outline-primary">Mark All as Read</button>
    </form>
    <?php endif; ?>
</div>

<?php if (empty($notifications)): ?>
    <div class="empty-state">
        <h4>No notifications yet</h4>
        <p>Updates about your campaigns and applications will appear here.</p>
    </div>
<?php else: ?>
    <div class="notification-list">
        <?php foreach ($notifications as $notification): ?>
        <div class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>">
            <div class="notification-body">
                <div class="d-flex justify-content-between align-items-start gap-3">
                    <h4 class="h6 mb-1"><?php echo htmlspecialchars($notification['title']); ?></h4>
                    <small class="text-muted text-nowrap"><?php echo formatDateTime($notification['created_at']); ?></small>
                </div>
                <p class="mb-2"><?php echo nl2br(htmlspecialchars($notification['message'] ?? '')); ?></p>
                <?php if (!empty($notification['link'])): ?>
                    <a href="read.php?id=<?php echo (int) $notification['id']; ?>" class="btn btn-sm btn-outline-primary">
                        Open
                    </a>
                <?php elseif (!$notification['is_read']): ?>
                    <a href="read.php?id=<?php echo (int) $notification['id']; ?>" class="btn btn-sm btn-outline-secondary">
                        Mark as Read
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
