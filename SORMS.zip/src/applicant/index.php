<?php
/**
 * My Applications Page (for students)
 *
 * Allows students to view all their applications and manage their application status.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['student', 'admin']);
requireLogin();

// Get current user's applicant profile
$applicant = Database::fetch('SELECT * FROM applicants WHERE user_id = :user_id', ['user_id' => $_SESSION['user_id']]);

if (!$applicant) {
    setFlash('error', 'You have not completed your applicant profile yet.');
    redirect('profile.php');
}

// Withdraw an application (students can only withdraw their own applications)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'withdraw') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Your session expired. Please try again.');
    } else {
        $applicationId = (int) ($_POST['application_id'] ?? 0);

        $application = Database::fetch(
            'SELECT * FROM applications WHERE id = :id AND applicant_id = :applicant_id',
            ['id' => $applicationId, 'applicant_id' => $applicant['id']]
        );

        if (!$application) {
            setFlash('error', 'Application not found.');
        } elseif (!in_array($application['status'], ['applied', 'reviewing', 'shortlisted'], true)) {
            setFlash('error', 'This application can no longer be withdrawn.');
        } else {
            Database::execute(
                "UPDATE applications SET status = 'withdrawn', reviewed_at = NOW() WHERE id = :id",
                ['id' => $applicationId]
            );

            Database::execute(
                "INSERT INTO application_history (application_id, changed_by, old_status, new_status, note)
                 VALUES (:application_id, :changed_by, :old_status, 'withdrawn', :note)",
                [
                    ':application_id' => $applicationId,
                    ':changed_by' => $_SESSION['user_id'],
                    ':old_status' => $application['status'],
                    ':note' => 'Application withdrawn by the applicant.',
                ]
            );

            setFlash('success', 'Your application has been withdrawn.');
        }
    }

    redirect('src/applicant/index.php');
}

// Get all applications for this applicant (across all campaigns)
$applications = Database::query(
    "SELECT a.*, c.title as campaign_title, c.slug as campaign_slug, o.name as organization_name
     FROM applications a
     JOIN campaigns c ON a.campaign_id = c.id
     JOIN organizations o ON c.organization_id = o.id
     WHERE a.applicant_id = :applicant_id
     ORDER BY a.applied_at DESC",
    ['applicant_id' => $applicant['id']]
);

$page_title = 'My Applications';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>My Applications</h1>
        <p class="description">View and manage your applications to student organizations</p>
    </div>
</div>

<?php if (empty($applications)): ?>
    <div class="empty-state">
        <div class="icon">📝</div>
        <h4>No applications yet</h4>
        <p>When you see a campaign you like, apply to it and it will appear here.</p>
        <a href="<?php echo SORMS_URL; ?>src/campaign/index.php" class="btn btn-primary">Browse Campaigns</a>
    </div>
<?php else: ?>
    <div class="table-wrapper">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Campaign</th>
                    <th>Organization</th>
                    <th>Applied</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $index => $app): ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td>
                        <a href="../campaign/view.php?id=<?php echo $app['campaign_id']; ?>" class="text-decoration-none fw-semibold">
                            <?php echo htmlspecialchars($app['campaign_title']); ?>
                        </a>
                    </td>
                    <td><?php echo htmlspecialchars($app['organization_name']); ?></td>
                    <td><?php echo formatDateTime($app['applied_at']); ?></td>
                    <td>
                        <span class="badge bg-<?php echo applicationStatusColor($app['status']); ?>">
                            <?php echo applicationStatusLabel($app['status']); ?>
                        </span>
                    </td>
                    <td>
                        <div class="btn-group">
                            <?php if (in_array($app['status'], ['applied', 'reviewing', 'shortlisted'], true)): ?>
                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Withdraw this application?');">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                <input type="hidden" name="action" value="withdraw">
                                <input type="hidden" name="application_id" value="<?php echo (int) $app['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-warning">Withdraw</button>
                            </form>
                            <?php endif; ?>
                            <a href="../campaign/view.php?id=<?php echo $app['campaign_id']; ?>" class="btn btn-sm btn-outline-info">View Campaign</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
