<?php
/**
 * Applicant Profile Page
 *
 * Allows students to view and edit their profile information.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['student', 'admin']);
requireLogin();

$user_id = $_SESSION['user_id'];

// Get user info
$user = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $user_id]);

// Get or create applicant profile
$applicant = Database::fetch('SELECT * FROM applicants WHERE user_id = :user_id', ['user_id' => $user_id]);

$full_name = $user['full_name'] ?? '';
$email = $user['email'] ?? '';
$phone = $user['phone'] ?? '';
$gender = $applicant['gender'] ?? '';
$date_of_birth = $applicant['date_of_birth'] ?? '';
$address = $applicant['address'] ?? '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $address = sanitize($_POST['address'] ?? '');

    $errors = [];

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    if (!validateString($full_name, 2, 100)) {
        $errors[] = 'Full name is required and must be between 2 and 100 characters.';
    }

    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!validateEmail($email)) {
        $errors[] = 'Please enter a valid email address.';
    } elseif (tableHasRows('users', ['email' => $email])) {
        $other = Database::fetch('SELECT id FROM users WHERE email = :email AND id != :id', ['email' => $email, 'id' => $user_id]);
        if ($other) {
            $errors[] = 'This email address is already used by another account.';
        }
    }

    if (!empty($phone) && !validatePhone($phone)) {
        $errors[] = 'Please enter a valid phone number.';
    }

    if (!empty($date_of_birth) && !validateDate($date_of_birth)) {
        $errors[] = 'Please enter a valid date of birth.';
    }

    if (!empty($errors)) {
        $error_message = implode('<br>', $errors);
    } else {
        try {
            Database::beginTransaction();

            // Update user info
            Database::execute(
                "UPDATE users SET full_name = :full_name, email = :email, phone = :phone WHERE id = :id",
                ['full_name' => $full_name, 'email' => $email, 'phone' => $phone !== '' ? $phone : null, 'id' => $user_id]
            );

            // Update or create applicant profile
            if ($applicant) {
                Database::execute(
                    "UPDATE applicants SET full_name = :full_name, email = :email, phone = :phone, gender = :gender, date_of_birth = :dob, address = :address WHERE id = :id",
                    [
                        'full_name' => $full_name,
                        'email' => $email,
                        'phone' => $phone !== '' ? $phone : null,
                        'gender' => $gender !== '' ? $gender : null,
                        'dob' => $date_of_birth !== '' ? $date_of_birth : null,
                        'address' => $address,
                        'id' => $applicant['id'],
                    ]
                );
            } else {
                Database::execute(
                    "INSERT INTO applicants (user_id, full_name, email, phone, gender, date_of_birth, address)
                     VALUES (:user_id, :full_name, :email, :phone, :gender, :dob, :address)",
                    [
                        ':user_id' => $user_id,
                        ':full_name' => $full_name,
                        ':email' => $email,
                        ':phone' => $phone !== '' ? $phone : null,
                        ':gender' => $gender !== '' ? $gender : null,
                        ':dob' => $date_of_birth !== '' ? $date_of_birth : null,
                        ':address' => $address,
                    ]
                );
            }

            Database::commit();

            $_SESSION['user_name'] = $full_name;

            setFlash('success', 'Your profile has been updated successfully!');
            redirect('profile.php');
        } catch (PDOException $e) {
            Database::rollBack();
            error_log('Profile update error: ' . $e->getMessage());
            $error_message = 'We could not save your profile right now. Please try again later.';
        }
    }
}

$page_title = 'Profile';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>My Profile</h1>
        <p class="description">View and edit your profile information</p>
    </div>
</div>

<div class="form-section">
    <h2>Profile Information</h2>

    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="full_name">Full Name *</label>
                <input
                    type="text"
                    class="form-control"
                    id="full_name"
                    name="full_name"
                    value="<?php echo htmlspecialchars($full_name); ?>"
                    required
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="email">Email *</label>
                <input
                    type="email"
                    class="form-control"
                    id="email"
                    name="email"
                    value="<?php echo htmlspecialchars($email); ?>"
                    required
                >
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="phone">Phone Number <span class="text-muted">(optional)</span></label>
                <input
                    type="tel"
                    class="form-control"
                    id="phone"
                    name="phone"
                    value="<?php echo htmlspecialchars($phone); ?>"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="gender">Gender</label>
                <select class="form-select" id="gender" name="gender">
                    <option value="">Select gender</option>
                    <option value="male" <?php echo $gender === 'male' ? 'selected' : ''; ?>>Male</option>
                    <option value="female" <?php echo $gender === 'female' ? 'selected' : ''; ?>>Female</option>
                    <option value="other" <?php echo $gender === 'other' ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="date_of_birth">Date of Birth</label>
            <input
                type="date"
                class="form-control"
                id="date_of_birth"
                name="date_of_birth"
                value="<?php echo htmlspecialchars($date_of_birth); ?>"
            >
        </div>

        <div class="mb-3">
            <label class="form-label" for="address">Address <span class="text-muted">(optional)</span></label>
            <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($address); ?></textarea>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary">Update Profile</button>
            <a href="<?php echo SORMS_URL; ?>" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
