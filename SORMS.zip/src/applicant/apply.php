<?php
/**
 * Applicant apply shortcut
 *
 * The application form lives with the campaign module. This page keeps
 * older links working and sends the student to the right form.
 */

require_once __DIR__ . '/../../includes/config.php';

requireLogin();

$campaignId = (int) ($_GET['id'] ?? $_GET['campaign_id'] ?? 0);

if ($campaignId < 1) {
    redirect('src/campaign/index.php');
}

redirect('src/campaign/apply.php?id=' . $campaignId);
