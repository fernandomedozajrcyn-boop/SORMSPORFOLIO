<?php
/**
 * Screening manage shortcut
 *
 * Screening is handled by the campaign management page. This page keeps
 * older links working and forwards the request with its parameters.
 */

require_once __DIR__ . '/../../includes/config.php';

requireRole(['admin', 'recruiter']);

$campaignId = (int) ($_GET['campaign_id'] ?? $_GET['id'] ?? 0);

if ($campaignId < 1) {
    redirect('src/screening/dashboard.php');
}

$params = ['campaign_id' => $campaignId];

if (!empty($_GET['application_id'])) {
    $params['application_id'] = (int) $_GET['application_id'];
}

if (!empty($_GET['action'])) {
    $params['action'] = $_GET['action'];
}

redirect('src/campaign/manage.php?' . http_build_query($params));
