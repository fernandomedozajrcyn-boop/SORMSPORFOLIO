<?php
/**
 * Screening Dashboard (main page for recruiters/admins)
 *
 * Shows all active campaigns and their screening status.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$isAdmin = userHasRole('admin');
$userId = (int) getUserId();

// Get organizations the current user can manage
$organizations = $isAdmin
    ? Database::query("SELECT id, name FROM organizations ORDER BY name")
    : getManageableOrganizations(false);

$allowedOrgIds = array_map('intval', array_column($organizations, 'id'));

$orgFilter = $_GET['org_id'] ?? null;
$validOrgFilter = null;

if ($orgFilter && in_array((int) $orgFilter, $allowedOrgIds, true)) {
    $validOrgFilter = (int) $orgFilter;
}

// Get all active campaigns with organization info
$campaignConditions = ['c.status != "draft"'];
$campaignParams = [];

if (!$isAdmin) {
    $campaignConditions[] = '(o.admin_user_id = :owner_admin OR o.founder_user_id = :owner_founder OR o.requested_by = :owner_requester)';
    $campaignParams[':owner_admin'] = $userId;
    $campaignParams[':owner_founder'] = $userId;
    $campaignParams[':owner_requester'] = $userId;
}

if ($validOrgFilter) {
    $campaignConditions[] = 'c.organization_id = :org_id';
    $campaignParams[':org_id'] = $validOrgFilter;
}

$campaigns = Database::query(
    "SELECT c.*, o.name as org_name, o.color_theme as org_color_theme, o.logo, o.cover_image
     FROM campaigns c
     JOIN organizations o ON c.organization_id = o.id
     WHERE " . implode(' AND ', $campaignConditions) . "
     ORDER BY c.recruitment_start DESC",
    $campaignParams
);

// Get statistics
$totalCampaigns = count($campaigns);
$openCampaigns = 0;
$inScreening = 0;
$closedCampaigns = 0;

foreach ($campaigns as $c) {
    if ($c['status'] === 'open') {
        $openCampaigns++;
    }
    if (isCampaignInScreening($c)) {
        $inScreening++;
    }
    if ($c['status'] === 'closed') {
        $closedCampaigns++;
    }
}

// Get total pending applications across all campaigns
$totalPending = (int) Database::value(
    "SELECT COUNT(*) FROM applications WHERE status NOT IN ('approved', 'rejected', 'withdrawn')"
);

// Get top campaigns by applications
$topCampaigns = Database::query(
    "SELECT c.id, c.title, o.name as org_name, COUNT(a.id) as application_count
     FROM campaigns c
     LEFT JOIN applications a ON c.id = a.campaign_id AND a.status IN ('applied', 'reviewing')
     JOIN organizations o ON c.organization_id = o.id
     WHERE c.status != 'draft'
     GROUP BY c.id, c.title, o.name
     ORDER BY application_count DESC
     LIMIT 5"
);

$page_title = 'Screening Dashboard';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Screening Dashboard</h1>
        <p class="description">Manage recruitment campaigns and screen applicants</p>
    </div>
    <div>
        <form method="GET" action="" class="d-flex gap-2">
            <label for="org_id" class="me-1">Filter by Organization:</label>
            <select name="org_id" id="org_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Organizations</option>
                <?php foreach ($organizations as $org): ?>
                    <option value="<?php echo $org['id']; ?>" <?php echo $orgFilter == $org['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($org['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<!-- Statistics Cards -->
<div class="dashboard-grid">
    <div class="stat-card">
        <div class="icon">📋</div>
        <div class="number"><?php echo $totalCampaigns; ?></div>
        <div class="label">Total Campaigns</div>
    </div>
    <div class="stat-card">
        <div class="icon">✅</div>
        <div class="number"><?php echo $openCampaigns; ?></div>
        <div class="label">Open for Applications</div>
    </div>
    <div class="stat-card">
        <div class="icon">👥</div>
        <div class="number"><?php echo $inScreening; ?></div>
        <div class="label">In Screening</div>
    </div>
    <div class="stat-card">
        <div class="icon">📝</div>
        <div class="number"><?php echo $totalPending; ?></div>
        <div class="label">Pending Applications</div>
    </div>
</div>

<!-- Top Campaigns -->
<?php if (!empty($topCampaigns)): ?>
<div class="card mt-4">
    <div class="card-header">
        <h3>Top Campaigns by Applications</h3>
    </div>
    <div class="card-body">
        <div class="table-wrapper">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Campaign</th>
                        <th>Organization</th>
                        <th>Applications</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topCampaigns as $index => $tc): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($tc['title']); ?></td>
                        <td><?php echo htmlspecialchars($tc['org_name']); ?></td>
                        <td><?php echo (int)$tc['application_count']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Active Campaigns -->
<?php if (empty($campaigns)): ?>
    <div class="empty-state">
        <div class="icon">📋</div>
        <h4>No active campaigns</h4>
        <p>There are no active campaigns available. <a href="<?php echo SORMS_URL; ?>src/campaign/create.php">Create a new campaign</a> to get started.</p>
    </div>
<?php else: ?>
<div class="table-wrapper">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Campaign</th>
                <th>Organization</th>
                <th>Dates</th>
                <th>Positions</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($campaigns as $campaign): ?>
            <tr>
                <td>
                    <a href="../campaign/manage.php?campaign_id=<?php echo $campaign['id']; ?>" class="text-decoration-none fw-semibold">
                        <?php echo htmlspecialchars($campaign['title']); ?>
                    </a>
                </td>
                <td><?php echo htmlspecialchars($campaign['org_name']); ?></td>
                <td>
                    <?php echo formatDate($campaign['recruitment_start']); ?> - <?php echo formatDate($campaign['recruitment_end']); ?>
                </td>
                <td><?php echo (int)$campaign['total_positions']; ?></td>
                <td>
                    <span class="badge bg-<?php echo $campaign['status'] === 'open' ? 'success' : ($campaign['status'] === 'closed' ? 'warning' : 'secondary'); ?>">
                        <?php echo campaignStatusLabel($campaign['status']); ?>
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <a href="../campaign/manage.php?campaign_id=<?php echo $campaign['id']; ?>" class="btn btn-sm btn-outline-primary">Screen</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
