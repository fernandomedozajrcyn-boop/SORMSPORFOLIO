<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireAdminAccess();

$page_title = 'Analytics Dashboard';
$page_csrf_token = csrfToken();
$apiUrl = SORMS_URL . 'api/analytics/stats.php';
$initialData = json_encode(
    ['api_url' => $apiUrl, 'period' => 'daily'],
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
$page_scripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>'
    . '<script>window.sormsAnalyticsConfig=' . $initialData . ';</script>'
    . '<script src="' . htmlspecialchars(SORMS_URL . 'assets/js/analytics.js', ENT_QUOTES, 'UTF-8') . '"></script>';

ob_start();
?>
<section class="analytics-dashboard" aria-labelledby="analytics-title">
    <div class="page-header">
        <div>
            <p class="analytics-eyebrow">Admin reporting</p>
            <h1 id="analytics-title">Analytics Dashboard</h1>
            <p class="description">Live site traffic, portfolio engagement, and account activity.</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-outline-primary" href="analytics-export.php?format=xlsx">Download Excel Report</a>
            <a class="btn btn-outline-primary" href="analytics-export.php?format=pdf">Download PDF Report</a>
        </div>
    </div>

    <div class="analytics-toolbar">
        <label for="analytics-period" class="form-label mb-0">Traffic period</label>
        <select id="analytics-period" class="form-select" aria-label="Select chart period">
            <option value="daily">Daily, last 30 days</option>
            <option value="weekly">Weekly, last 12 weeks</option>
            <option value="monthly">Monthly, last 12 months</option>
        </select>
        <span id="analytics-updated" class="text-muted small" aria-live="polite">Loading statistics</span>
    </div>

    <div id="analytics-error" class="alert alert-danger" role="alert" hidden></div>
    <div id="analytics-loading" class="analytics-loading" role="status">Loading dashboard statistics</div>

    <div class="analytics-kpi-grid" aria-live="polite">
        <article class="analytics-kpi">
            <span class="analytics-kpi-label">Total Visitor Traffic</span>
            <strong id="metric-visitors">--</strong>
            <span class="analytics-kpi-note">Tracked page views</span>
        </article>
        <article class="analytics-kpi">
            <span class="analytics-kpi-label">Portfolio PDF Downloads</span>
            <strong id="metric-downloads">--</strong>
            <span class="analytics-kpi-note"><span id="metric-conversion">--</span> tracked-network conversion</span>
        </article>
        <article class="analytics-kpi">
            <span class="analytics-kpi-label">Registered Users</span>
            <strong id="metric-users">--</strong>
            <span class="analytics-kpi-note"><span id="metric-signup-rate">--</span> signup completion</span>
        </article>
        <article class="analytics-kpi">
            <span class="analytics-kpi-label">Successful Login Rate</span>
            <strong id="metric-login-rate">--</strong>
            <span class="analytics-kpi-note">Successful sign-ins / recorded attempts</span>
        </article>
    </div>

    <div class="analytics-chart-grid">
        <article class="analytics-chart-card analytics-chart-wide">
            <div class="analytics-chart-heading">
                <div>
                    <h2>Traffic and Downloads</h2>
                    <p>Tracked page views compared with portfolio downloads</p>
                </div>
            </div>
            <div class="analytics-chart-canvas"><canvas id="traffic-chart" aria-label="Traffic and downloads over time" role="img"></canvas></div>
        </article>
        <article class="analytics-chart-card">
            <div class="analytics-chart-heading">
                <div>
                    <h2>Device Usage</h2>
                    <p>Share of tracked page views by device</p>
                </div>
            </div>
            <div class="analytics-chart-canvas analytics-chart-doughnut"><canvas id="device-chart" aria-label="Device usage percentages" role="img"></canvas></div>
            <div id="device-breakdown" class="analytics-breakdown"></div>
        </article>
        <article class="analytics-chart-card">
            <div class="analytics-chart-heading">
                <div>
                    <h2>Operating Systems</h2>
                    <p>Share of tracked page views by operating system</p>
                </div>
            </div>
            <div class="analytics-chart-canvas analytics-chart-doughnut"><canvas id="os-chart" aria-label="Operating system percentages" role="img"></canvas></div>
            <div id="os-breakdown" class="analytics-breakdown"></div>
        </article>
    </div>
    <p class="analytics-footnote">Visitor conversion uses distinct anonymized network addresses observed in page views and portfolio downloads. Network addresses are anonymized by default and may represent multiple people.</p>
</section>
<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
