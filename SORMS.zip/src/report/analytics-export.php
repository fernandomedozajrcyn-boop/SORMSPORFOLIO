<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/analytics.php';
require_once __DIR__ . '/../../includes/xlsx.php';

requireAdminAccess();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    exit('Method not allowed.');
}

$format = (string) ($_GET['format'] ?? '');
if (!in_array($format, ['xlsx', 'pdf'], true)) {
    http_response_code(400);
    exit('Unsupported report format.');
}

$reportData = getAnalyticsDashboardData('daily');
$summary = $reportData['summary'];

if ($format === 'pdf') {
    $content = '';
    $addText = static function (string $value, int $x, int $y, int $size = 10, bool $bold = false) use (&$content): void {
        $text = preg_replace('/[^\x20-\x7E]/', '?', $value);
        $text = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
        $font = $bold ? '/F2' : '/F1';
        $content .= "BT {$font} {$size} Tf {$x} {$y} Td ({$text}) Tj ET\n";
    };
    $addRect = static function (float $red, float $green, float $blue, int $x, int $y, int $width, int $height) use (&$content): void {
        $content .= "{$red} {$green} {$blue} rg {$x} {$y} {$width} {$height} re f\n";
    };

    $addText('Student Organization Recruitment System', 48, 754, 17, true);
    $addText('Analytics summary report | Generated ' . gmdate('Y-m-d H:i') . ' UTC', 48, 733, 9);

    $cards = [
        ['Visitor page views', number_format($summary['total_visitors']), ''],
        ['PDF downloads', number_format($summary['total_downloads']), $summary['visitor_conversion_rate'] . '% conversion'],
        ['Registered users', number_format($summary['total_users']), $summary['signup_completion_rate'] . '% signup completion'],
        ['Successful login rate', $summary['login_success_rate'] . '%', 'of recorded attempts'],
    ];
    foreach ($cards as $index => $card) {
        $x = 48 + ($index * 130);
        $addRect(0.95, 0.97, 0.99, $x, 618, 120, 94);
        $addRect(0.10, 0.45, 0.91, $x, 708, 120, 4);
        $addText($card[0], $x + 9, 690, 8, true);
        $addText($card[1], $x + 9, 659, 19, true);
        $addText($card[2], $x + 9, 637, 7);
    }

    $addText('TRAFFIC AND DOWNLOADS - LAST 7 DAYS', 48, 590, 11, true);
    $recentLabels = array_slice($reportData['trend']['labels'], -7);
    $recentVisitors = array_slice($reportData['trend']['visitors'], -7);
    $recentDownloads = array_slice($reportData['trend']['downloads'], -7);
    $maxTrend = max(array_merge([1], $recentVisitors, $recentDownloads));
    $chartBaseY = 444;
    $chartTopY = 563;
    $chartHeight = $chartTopY - $chartBaseY;
    $content .= "0.88 0.90 0.93 RG 48 {$chartBaseY} m 564 {$chartBaseY} l S\n";
    foreach ($recentLabels as $index => $label) {
        $groupX = 64 + ($index * 70);
        $visitorHeight = (int) round(($recentVisitors[$index] / $maxTrend) * $chartHeight);
        $downloadHeight = (int) round(($recentDownloads[$index] / $maxTrend) * $chartHeight);
        $addRect(0.10, 0.45, 0.91, $groupX, $chartBaseY, 18, max(2, $visitorHeight));
        $addRect(0.20, 0.66, 0.33, $groupX + 21, $chartBaseY, 18, max(2, $downloadHeight));
        $addText($label, $groupX - 3, 428, 7);
    }
    $addRect(0.10, 0.45, 0.91, 435, 405, 8, 8);
    $addText('Page views', 447, 405, 8);
    $addRect(0.20, 0.66, 0.33, 508, 405, 8, 8);
    $addText('Downloads', 520, 405, 8);

    $renderShareChart = static function (string $title, array $rows, int $topY) use ($addText, $addRect): void {
        $addText($title, 48, $topY, 11, true);
        $total = array_sum(array_column($rows, 'total'));
        $rows = array_slice($rows, 0, 5);
        foreach ($rows as $index => $row) {
            $y = $topY - 26 - ($index * 25);
            $share = analyticsPercent((float) $row['total'], (float) $total);
            $addText((string) $row['label'], 48, $y, 8);
            $addRect(0.91, 0.94, 0.97, 200, $y - 4, 280, 9);
            $addRect(0.10, 0.45, 0.91, 200, $y - 4, (int) round(280 * ($share / 100)), 9);
            $addText($share . '% (' . $row['total'] . ')', 492, $y, 8);
        }
    };
    $renderShareChart('DEVICE USAGE SHARE', $reportData['devices'], 378);
    $renderShareChart('OPERATING SYSTEM SHARE', $reportData['operating_systems'], 204);
    $addText('IP-based visitor conversion is approximate because addresses are anonymized by network.', 48, 40, 8);

    $contentLength = strlen($content);
    $objects = [
        '<< /Type /Catalog /Pages 2 0 R >>',
        '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>',
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
        '<< /Length ' . $contentLength . " >>\nstream\n" . $content . "endstream",
    ];
    $pdf = "%PDF-1.4\n";
    $offsets = [0];
    foreach ($objects as $index => $object) {
        $offsets[] = strlen($pdf);
        $pdf .= ($index + 1) . " 0 obj\n{$object}\nendobj\n";
    }
    $xrefOffset = strlen($pdf);
    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
    foreach (array_slice($offsets, 1) as $offset) {
        $pdf .= sprintf("%010d 00000 n \n", $offset);
    }
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
    $pdf .= "startxref\n{$xrefOffset}\n%%EOF";

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="sorms-analytics-' . gmdate('Ymd-His') . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    echo $pdf;
    exit;
}

function excelColumnName(int $column): string
{
    $name = '';
    while ($column > 0) {
        $remainder = ($column - 1) % 26;
        $name = chr(65 + $remainder) . $name;
        $column = intdiv($column - 1, 26);
    }
    return $name;
}

function excelCell(int $column, int $row, $value, bool $numeric = false, int $style = 0): string
{
    $reference = excelColumnName($column) . $row;
    $styleAttribute = $style > 0 ? ' s="' . $style . '"' : '';
    if ($numeric && is_numeric($value)) {
        return '<c r="' . $reference . '"' . $styleAttribute . '><v>' . (float) $value . '</v></c>';
    }
    $text = mb_convert_encoding((string) $value, 'UTF-8', 'UTF-8');
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text);
    $text = htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    return '<c r="' . $reference . '" t="inlineStr"' . $styleAttribute . '><is><t xml:space="preserve">' . $text . '</t></is></c>';
}

function excelWorksheetRow(array $values, int $rowNumber, bool $header = false): string
{
    $xml = '<row r="' . $rowNumber . '">';
    foreach (array_values($values) as $index => $value) {
        $isNumeric = !$header && is_numeric($value) && !is_string($value);
        $xml .= excelCell($index + 1, $rowNumber, $value, $isNumeric, $header ? 1 : 0);
    }
    return $xml . '</row>';
}

function writeAnalyticsWorkbook(array $reportData): void
{
    $summary = $reportData['summary'];
    $temporaryPath = tempnam(sys_get_temp_dir(), 'sorms-analytics-');
    $rawSheetPath = tempnam(sys_get_temp_dir(), 'sorms-analytics-raw-');
    if ($temporaryPath === false || $rawSheetPath === false) {
        if (is_string($temporaryPath) && is_file($temporaryPath)) {
            unlink($temporaryPath);
        }
        if (is_string($rawSheetPath) && is_file($rawSheetPath)) {
            unlink($rawSheetPath);
        }
        throw new RuntimeException('Unable to allocate temporary files for Excel export.');
    }

    try {
        $rawSheet = fopen($rawSheetPath, 'wb');
        if ($rawSheet === false) {
            throw new RuntimeException('Unable to create the raw telemetry worksheet.');
        }
        fwrite($rawSheet, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<cols><col min="1" max="1" width="12" customWidth="1"/><col min="2" max="2" width="24" customWidth="1"/>'
            . '<col min="3" max="3" width="22" customWidth="1"/><col min="4" max="7" width="20" customWidth="1"/>'
            . '<col min="8" max="8" width="32" customWidth="1"/><col min="9" max="9" width="48" customWidth="1"/>'
            . '<col min="10" max="10" width="48" customWidth="1"/></cols><sheetData>');
        fwrite($rawSheet, excelWorksheetRow(
            ['Event ID', 'Event Type', 'Created At (UTC)', 'Device', 'Operating System', 'Browser', 'Anonymized IP', 'Referrer', 'Metadata', 'User Agent'],
            1,
            true
        ));

        $statement = Database::getConnection()->prepare(
            'SELECT id, event_type, created_at, device_type, operating_system, browser,
                    ip_address, referrer, metadata, user_agent
             FROM activity_logs
             ORDER BY created_at DESC, id DESC'
        );
        $statement->execute();
        $rowNumber = 2;
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            fwrite($rawSheet, excelWorksheetRow([
                (int) $row['id'],
                (string) $row['event_type'],
                (string) $row['created_at'],
                (string) ($row['device_type'] ?? ''),
                (string) ($row['operating_system'] ?? ''),
                (string) ($row['browser'] ?? ''),
                (string) ($row['ip_address'] ?? ''),
                (string) ($row['referrer'] ?? ''),
                (string) ($row['metadata'] ?? ''),
                (string) ($row['user_agent'] ?? ''),
            ], $rowNumber++));
        }
        fwrite($rawSheet, '</sheetData></worksheet>');
        fclose($rawSheet);

        $summaryRows = [
            ['Metric', 'Value'],
            ['Generated at (UTC)', gmdate('Y-m-d H:i:s')],
            ['Total visitor page views', $summary['total_visitors']],
            ['Portfolio PDF downloads', $summary['total_downloads']],
            ['Registered users', $summary['total_users']],
            ['Tracked-network visitor conversion (%)', $summary['visitor_conversion_rate']],
            ['Signup completion rate (%)', $summary['signup_completion_rate']],
            ['Successful login rate (%)', $summary['login_success_rate']],
            ['Tracked visitor networks', $summary['tracked_visitor_networks']],
            ['', ''],
            ['Device type', 'Page views', 'Share (%)'],
        ];
        $deviceTotal = array_sum(array_column($reportData['devices'], 'total'));
        foreach ($reportData['devices'] as $row) {
            $summaryRows[] = [
                (string) $row['label'],
                (int) $row['total'],
                analyticsPercent((float) $row['total'], (float) $deviceTotal),
            ];
        }
        $summaryRows[] = ['', '', ''];
        $summaryRows[] = ['Operating system', 'Page views', 'Share (%)'];
        $osTotal = array_sum(array_column($reportData['operating_systems'], 'total'));
        foreach ($reportData['operating_systems'] as $row) {
            $summaryRows[] = [
                (string) $row['label'],
                (int) $row['total'],
                analyticsPercent((float) $row['total'], (float) $osTotal),
            ];
        }

        $summaryXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<cols><col min="1" max="1" width="42" customWidth="1"/><col min="2" max="2" width="22" customWidth="1"/>'
            . '<col min="3" max="3" width="18" customWidth="1"/></cols><sheetData>';
        foreach ($summaryRows as $index => $row) {
            $summaryXml .= excelWorksheetRow($row, $index + 1, $index === 0 || in_array($row[0], ['Device type', 'Operating system'], true));
        }
        $summaryXml .= '</sheetData></worksheet>';

        $files = [
            '[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                . '<Default Extension="xml" ContentType="application/xml"/>'
                . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                . '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                . '</Types>',
            '_rels/.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                . '</Relationships>',
            'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                . '<sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Raw Telemetry" sheetId="2" r:id="rId2"/></sheets></workbook>',
            'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
                . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>'
                . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                . '</Relationships>',
            'xl/styles.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>'
                . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1A73E8"/><bgColor indexed="64"/></patternFill></fill></fills>'
                . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                . '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
                . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
        ];
        $files['xl/worksheets/sheet1.xml'] = $summaryXml;
        $files['xl/worksheets/sheet2.xml'] = ['path' => $rawSheetPath];
        writeXlsxArchive($temporaryPath, $files);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="sorms-analytics-' . gmdate('Ymd-His') . '.xlsx"');
        header('Content-Length: ' . filesize($temporaryPath));
        header('Cache-Control: private, no-store, max-age=0');
        header('X-Content-Type-Options: nosniff');
        readfile($temporaryPath);
    } finally {
        if (isset($rawSheet) && is_resource($rawSheet)) {
            fclose($rawSheet);
        }
        if (is_file($temporaryPath)) {
            unlink($temporaryPath);
        }
        if (is_file($rawSheetPath)) {
            unlink($rawSheetPath);
        }
    }
}

try {
    writeAnalyticsWorkbook($reportData);
} catch (Throwable $exception) {
    error_log('Analytics Excel export failed: ' . $exception->getMessage());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
    }
    exit('Excel report generation failed. Please try again later.');
}
