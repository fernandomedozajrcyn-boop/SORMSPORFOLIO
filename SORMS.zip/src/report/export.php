<?php
/**
 * Application export (admin only)
 *
 * Streams every application as a CSV file that can be opened in Excel
 * or any spreadsheet application.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');

$applications = Database::query(
    "SELECT a.id, app.full_name AS applicant_name, app.email, app.phone,
            o.name AS organization_name, c.title AS campaign_title,
            a.status, a.applied_at, a.reviewed_at
     FROM applications a
     JOIN applicants app ON a.applicant_id = app.id
     JOIN campaigns c ON a.campaign_id = c.id
     JOIN organizations o ON c.organization_id = o.id
     ORDER BY a.applied_at DESC"
);

$filename = 'sorms-applications-' . date('Ymd-His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

$output = fopen('php://output', 'w');

if ($output === false) {
    exit;
}

// UTF-8 BOM so Excel displays the file correctly
fwrite($output, "\xEF\xBB\xBF");

fputcsv($output, [
    'Application ID',
    'Applicant',
    'Email',
    'Phone',
    'Organization',
    'Campaign',
    'Status',
    'Applied At',
    'Reviewed At',
]);

foreach ($applications as $application) {
    fputcsv($output, [
        $application['id'],
        $application['applicant_name'],
        $application['email'],
        $application['phone'] ?? '',
        $application['organization_name'],
        $application['campaign_title'],
        applicationStatusLabel($application['status']),
        $application['applied_at'],
        $application['reviewed_at'] ?? '',
    ]);
}

fclose($output);
exit;
