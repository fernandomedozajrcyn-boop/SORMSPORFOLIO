<?php
/**
 * Login Activity Report (admin only)
 *
 * Shows successful and failed sign-in attempts with the IP address,
 * device, browser, operating system, approximate location, and network.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');

$statusFilter = (string) ($_GET['status'] ?? '');
if (!in_array($statusFilter, ['success', 'failed'], true)) {
    $statusFilter = '';
}

$userFilter = (int) ($_GET['user_id'] ?? 0);

$conditions = [];
$params = [];

if ($statusFilter !== '') {
    $conditions[] = 'l.status = :status';
    $params['status'] = $statusFilter;
}

if ($userFilter > 0) {
    $conditions[] = 'l.user_id = :user_id';
    $params['user_id'] = $userFilter;
}

$whereSql = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

$logs = Database::query(
    "SELECT l.*, u.full_name, u.username, u.role
     FROM login_logs l
     LEFT JOIN users u ON l.user_id = u.id
     $whereSql
     ORDER BY l.created_at DESC
     LIMIT 200",
    $params
);

$users = Database::query(
    'SELECT id, full_name, username FROM users ORDER BY full_name ASC'
);

$summary = Database::fetch(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'success'), 0) AS success_count,
            COALESCE(SUM(status = 'failed'), 0) AS failed_count,
            COUNT(DISTINCT ip_address) AS unique_ips
     FROM login_logs"
);

$todayCount = (int) Database::value(
    'SELECT COUNT(*) FROM login_logs WHERE DATE(created_at) = CURDATE()'
);

$page_title = 'Login Activity';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Login Activity</h1>
        <p class="description">Sign-in attempts, devices, networks, and approximate locations</p>
    </div>
    <div>
        <a href="index.php" class="btn btn-outline-secondary">Back to Reports</a>
    </div>
</div>

<div class="dashboard-grid">
    <div class="stat-card">
        <div class="number"><?php echo (int) $summary['total']; ?></div>
        <div class="label">Total Login Attempts</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo (int) $summary['success_count']; ?></div>
        <div class="label">Successful Logins</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo (int) $summary['failed_count']; ?></div>
        <div class="label">Failed Logins</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo $todayCount; ?></div>
        <div class="label">Attempts Today</div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-body">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label" for="status">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All attempts</option>
                    <option value="success" <?php echo $statusFilter === 'success' ? 'selected' : ''; ?>>Successful</option>
                    <option value="failed" <?php echo $statusFilter === 'failed' ? 'selected' : ''; ?>>Failed</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="user_id">User</label>
                <select class="form-select" id="user_id" name="user_id">
                    <option value="0">All users</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo (int) $user['id']; ?>" <?php echo $userFilter === (int) $user['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['username'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <a href="logins.php" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3>Recent Login Attempts</h3>
    </div>
    <div class="card-body">
        <?php if (empty($logs)): ?>
            <div class="empty-state">
                <h4>No login activity yet</h4>
                <p>Login attempts will appear here once users start signing in.</p>
            </div>
        <?php else: ?>
            <p class="text-muted small">Showing the latest <?php echo count($logs); ?> attempt(s). Unique IP addresses: <?php echo (int) $summary['unique_ips']; ?>.</p>
            <div class="table-wrapper">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>When</th>
                            <th>User</th>
                            <th>Status</th>
                            <th>IP Address</th>
                            <th>Device</th>
                            <th>Location</th>
                            <th>Network</th>
                            <th>Referer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <?php
                            $locationParts = array_filter([
                                $log['city'] ?? '',
                                $log['region'] ?? '',
                                $log['country'] ?? '',
                            ]);
                            $locationText = $locationParts ? implode(', ', $locationParts) : 'Local / Unknown';
                        ?>
                        <tr>
                            <td class="text-nowrap"><?php echo formatDateTime($log['created_at']); ?></td>
                            <td>
                                <?php if (!empty($log['full_name'])): ?>
                                    <strong><?php echo htmlspecialchars($log['full_name']); ?></strong><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($log['username'] ?? ''); ?><?php echo !empty($log['role']) ? ' - ' . htmlspecialchars($log['role']) : ''; ?></small>
                                <?php else: ?>
                                    <span class="text-muted">Unknown user</span><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($log['username_attempted'] ?? 'Not provided'); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $log['status'] === 'success' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($log['status']); ?>
                                </span>
                            </td>
                            <td class="text-nowrap"><?php echo htmlspecialchars($log['ip_address'] ?? 'Unknown'); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($log['device_type'] ?? 'Unknown'); ?></strong><br>
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($log['browser'] ?? 'Unknown'); ?>
                                    /
                                    <?php echo htmlspecialchars($log['operating_system'] ?? 'Unknown'); ?>
                                </small>
                            </td>
                            <td><?php echo htmlspecialchars($locationText); ?></td>
                            <td><?php echo htmlspecialchars($log['isp'] ?? 'Unknown'); ?></td>
                            <td>
                                <?php if (!empty($log['referer'])): ?>
                                    <span class="text-muted small" title="<?php echo htmlspecialchars($log['referer']); ?>">
                                        <?php echo htmlspecialchars(mb_strimwidth($log['referer'], 0, 32, '...')); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted small">Direct</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
