<?php
/**
 * Logout handler
 *
 * Destroys the current session and redirects to the login page.
 */

require_once __DIR__ . '/../../includes/config.php';

session_start();

// Clear all session variables
$_SESSION = [];

// Destroy the session cookie
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: ' . SORMS_URL . 'src/auth/login.php');
exit;
