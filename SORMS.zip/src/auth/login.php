<?php
/**
 * Login page for Student Organization Recruitment Management System
 *
 * Allows users to login with their username/email and password.
 * Supports Admin, Recruiter, and Student roles.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

startSession();

// Prevent multiple logins on the same session
if (isLoggedIn()) {
    redirect(homeUrlForRole());
}

$error = '';
$usernameOrEmail = '';
$showForm = true;
$rateLimitExceeded = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameOrEmail = sanitize($_POST['username_or_email'] ?? '');
    $password = $_POST['password'] ?? '';

    $rateLimitExceeded = !consumeRateLimit('login_attempts', 'USER_LOGIN', 10, 40, 900);

    if ($rateLimitExceeded) {
        $error = 'Too many sign-in attempts. Please wait a few minutes and try again.';
    } elseif (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (empty($usernameOrEmail) || empty($password) || strlen($password) > 1024) {
        $error = 'Please enter your username/email and password.';
    } else {
        // Fetch user by username or email
        $user = Database::fetch(
            "SELECT * FROM users WHERE (username = :username OR email = :email) AND status = 'active'",
            ['username' => $usernameOrEmail, 'email' => $usernameOrEmail]
        );

        if ($user && password_verify($password, $user['password_hash'])) {
            // Login successful
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_phone'] = $user['phone'];
            $_SESSION['user_avatar'] = $user['avatar'];
            $_SESSION['user_status'] = $user['status'];

            // Fetch full user data for the session
            $fullUser = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $user['id']]);
            $_SESSION['user'] = $fullUser;

            // Check if user is active
            if ($fullUser['status'] === 'suspended') {
                session_destroy();
                recordLoginAttempt((int) $user['id'], $usernameOrEmail, 'failed');
                $error = 'Your account has been suspended. Please contact the administrator.';
            } else {
                recordLoginAttempt((int) $user['id'], $usernameOrEmail, 'success');

                // Redirect based on role
                redirect(homeUrlForRole($fullUser['role']));
            }
        } else {
            recordLoginAttempt($user ? (int) $user['id'] : null, $usernameOrEmail, 'failed');
            $error = 'Invalid username/email or password.';
        }
    }
}

$page_title = 'Login';
ob_start();
?>
<div class="login-container">
    <div class="login-card">
        <div class="text-center mb-4">
            <h1 class="display-5 fw-bold"><?php echo htmlspecialchars(SORMS_SITE_NAME); ?></h1>
            <p class="text-muted">Sign in to your account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="login-form">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

            <div class="mb-3">
                <label class="form-label" for="username_or_email">Username or Email</label>
                <input
                    type="text"
                    class="form-control"
                    id="username_or_email"
                    name="username_or_email"
                    maxlength="100"
                    placeholder="Enter your username or email"
                    value="<?php echo htmlspecialchars($usernameOrEmail); ?>"
                    autofocus
                    required
                >
            </div>

            <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <input
                    type="password"
                    class="form-control"
                    id="password"
                    name="password"
                    maxlength="1024"
                    placeholder="Enter your password"
                    required
                >
                <div class="form-text">
                    <a href="#" class="text-decoration-none">Forgot your password?</a>
                </div>
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg">Sign In</button>
            </div>
        </form>

        <div class="mt-4 text-center">
            <p class="text-muted">
                Don't have an account? <a href="register.php" class="text-decoration-none fw-semibold">Register</a>
            </p>
            
        </div>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
