<?php
/**
 * Registration page for Student Organization Recruitment Management System
 *
 * Creates a student account together with its applicant profile.
 * Recruiters and administrators are created by an administrator, not here.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

startSession();

// A signed in user has no business on the registration page
if (isLoggedIn()) {
    redirect('src/applicant/index.php');
}

$isRegistrationEnabled = (bool) SORMS_REGISTRATION_ENABLED;

$error = '';
$fullName = '';
$username = '';
$email = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = sanitize($_POST['full_name'] ?? '');
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

    if (!consumeRateLimit('signup_attempts', 'USER_SIGNUP', 5, 20, 3600)) {
        $error = 'Too many account creation attempts. Please wait and try again later.';
    } elseif (!$isRegistrationEnabled) {
        $error = 'Registrations are currently closed. Please contact the administrator for access.';
    } elseif (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } else {
        logActivity('USER_SIGNUP', ['status' => 'attempt']);
        $errors = [];

        if (!validateString($fullName, 2, 100)) {
            $errors[] = 'Full name must be between 2 and 100 characters.';
        }

        if (!validateString($username, 3, 50)) {
            $errors[] = 'Username must be between 3 and 50 characters.';
        } elseif (!preg_match('/^[A-Za-z0-9._-]+$/', $username)) {
            $errors[] = 'Username can only contain letters, numbers, dots, underscores and hyphens.';
        }

        if (!validateEmail($email)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if ($phone !== '' && !validatePhone($phone)) {
            $errors[] = 'Please enter a valid phone number.';
        }

        if (
            strlen($password) < 8
            || strlen($password) > 128
            || !preg_match('/[A-Za-z]/', $password)
            || !preg_match('/[0-9]/', $password)
        ) {
            $errors[] = 'Password must be at least 8 characters and include a letter and a number.';
        }

        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }

        if (validateString($username, 1, 50) && tableHasRows('users', ['username' => $username])) {
            $errors[] = 'This username is already taken.';
        }

        if (validateEmail($email) && tableHasRows('users', ['email' => $email])) {
            $errors[] = 'This email address is already registered.';
        }

        if ($errors) {
            $error = implode(PHP_EOL, $errors);
        } else {
            try {
                Database::beginTransaction();

                Database::execute(
                    "INSERT INTO users (username, email, password_hash, full_name, role, phone, status)
                     VALUES (:username, :email, :password_hash, :full_name, 'student', :phone, 'active')",
                    [
                        ':username'     => $username,
                        ':email'        => $email,
                        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
                        ':full_name'    => $fullName,
                        ':phone'        => $phone !== '' ? $phone : null,
                    ]
                );

                $userId = Database::getLastInsertId();

                Database::execute(
                    "INSERT INTO applicants (user_id, full_name, email, phone)
                     VALUES (:user_id, :full_name, :email, :phone)",
                    [
                        ':user_id'  => $userId,
                        ':full_name' => $fullName,
                        ':email'    => $email,
                        ':phone'    => $phone !== '' ? $phone : null,
                    ]
                );

                Database::commit();
                logActivity('USER_SIGNUP', ['status' => 'success'], (int) $userId);

                setFlash('success', 'Your account has been created successfully. Please sign in.');
                redirect('src/auth/login.php');
            } catch (PDOException $e) {
                Database::rollBack();
                error_log('Registration error: ' . $e->getMessage());
                $error = 'We could not create your account right now. Please try again later.';
            }
        }
    }
}

$page_title = 'Register';

ob_start();
?>
<div class="register-container">
    <div class="register-card">
        <div class="text-center mb-4">
            <h1 class="display-5 fw-bold">Create Your Account</h1>
            <p class="text-muted">Join the Student Organization Recruitment System</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo nl2br(htmlspecialchars($error, ENT_QUOTES, 'UTF-8')); ?>
            </div>
        <?php endif; ?>

        <?php if (!$isRegistrationEnabled): ?>
            <div class="alert alert-warning" role="alert">
                Registrations are currently closed. Please contact the administrator for access.
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="register-form">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="full_name">Full Name *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="full_name"
                        name="full_name"
                        maxlength="100"
                        placeholder="Enter your full name"
                        value="<?php echo htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8'); ?>"
                        required
                    >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="username">Username *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="username"
                        name="username"
                        maxlength="50"
                        placeholder="Enter your username"
                        value="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>"
                        required
                    >
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="email">Email Address *</label>
                <input
                    type="email"
                    class="form-control"
                    id="email"
                    name="email"
                    maxlength="100"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                    required
                >
            </div>

            <div class="mb-3">
                <label class="form-label" for="phone">Phone Number <span class="text-muted">(optional)</span></label>
                <input
                    type="tel"
                    class="form-control"
                    id="phone"
                    name="phone"
                    maxlength="20"
                    placeholder="Enter your phone number"
                    value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>"
                >
            </div>

            <div class="mb-3">
                <label class="form-label" for="password">Password *</label>
                <input
                    type="password"
                    class="form-control"
                    id="password"
                    name="password"
                    placeholder="At least 8 characters, including a letter and a number"
                    minlength="8"
                    maxlength="128"
                    data-password-strength
                    aria-describedby="password-strength"
                    required
                >
                <div class="password-strength mt-2" aria-live="polite">
                    <div class="progress" role="progressbar" aria-label="Password strength" aria-valuemin="0" aria-valuemax="4" aria-valuenow="0">
                        <div class="progress-bar" id="password-strength-meter" style="width: 0%"></div>
                    </div>
                    <small class="form-text" id="password-strength">Use at least 8 characters, a letter, and a number.</small>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="confirm_password">Confirm Password *</label>
                <input
                    type="password"
                    class="form-control"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Confirm your password"
                    required
                >
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg" <?php echo $isRegistrationEnabled ? '' : 'disabled'; ?>>Create Account</button>
            </div>
        </form>

        <div class="mt-4 text-center">
            <p class="text-muted">
                Already have an account? <a href="login.php" class="text-decoration-none fw-semibold">Sign in</a>
            </p>
        </div>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
