<?php
/**
 * Secure organization document viewer
 *
 * Documents are stored outside the public web root and are only served
 * to administrators, the uploader, or the organization's managers.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireLogin();

$documentId = (int) ($_GET['id'] ?? 0);

$document = Database::fetch(
    'SELECT * FROM organization_documents WHERE id = :id',
    ['id' => $documentId]
);

if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}

$isUploader = (int) $document['uploaded_by'] === (int) getUserId();
$canManage = canManageOrganization((int) $document['organization_id']);

if (!userHasRole('admin') && !$isUploader && !$canManage) {
    http_response_code(403);
    exit('You do not have permission to view this document.');
}

$storageRoot = realpath(SORMS_ORG_DOCUMENTS_PATH);
$filePath = realpath(SORMS_ORG_DOCUMENTS_PATH . DIRECTORY_SEPARATOR . basename($document['stored_name']));

if (
    $storageRoot === false
    || $filePath === false
    || strpos($filePath, $storageRoot) !== 0
    || !is_file($filePath)
) {
    http_response_code(404);
    exit('Document file not found.');
}

$mimeType = $document['mime_type'] ?: 'application/octet-stream';
$safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $document['original_name']);

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($filePath));
header('Content-Disposition: inline; filename="' . $safeName . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=0, no-store');

readfile($filePath);
exit;
