<?php
/**
 * Create Organization Page
 *
 * Allows admin to create a new student organization.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');
requireLogin();

$error = '';
$success = '';
$name = '';
$description = '';
$established_date = '';
$website = '';
$social_link = '';
$color_theme = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $established_date = $_POST['established_date'] ?? '';
    $website = sanitize($_POST['website'] ?? '');
    $social_link = sanitize($_POST['social_link'] ?? '');
    $color_theme = sanitize($_POST['color_theme'] ?? '');
    $status = 'active';

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (empty($name)) {
        $error = 'Organization name is required.';
    } elseif (!validateString($name, 2, 150)) {
        $error = 'Organization name must be between 2 and 150 characters.';
    } elseif (tableHasRows('organizations', ['name' => $name])) {
        $error = 'An organization with this name already exists.';
    } elseif (empty($established_date)) {
        $error = 'Establishment date is required.';
    } elseif (!validateDate($established_date)) {
        $error = 'Please enter a valid date.';
    } elseif (!empty($website) && !filter_var($website, FILTER_VALIDATE_URL)) {
        $error = 'Please enter a valid website URL.';
    }

    if (empty($error)) {
        $sql = "INSERT INTO organizations
                (name, description, established_date, website, social_link, color_theme, status,
                 verification_status, verified_by, verified_at, founder_user_id, admin_user_id)
                VALUES (:name, :description, :established_date, :website, :social_link, :color_theme, :status,
                        'verified', :verified_by, NOW(), :founder_user_id, :admin_user_id)";

        $stmt = Database::getConnection()->prepare($sql);

        try {
            $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':established_date' => $established_date,
                ':website' => $website !== '' ? $website : null,
                ':social_link' => $social_link !== '' ? $social_link : null,
                ':color_theme' => $color_theme !== '' ? $color_theme : null,
                ':status' => $status,
                ':verified_by' => $_SESSION['user_id'],
                ':founder_user_id' => $_SESSION['user_id'],
                ':admin_user_id' => $_SESSION['user_id'],
            ]);

            $orgId = Database::getLastInsertId();

            $success = 'Organization "' . $name . '" has been created successfully.';

            $name = '';
            $description = '';
            $established_date = '';
            $website = '';
            $social_link = '';
            $color_theme = '';
        } catch (PDOException $e) {
            error_log('Create organization error: ' . $e->getMessage());
            $error = 'Failed to create organization. Please try again.';
        }
    }
}

$page_title = 'Create Organization';
ob_start();

?>
<div class="page-header">
    <div>
        <h1>Create New Organization</h1>
        <p class="description">Add a new student organization to the recruitment system</p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back to List</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" role="alert">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<div class="form-section">
    <h2>Organization Details</h2>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="name">Organization Name *</label>
                <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"
                    value="<?php echo htmlspecialchars($name); ?>"
                    required
                    placeholder="e.g. IT Students Association"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="established_date">Established Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="established_date"
                    name="established_date"
                    value="<?php echo htmlspecialchars($established_date); ?>"
                    required
                >
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="description">Description</label>
            <textarea
                class="form-control"
                id="description"
                name="description"
                rows="4"
                placeholder="Describe the organization, its purpose, and activities"
            ><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label" for="website">Website</label>
            <input
                type="url"
                class="form-control"
                id="website"
                name="website"
                value="<?php echo htmlspecialchars($website); ?>"
                placeholder="https://example.com"
            >
        </div>

        <div class="mb-3">
            <label class="form-label" for="social_link">Social Media Links <span class="text-muted">(comma separated)</span></label>
            <input
                type="text"
                class="form-control"
                id="social_link"
                name="social_link"
                value="<?php echo htmlspecialchars($social_link); ?>"
                placeholder="https://facebook.com/..., https://twitter.com/..."
            >
        </div>

        <div class="mb-3">
            <label class="form-label" for="color_theme">Color Theme <span class="text-muted">(hex code)</span></label>
            <input
                type="color"
                class="form-control form-control-color"
                id="color_theme"
                name="color_theme"
                value="<?php echo htmlspecialchars($color_theme); ?>"
                title="Enter hex color code"
            >
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg">Create Organization</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';


