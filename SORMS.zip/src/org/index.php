<?php
/**
 * Organization Listing Page
 *
 * Admins see every organization. Recruiters only see the organizations
 * they are allowed to manage.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$page_title = 'Organizations';
$isAdmin = userHasRole('admin');

if ($isAdmin) {
    $organizations = Database::query(
        "SELECT o.*, u.full_name AS founder_name
         FROM organizations o
         LEFT JOIN users u ON o.admin_user_id = u.id
         ORDER BY o.created_at DESC"
    );
} else {
    $userId = (int) getUserId();
    $organizations = Database::query(
        "SELECT o.*, u.full_name AS founder_name
         FROM organizations o
         LEFT JOIN users u ON o.admin_user_id = u.id
         WHERE o.admin_user_id = :admin_user_id
            OR o.founder_user_id = :founder_user_id
            OR o.requested_by = :requested_by
         ORDER BY o.created_at DESC",
        [
            'admin_user_id' => $userId,
            'founder_user_id' => $userId,
            'requested_by' => $userId,
        ]
    );
}

$pendingRequests = $isAdmin
    ? (int) Database::value("SELECT COUNT(*) FROM organizations WHERE verification_status = 'pending'")
    : 0;

$verificationLabels = [
    'unverified' => 'Not Submitted',
    'pending' => 'Pending Review',
    'verified' => 'Verified',
    'rejected' => 'Rejected',
];

ob_start();
?>
<div class="page-header">
    <div>
        <h1><?php echo $isAdmin ? 'Organizations' : 'My Organizations'; ?></h1>
        <p class="description">
            <?php echo $isAdmin
                ? 'Review requests and manage student organizations in the recruitment system'
                : 'Organizations you are verified to manage'; ?>
        </p>
    </div>
    <?php if ($isAdmin): ?>
        <a href="create.php" class="btn btn-primary">New Organization</a>
    <?php endif; ?>
</div>

<?php if ($isAdmin && $pendingRequests > 0): ?>
    <div class="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span>
            <strong><?php echo $pendingRequests; ?></strong>
            organization request<?php echo $pendingRequests === 1 ? '' : 's'; ?> awaiting verification.
        </span>
        <a href="index.php#pending-reviews" class="btn btn-sm btn-warning">Review Requests</a>
    </div>
<?php endif; ?>

<?php if (empty($organizations)): ?>
    <div class="alert alert-info">
        <?php if ($isAdmin): ?>
            No organizations found. <a href="create.php">Create your first organization</a> to get started.
        <?php else: ?>
            You are not managing any organization yet. Organizations appear here after an administrator approves your request.
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="table-wrapper">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Organization Name</th>
                    <th>Founder</th>
                    <th>Verification</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($organizations as $index => $org): ?>
                <tr id="<?php echo $org['verification_status'] === 'pending' ? 'pending-reviews' : ''; ?>">
                    <td><?php echo $index + 1; ?></td>
                    <td>
                        <?php if (canManageOrganization((int) $org['id'])): ?>
                            <a href="edit.php?id=<?php echo (int) $org['id']; ?>" class="text-decoration-none fw-semibold">
                                <?php echo htmlspecialchars($org['name']); ?>
                            </a>
                        <?php else: ?>
                            <span class="fw-semibold"><?php echo htmlspecialchars($org['name']); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($org['founder_name'] ?? 'N/A'); ?></td>
                    <td>
                        <?php
                        $verificationStatus = $org['verification_status'] ?? 'unverified';
                        $verificationColor = [
                            'verified' => 'success',
                            'pending' => 'warning',
                            'rejected' => 'danger',
                            'unverified' => 'secondary',
                        ][$verificationStatus] ?? 'secondary';
                        ?>
                        <span class="badge bg-<?php echo $verificationColor; ?>">
                            <?php echo htmlspecialchars($verificationLabels[$verificationStatus] ?? $verificationStatus); ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-<?php echo $org['status'] === 'active' ? 'success' : ($org['status'] === 'pending' ? 'warning' : 'secondary'); ?>">
                            <?php echo strtoupper($org['status']); ?>
                        </span>
                    </td>
                    <td><?php echo formatDate($org['created_at']); ?></td>
                    <td>
                        <div class="btn-group flex-wrap">
                            <?php if ($isAdmin && in_array($verificationStatus, ['pending', 'rejected', 'unverified'], true)): ?>
                                <a href="review.php?id=<?php echo (int) $org['id']; ?>" class="btn btn-sm btn-warning">Review</a>
                            <?php endif; ?>
                            <?php if (canManageOrganization((int) $org['id'])): ?>
                                <a href="edit.php?id=<?php echo (int) $org['id']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                <a href="../campaign/index.php?org_id=<?php echo (int) $org['id']; ?>" class="btn btn-sm btn-outline-info">Manage Campaigns</a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
