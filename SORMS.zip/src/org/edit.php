<?php
/**
 * Edit Organization Page
 *
 * Allows admins and verified organization managers to update an organization.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$isAdmin = userHasRole('admin');

$error = '';
$success = '';
$id = $_GET['id'] ?? null;

if (!$id) {
    setFlash('error', 'Organization ID is required.');
    redirect('src/org/index.php');
}

$organization = Database::fetch('SELECT * FROM organizations WHERE id = :id', ['id' => $id]);

if (!$organization) {
    setFlash('error', 'Organization not found.');
    redirect('src/org/index.php');
}

if (!canManageOrganization((int) $organization['id'])) {
    setFlash('error', 'You do not have permission to manage this organization.');
    redirect('src/org/index.php');
}

$name = $organization['name'];
$description = $organization['description'] ?? '';
$established_date = $organization['established_date'] ?? '';
$website = $organization['website'] ?? '';
$social_link = $organization['social_link'] ?? '';
$color_theme = $organization['color_theme'] ?? '';
$status = $organization['status'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $established_date = $_POST['established_date'] ?? '';
    $website = sanitize($_POST['website'] ?? '');
    $social_link = sanitize($_POST['social_link'] ?? '');
    $color_theme = sanitize($_POST['color_theme'] ?? '');
    $status = $isAdmin ? ($_POST['status'] ?? 'pending') : $organization['status'];

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (!validateString($name, 2, 150)) {
        $error = 'Organization name must be between 2 and 150 characters.';
    } elseif (tableHasRows('organizations', ['name' => $name])) {
        $duplicate = Database::fetch('SELECT id FROM organizations WHERE name = :name AND id != :id', ['name' => $name, 'id' => $id]);
        if ($duplicate) {
            $error = 'An organization with this name already exists.';
        }
    } elseif (empty($established_date)) {
        $error = 'Establishment date is required.';
    } elseif (!validateDate($established_date)) {
        $error = 'Please enter a valid date.';
    } elseif (!empty($website) && !filter_var($website, FILTER_VALIDATE_URL)) {
        $error = 'Please enter a valid website URL.';
    } elseif ($isAdmin && !in_array($status, ['active', 'inactive', 'pending'], true)) {
        $error = 'Please choose a valid status.';
    }

    if (empty($error)) {
        try {
            Database::execute(
                "UPDATE organizations SET
                    name = :name,
                    description = :description,
                    established_date = :established_date,
                    website = :website,
                    social_link = :social_link,
                    color_theme = :color_theme,
                    status = :status,
                    updated_at = CURRENT_TIMESTAMP
                 WHERE id = :id",
                [
                    ':name' => $name,
                    ':description' => $description,
                    ':established_date' => $established_date,
                    ':website' => $website !== '' ? $website : null,
                    ':social_link' => $social_link !== '' ? $social_link : null,
                    ':color_theme' => $color_theme !== '' ? $color_theme : null,
                    ':status' => $status,
                    ':id' => $id,
                ]
            );

            $success = 'Organization "' . $name . '" has been updated successfully.';
        } catch (PDOException $e) {
            error_log('Update organization error: ' . $e->getMessage());
            $error = 'Failed to update organization. Please try again.';
        }
    }
}

$page_title = 'Edit Organization';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Edit Organization</h1>
        <p class="description">Update the details of <?php echo htmlspecialchars($organization['name']); ?></p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back to List</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" role="alert">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<div class="form-section">
    <h2>Organization Details</h2>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="name">Organization Name *</label>
                <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"
                    value="<?php echo htmlspecialchars($name); ?>"
                    required
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="established_date">Established Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="established_date"
                    name="established_date"
                    value="<?php echo htmlspecialchars($established_date); ?>"
                    required
                >
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="description">Description</label>
            <textarea
                class="form-control"
                id="description"
                name="description"
                rows="4"
                placeholder="Describe the organization, its purpose, and activities"
            ><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label" for="website">Website</label>
            <input
                type="url"
                class="form-control"
                id="website"
                name="website"
                value="<?php echo htmlspecialchars($website); ?>"
                placeholder="https://example.com"
            >
        </div>

        <div class="mb-3">
            <label class="form-label" for="social_link">Social Media Links <span class="text-muted">(comma separated)</span></label>
            <input
                type="text"
                class="form-control"
                id="social_link"
                name="social_link"
                value="<?php echo htmlspecialchars($social_link); ?>"
                placeholder="https://facebook.com/..., https://twitter.com/..."
            >
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="color_theme">Color Theme <span class="text-muted">(hex code)</span></label>
                <input
                    type="color"
                    class="form-control form-control-color"
                    id="color_theme"
                    name="color_theme"
                    value="<?php echo htmlspecialchars($color_theme !== '' ? $color_theme : '#1a73e8'); ?>"
                    title="Enter hex color code"
                >
            </div>
            <div class="col-md-6 mb-3">
                <?php if ($isAdmin): ?>
                    <label class="form-label" for="status">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                <?php else: ?>
                    <label class="form-label">Status</label>
                    <div>
                        <span class="badge bg-<?php echo $status === 'active' ? 'success' : ($status === 'pending' ? 'warning' : 'secondary'); ?>">
                            <?php echo strtoupper($status); ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg">Save Changes</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
