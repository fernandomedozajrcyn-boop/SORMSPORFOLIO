<?php
/**
 * Organization Verification Review (admin only)
 *
 * Lets an administrator inspect the uploaded papers and approve or reject
 * an organization's request to use the recruitment platform.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');

$organizationId = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

if ($organizationId < 1) {
    setFlash('error', 'Organization ID is required.');
    redirect('src/org/index.php');
}

$organization = Database::fetch(
    'SELECT o.*,
            requester.full_name AS requester_name,
            requester.username AS requester_username,
            requester.role AS requester_role,
            verifier.full_name AS verifier_name
     FROM organizations o
     LEFT JOIN users requester ON o.requested_by = requester.id
     LEFT JOIN users verifier ON o.verified_by = verifier.id
     WHERE o.id = :id',
    ['id' => $organizationId]
);

if (!$organization) {
    setFlash('error', 'Organization not found.');
    redirect('src/org/index.php');
}

$documents = Database::query(
    'SELECT * FROM organization_documents WHERE organization_id = :organization_id ORDER BY created_at DESC',
    ['organization_id' => $organizationId]
);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $notes = sanitize($_POST['verification_notes'] ?? '');

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (!in_array($action, ['approve', 'reject', 'delete'], true)) {
        $error = 'Please choose a valid review action.';
    } elseif ($organization['verification_status'] === 'verified') {
        $error = 'Verified organizations cannot be changed from request review.';
    } elseif ($action === 'reject' && $notes === '') {
        $error = 'Please add a reason when rejecting an organization.';
    } else {
        $ownerId = (int) ($organization['requested_by']
            ?: $organization['founder_user_id']
            ?: $organization['admin_user_id']);

        try {
            Database::beginTransaction();

            if ($action === 'delete') {
                if ($ownerId > 0) {
                    $notification = Database::getConnection()->prepare(
                        "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                         VALUES (:user_id, 'organization_rejected', 'Organization Request Removed',
                                 :message, :link, 0)"
                    );
                    $notification->execute([
                        'user_id' => $ownerId,
                        'message' => $organization['name'] . ' was removed by an administrator. Contact the administrator if you believe this was a mistake.',
                        'link' => SORMS_URL . 'src/org/request.php',
                    ]);
                }

                if (Database::execute(
                    "DELETE FROM organizations
                     WHERE id = :id AND verification_status != 'verified'",
                    ['id' => $organizationId]
                ) !== 1) {
                    throw new RuntimeException('Organization request could not be deleted.');
                }
            } elseif ($action === 'approve') {
                Database::execute(
                    "UPDATE organizations SET
                        status = 'active',
                        verification_status = 'verified',
                        verification_notes = :verification_notes,
                        verified_by = :verified_by,
                        verified_at = NOW(),
                        admin_user_id = :admin_user,
                        founder_user_id = :founder_user,
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = :id",
                    [
                        'verification_notes' => $notes !== '' ? $notes : null,
                        'verified_by' => $_SESSION['user_id'],
                        'admin_user' => $ownerId ?: null,
                        'founder_user' => $ownerId ?: null,
                        'id' => $organizationId,
                    ]
                );

                if ($ownerId > 0) {
                    Database::execute(
                        "UPDATE users SET role = 'recruiter' WHERE id = :id AND role = 'student'",
                        ['id' => $ownerId]
                    );

                    $notification = Database::getConnection()->prepare(
                        "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                         VALUES (:user_id, 'organization_verified', 'Organization Verified',
                                 :message, :link, 0)"
                    );
                    $notification->execute([
                        'user_id' => $ownerId,
                        'message' => $organization['name'] . ' has been verified. You can now create recruitment campaigns.',
                        'link' => SORMS_URL . 'src/campaign/create.php',
                    ]);
                }

                setFlash('success', 'Organization approved. The requester must sign out and back in before managing recruitment campaigns.');
            } else {
                Database::execute(
                    "UPDATE organizations SET
                        status = 'inactive',
                        verification_status = 'rejected',
                        verification_notes = :verification_notes,
                        verified_by = :verified_by,
                        verified_at = NOW(),
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = :id",
                    [
                        'verification_notes' => $notes,
                        'verified_by' => $_SESSION['user_id'],
                        'id' => $organizationId,
                    ]
                );

                if ($ownerId > 0) {
                    $notification = Database::getConnection()->prepare(
                        "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                         VALUES (:user_id, 'organization_rejected', 'Organization Request Rejected',
                                 :message, :link, 0)"
                    );
                    $notification->execute([
                        'user_id' => $ownerId,
                        'message' => $organization['name'] . ' was not verified. Reason: ' . $notes,
                        'link' => SORMS_URL . 'src/org/request.php',
                    ]);
                }

                setFlash('success', 'Organization request rejected and the requester has been notified.');
            }

            Database::commit();

            if ($action === 'delete') {
                $storageRoot = realpath(SORMS_ORG_DOCUMENTS_PATH);

                if ($storageRoot !== false) {
                    foreach (array_column($documents, 'stored_name') as $storedName) {
                        $filePath = realpath(
                            SORMS_ORG_DOCUMENTS_PATH . DIRECTORY_SEPARATOR . basename((string) $storedName)
                        );

                        if (
                            $filePath !== false
                            && strpos($filePath, $storageRoot . DIRECTORY_SEPARATOR) === 0
                            && is_file($filePath)
                            && !unlink($filePath)
                        ) {
                            error_log('Unable to remove organization document: ' . $filePath);
                        }
                    }
                }

                setFlash('success', 'Organization request and its uploaded papers have been removed.');
            }

            redirect('src/org/index.php');
        } catch (Throwable $e) {
            Database::rollBack();
            error_log('Organization review error: ' . $e->getMessage());
            $error = 'We could not save the review decision. Please try again.';
        }
    }
}

$statusLabels = [
    'unverified' => 'Not Submitted',
    'pending' => 'Pending Review',
    'verified' => 'Verified',
    'rejected' => 'Rejected',
];

$page_title = 'Review Organization';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Review Organization</h1>
        <p class="description">Verify the submitted papers before approving this recruitment platform</p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back to Organizations</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <h2 class="h4 mb-1"><?php echo htmlspecialchars($organization['name']); ?></h2>
                <p class="text-muted mb-0">
                    Requested by
                    <?php if (!empty($organization['requester_name'])): ?>
                        <?php echo htmlspecialchars($organization['requester_name']); ?>
                        (<?php echo htmlspecialchars($organization['requester_username']); ?>)
                    <?php else: ?>
                        an unknown user
                    <?php endif; ?>
                </p>
            </div>
            <span class="badge bg-<?php echo $organization['verification_status'] === 'verified' ? 'success' : ($organization['verification_status'] === 'pending' ? 'warning' : 'secondary'); ?>">
                <?php echo htmlspecialchars($statusLabels[$organization['verification_status']] ?? $organization['verification_status']); ?>
            </span>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-6">
                <p><strong>Established:</strong> <?php echo $organization['established_date'] ? formatDate($organization['established_date']) : 'Not set'; ?></p>
                <p><strong>Website:</strong> <?php echo htmlspecialchars($organization['website'] ?? 'Not set'); ?></p>
                <p><strong>Social Links:</strong> <?php echo htmlspecialchars($organization['social_link'] ?? 'Not set'); ?></p>
                <p class="mb-0"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($organization['description'] ?? '')); ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Submitted:</strong> <?php echo formatDateTime($organization['created_at']); ?></p>
                <p><strong>Last Updated:</strong> <?php echo formatDateTime($organization['updated_at']); ?></p>
                <?php if (!empty($organization['verified_at'])): ?>
                    <p><strong>Reviewed:</strong> <?php echo formatDateTime($organization['verified_at']); ?></p>
                <?php endif; ?>
                <?php if (!empty($organization['verification_notes'])): ?>
                    <p class="mb-0"><strong>Review Notes:</strong> <?php echo nl2br(htmlspecialchars($organization['verification_notes'])); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3>Verification Papers</h3>
    </div>
    <div class="card-body">
        <?php if (empty($documents)): ?>
            <p class="text-muted mb-0">No verification papers were uploaded.</p>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Document</th>
                            <th>Type</th>
                            <th>Size</th>
                            <th>Uploaded</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($documents as $document): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($document['original_name']); ?></td>
                            <td><?php echo htmlspecialchars($document['mime_type'] ?? 'Unknown'); ?></td>
                            <td><?php echo formatFileSize((int) $document['file_size']); ?></td>
                            <td><?php echo formatDateTime($document['created_at']); ?></td>
                            <td>
                                <a href="document.php?id=<?php echo (int) $document['id']; ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    Open
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($organization['verification_status'] !== 'verified'): ?>
<div class="card mt-4">
    <div class="card-header">
        <h3>Review Decision</h3>
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" name="id" value="<?php echo (int) $organization['id']; ?>">

            <div class="mb-3">
                <label class="form-label" for="verification_notes">Review Notes</label>
                <textarea class="form-control" id="verification_notes" name="verification_notes" rows="3" placeholder="Add a reason or remarks. Required when rejecting."></textarea>
            </div>

            <div class="btn-group">
                <button type="submit" name="action" value="approve" class="btn btn-success">Approve Organization</button>
                <button type="submit" name="action" value="reject" class="btn btn-danger">Reject Request</button>
                <button
                    type="submit"
                    name="action"
                    value="delete"
                    class="btn btn-outline-danger"
                    onclick="return confirm('Permanently remove this organization request and its uploaded papers?');"
                >Delete Request</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
