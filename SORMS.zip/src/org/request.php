<?php
/**
 * Organization Verification Request
 *
 * Lets a student request a recruitment platform (organization) for their
 * organization and upload the approved papers for admin review.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('student');

$userId = (int) $_SESSION['user_id'];

$existing = Database::fetch(
    'SELECT * FROM organizations
     WHERE requested_by = :requester_id OR founder_user_id = :founder_id
     ORDER BY id DESC LIMIT 1',
    ['requester_id' => $userId, 'founder_id' => $userId]
);

$documents = [];

if ($existing) {
    $documents = Database::query(
        'SELECT * FROM organization_documents WHERE organization_id = :organization_id ORDER BY created_at DESC',
        ['organization_id' => $existing['id']]
    );
}

$canSubmitForm = !$existing || $existing['verification_status'] === 'rejected';

$error = '';
$success = '';

$name = $existing['name'] ?? '';
$description = $existing['description'] ?? '';
$establishedDate = $existing['established_date'] ?? '';
$website = $existing['website'] ?? '';
$socialLink = $existing['social_link'] ?? '';
$colorTheme = $existing['color_theme'] ?? '#1a73e8';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canSubmitForm) {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $establishedDate = sanitize($_POST['established_date'] ?? '');
    $website = sanitize($_POST['website'] ?? '');
    $socialLink = sanitize($_POST['social_link'] ?? '');
    $colorTheme = sanitize($_POST['color_theme'] ?? '');

    $errors = [];

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    if (!validateString($name, 2, 150)) {
        $errors[] = 'Organization name must be between 2 and 150 characters.';
    } elseif (tableHasRows('organizations', ['name' => $name])) {
        $duplicate = Database::fetch(
            'SELECT id FROM organizations WHERE name = :name AND id != :id',
            ['name' => $name, 'id' => $existing['id'] ?? 0]
        );

        if ($duplicate) {
            $errors[] = 'An organization with this name already exists.';
        }
    }

    if ($establishedDate === '' || !validateDate($establishedDate)) {
        $errors[] = 'Please enter a valid establishment date.';
    }

    if ($website !== '' && !filter_var($website, FILTER_VALIDATE_URL)) {
        $errors[] = 'Please enter a valid website URL.';
    }

    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $colorTheme)) {
        $colorTheme = '#1a73e8';
    }

    // Normalize the multiple file input into a simple list
    $uploadedFiles = [];

    if (!empty($_FILES['documents']['name'])) {
        if (is_array($_FILES['documents']['name'])) {
            foreach ($_FILES['documents']['name'] as $index => $fileName) {
                $uploadedFiles[] = [
                    'name' => $fileName,
                    'tmp_name' => $_FILES['documents']['tmp_name'][$index] ?? '',
                    'error' => $_FILES['documents']['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                    'size' => $_FILES['documents']['size'][$index] ?? 0,
                ];
            }
        } else {
            $uploadedFiles[] = [
                'name' => $_FILES['documents']['name'],
                'tmp_name' => $_FILES['documents']['tmp_name'] ?? '',
                'error' => $_FILES['documents']['error'] ?? UPLOAD_ERR_NO_FILE,
                'size' => $_FILES['documents']['size'] ?? 0,
            ];
        }
    }

    $uploadedFiles = array_values(array_filter($uploadedFiles, static function (array $file): bool {
        return ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    }));

    if (!$existing && !$uploadedFiles) {
        $errors[] = 'Please upload at least one approved document for verification.';
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $validatedFiles = [];

    foreach ($uploadedFiles as $file) {
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            $errors[] = 'One of the uploaded files could not be processed.';
            continue;
        }

        if (!is_uploaded_file($file['tmp_name'])) {
            $errors[] = 'One of the uploaded files is not valid.';
            continue;
        }

        if ((int) $file['size'] > SORMS_MAX_DOCUMENT_SIZE) {
            $errors[] = htmlspecialchars($file['name']) . ' is larger than 5 MB.';
            continue;
        }

        $mimeType = $finfo->file($file['tmp_name']);

        if (!isset(SORMS_ALLOWED_DOCUMENT_TYPES[$mimeType])) {
            $errors[] = htmlspecialchars($file['name']) . ' must be a PDF, JPG, or PNG file.';
            continue;
        }

        $validatedFiles[] = [
            'name' => $file['name'],
            'tmp_name' => $file['tmp_name'],
            'size' => (int) $file['size'],
            'mime_type' => $mimeType,
            'extension' => SORMS_ALLOWED_DOCUMENT_TYPES[$mimeType],
        ];
    }

    if (!$errors) {
        if (!is_dir(SORMS_ORG_DOCUMENTS_PATH)) {
            @mkdir(SORMS_ORG_DOCUMENTS_PATH, 0775, true);
        }

        if (!is_dir(SORMS_ORG_DOCUMENTS_PATH) || !is_writable(SORMS_ORG_DOCUMENTS_PATH)) {
            $errors[] = 'The document storage folder is not writable. Please contact the administrator.';
        }
    }

    if (!$errors) {
        $movedFiles = [];

        try {
            Database::beginTransaction();

            if ($existing) {
                Database::execute(
                    "UPDATE organizations SET
                        name = :name,
                        description = :description,
                        established_date = :established_date,
                        website = :website,
                        social_link = :social_link,
                        color_theme = :color_theme,
                        status = 'pending',
                        verification_status = 'pending',
                        verification_notes = NULL,
                        verified_by = NULL,
                        verified_at = NULL,
                        requested_by = :requested_by,
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = :id",
                    [
                        'name' => $name,
                        'description' => $description,
                        'established_date' => $establishedDate,
                        'website' => $website !== '' ? $website : null,
                        'social_link' => $socialLink !== '' ? $socialLink : null,
                        'color_theme' => $colorTheme,
                        'requested_by' => $userId,
                        'id' => $existing['id'],
                    ]
                );

                $organizationId = (int) $existing['id'];
            } else {
                Database::execute(
                    "INSERT INTO organizations
                        (name, description, established_date, website, social_link, color_theme,
                         status, verification_status, founder_user_id, requested_by)
                     VALUES
                        (:name, :description, :established_date, :website, :social_link, :color_theme,
                         'pending', 'pending', :founder_id, :requested_by)",
                    [
                        'name' => $name,
                        'description' => $description,
                        'established_date' => $establishedDate,
                        'website' => $website !== '' ? $website : null,
                        'social_link' => $socialLink !== '' ? $socialLink : null,
                        'color_theme' => $colorTheme,
                        'founder_id' => $userId,
                        'requested_by' => $userId,
                    ]
                );

                $organizationId = Database::getLastInsertId();
            }

            foreach ($validatedFiles as $file) {
                $storedName = bin2hex(random_bytes(16)) . '.' . $file['extension'];
                $destination = SORMS_ORG_DOCUMENTS_PATH . DIRECTORY_SEPARATOR . $storedName;

                if (!move_uploaded_file($file['tmp_name'], $destination)) {
                    throw new RuntimeException('Unable to store an uploaded document.');
                }

                $movedFiles[] = $destination;

                Database::execute(
                    "INSERT INTO organization_documents
                        (organization_id, uploaded_by, original_name, stored_name, mime_type, file_size)
                     VALUES
                        (:organization_id, :uploaded_by, :original_name, :stored_name, :mime_type, :file_size)",
                    [
                        'organization_id' => $organizationId,
                        'uploaded_by' => $userId,
                        'original_name' => mb_substr($file['name'], 0, 255),
                        'stored_name' => $storedName,
                        'mime_type' => $file['mime_type'],
                        'file_size' => $file['size'],
                    ]
                );
            }

            $notifyAdmins = Database::getConnection()->prepare(
                "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                 SELECT id, 'organization_request', 'New Organization Verification Request',
                        CONCAT(:organization_name, ' submitted approved papers for verification.'),
                        :link, 0
                 FROM users
                 WHERE role = 'admin' AND status = 'active'"
            );
            $notifyAdmins->execute([
                'organization_name' => $name,
                'link' => SORMS_URL . 'src/org/review.php?id=' . $organizationId,
            ]);

            Database::commit();

            setFlash('success', 'Your organization request has been submitted. An administrator will review your papers.');
            redirect('src/org/request.php');
        } catch (Throwable $e) {
            Database::rollBack();

            foreach ($movedFiles as $path) {
                @unlink($path);
            }

            error_log('Organization request error: ' . $e->getMessage());
            $errors[] = 'We could not submit your request right now. Please try again.';
        }
    }

    if ($errors) {
        $error = implode(PHP_EOL, $errors);
    }
}

$verificationLabels = [
    'unverified' => 'Not submitted',
    'pending' => 'Under Review',
    'verified' => 'Verified',
    'rejected' => 'Rejected',
];

$page_title = 'Organization Request';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Organization Request</h1>
        <p class="description">Create a recruitment platform for your student organization</p>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo nl2br(htmlspecialchars($error, ENT_QUOTES, 'UTF-8')); ?>
    </div>
<?php endif; ?>

<?php if ($existing && !$canSubmitForm): ?>
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div>
                    <h2 class="h4 mb-1"><?php echo htmlspecialchars($existing['name']); ?></h2>
                    <p class="text-muted mb-0">Submitted <?php echo formatDateTime($existing['created_at']); ?></p>
                </div>
                <span class="badge bg-<?php echo $existing['verification_status'] === 'verified' ? 'success' : ($existing['verification_status'] === 'pending' ? 'warning' : 'secondary'); ?>">
                    <?php echo htmlspecialchars($verificationLabels[$existing['verification_status']] ?? $existing['verification_status']); ?>
                </span>
            </div>

            <?php if ($existing['verification_status'] === 'pending'): ?>
                <div class="alert alert-info mt-3 mb-0">
                    Your papers are being reviewed by an administrator. You will be notified once a decision is made.
                </div>
            <?php elseif ($existing['verification_status'] === 'verified'): ?>
                <div class="alert alert-success mt-3 mb-0">
                    Your organization is verified. You can now create and manage recruitment campaigns.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3>Organization Details</h3>
        </div>
        <div class="card-body">
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($existing['description'] ?? '')); ?></p>
            <p><strong>Established:</strong> <?php echo $existing['established_date'] ? formatDate($existing['established_date']) : 'Not set'; ?></p>
            <p><strong>Website:</strong> <?php echo htmlspecialchars($existing['website'] ?? 'Not set'); ?></p>
            <p class="mb-0"><strong>Social Links:</strong> <?php echo htmlspecialchars($existing['social_link'] ?? 'Not set'); ?></p>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3>Submitted Papers</h3>
        </div>
        <div class="card-body">
            <?php if (empty($documents)): ?>
                <p class="text-muted mb-0">No documents were uploaded.</p>
            <?php else: ?>
                <ul class="list-unstyled mb-0">
                    <?php foreach ($documents as $document): ?>
                        <li class="mb-2">
                            <a href="document.php?id=<?php echo (int) $document['id']; ?>" target="_blank" class="text-decoration-none">
                                <?php echo htmlspecialchars($document['original_name']); ?>
                            </a>
                            <small class="text-muted">(<?php echo formatFileSize((int) $document['file_size']); ?>)</small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php if ($canSubmitForm): ?>
    <?php if ($existing && $existing['verification_status'] === 'rejected'): ?>
        <div class="alert alert-warning" role="alert">
            <strong>Your previous request was rejected.</strong>
            <?php if (!empty($existing['verification_notes'])): ?>
                <br><?php echo nl2br(htmlspecialchars($existing['verification_notes'])); ?>
            <?php endif; ?>
            <br>You can correct the details and submit new papers below.
        </div>
    <?php endif; ?>

    <div class="form-section">
        <h2><?php echo $existing ? 'Resubmit Organization Request' : 'Create Organization Request'; ?></h2>
        <p class="sub">Upload the approved papers of your organization so an administrator can verify it.</p>

        <form method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="name">Organization Name *</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="established_date">Established Date *</label>
                    <input type="date" class="form-control" id="established_date" name="established_date" value="<?php echo htmlspecialchars($establishedDate); ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="description">Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" placeholder="Describe the organization, its purpose, and activities"><?php echo htmlspecialchars($description); ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="website">Website</label>
                    <input type="url" class="form-control" id="website" name="website" value="<?php echo htmlspecialchars($website); ?>" placeholder="https://example.com">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="color_theme">Color Theme</label>
                    <input type="color" class="form-control form-control-color" id="color_theme" name="color_theme" value="<?php echo htmlspecialchars($colorTheme); ?>">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="social_link">Social Media Links <span class="text-muted">(comma separated)</span></label>
                <input type="text" class="form-control" id="social_link" name="social_link" value="<?php echo htmlspecialchars($socialLink); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label" for="documents">
                    Approved Papers <?php echo $existing ? '' : '*'; ?>
                </label>
                <input type="file" class="form-control" id="documents" name="documents[]" accept=".pdf,.jpg,.jpeg,.png" multiple <?php echo $existing ? '' : 'required'; ?>>
                <div class="form-text">PDF, JPG, or PNG. Maximum 5 MB per file. You can upload more than one file.</div>
            </div>

            <?php if (!empty($documents)): ?>
                <div class="mb-3">
                    <p class="mb-1"><strong>Previously uploaded papers</strong></p>
                    <ul class="list-unstyled mb-0">
                        <?php foreach ($documents as $document): ?>
                            <li>
                                <a href="document.php?id=<?php echo (int) $document['id']; ?>" target="_blank">
                                    <?php echo htmlspecialchars($document['original_name']); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg">Submit for Verification</button>
            </div>
        </form>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
