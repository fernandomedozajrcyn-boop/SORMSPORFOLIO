<?php
/**
 * Campaign Listing Page
 *
 * Lists all recruitment campaigns with filtering by organization and status.
 * Recruiters can create campaigns; all users can view active campaigns.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = 'Recruitment Campaigns';

// Determine organization filter
$orgFilter = $_GET['org_id'] ?? null;

// Organizations available in the filter and for campaign creation
$organizations = [];
if (userHasRole('admin')) {
    $organizations = Database::query("SELECT id, name FROM organizations ORDER BY name");
} elseif (userHasRole('recruiter')) {
    $organizations = getManageableOrganizations(false);
}

$allowedOrgIds = array_map('intval', array_column($organizations, 'id'));

// If orgFilter is set and user is recruiter/admin, validate against allowed organizations
$validOrgFilter = null;
if ($orgFilter) {
    if (userHasRole(['admin', 'recruiter'])) {
        if (in_array((int) $orgFilter, $allowedOrgIds, true)) {
            $validOrgFilter = (int) $orgFilter;
        } else {
            $orgFilter = null;
        }
    }
}

// Fetch campaigns
$campaignConditions = [];
$campaignParams = [];

if ($validOrgFilter) {
    $campaignConditions[] = 'c.organization_id = :org_id';
    $campaignParams[':org_id'] = $validOrgFilter;
}

$campaignConditions[] = 'c.status != "draft"';

$sql = "SELECT c.*, o.name as org_name, o.color_theme as org_color_theme
        FROM campaigns c
        JOIN organizations o ON c.organization_id = o.id
        WHERE " . implode(' AND ', $campaignConditions) . "
        ORDER BY c.recruitment_start DESC";

$campaigns = Database::query($sql, $campaignParams);

// Count pending applications for display
$countSql = "SELECT COUNT(*) as total FROM applications WHERE status NOT IN ('approved', 'rejected', 'withdrawn')";
$countResult = Database::fetch($countSql);
$totalPending = $countResult['total'];

ob_start();
?>
<div class="page-header">
    <div>
        <h1>Recruitment Campaigns</h1>
        <p class="description">View and manage recruitment campaigns and applications</p>
    </div>
    <?php if (userHasRole(['admin', 'recruiter']) && !empty($organizations)): ?>
    <div>
        <form method="GET" action="" class="d-flex gap-2">
            <label for="org_id" class="me-1">Filter by Organization:</label>
            <select name="org_id" id="org_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Organizations</option>
                <?php foreach ($organizations as $org): ?>
                    <option value="<?php echo $org['id']; ?>" <?php echo $orgFilter == $org['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($org['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
    <?php endif; ?>
    <?php if (userHasRole(['admin', 'recruiter']) && !empty($organizations)): ?>
    <div>
        <a href="create.php" class="btn btn-primary">New Campaign</a>
    </div>
    <?php endif; ?>
</div>

<?php if (empty($campaigns)): ?>
    <div class="empty-state">
        <div class="icon">📋</div>
        <h4>No campaigns found</h4>
        <?php if (userHasRole('admin')): ?>
            <p>There are no active campaigns available. <a href="create.php">Create a new campaign</a> to get started.</p>
        <?php elseif (userHasRole('recruiter') && !empty($organizations)): ?>
            <p>There are no active campaigns available. <a href="create.php">Create a new campaign</a> for your organization.</p>
        <?php else: ?>
            <p>There are no active campaigns available right now. Please check back later.</p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="table-wrapper">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Campaign</th>
                    <th>Organization</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Positions</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($campaigns as $campaign): ?>
                <tr>
                    <td>
                        <a href="view.php?id=<?php echo $campaign['id']; ?>" class="text-decoration-none fw-semibold">
                            <?php echo htmlspecialchars($campaign['title']); ?>
                        </a>
                    </td>
                    <td><?php echo htmlspecialchars($campaign['org_name']); ?></td>
                    <td><?php echo formatDate($campaign['recruitment_start']); ?></td>
                    <td><?php echo formatDate($campaign['recruitment_end']); ?></td>
                    <td><?php echo (int)$campaign['total_positions']; ?></td>
                    <td>
                        <span class="badge bg-<?php echo $campaign['status'] === 'open' ? 'success' : ($campaign['status'] === 'closed' ? 'warning' : 'secondary'); ?>">
                            <?php echo campaignStatusLabel($campaign['status']); ?>
                        </span>
                    </td>
                    <td>
                        <div class="btn-group">
                            <a href="view.php?id=<?php echo $campaign['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                            <?php if (canManageCampaign($campaign)): ?>
                            <a href="edit.php?id=<?php echo $campaign['id']; ?>" class="btn btn-sm btn-outline-info">Edit</a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
