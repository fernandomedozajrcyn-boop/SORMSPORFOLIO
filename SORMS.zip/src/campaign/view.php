<?php
/**
 * Campaign View Page
 *
 * Allows users to view campaign details and the list of applicants.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    setFlash('error', 'Campaign ID is required.');
    redirect('src/campaign/index.php');
}

$campaign = Database::fetch('SELECT c.*, o.name as org_name, o.color_theme as org_color_theme, o.logo, o.cover_image, o.description as org_description
                            FROM campaigns c
                            JOIN organizations o ON c.organization_id = o.id
                            WHERE c.id = :id', ['id' => $id]);

if (!$campaign) {
    setFlash('error', 'Campaign not found.');
    redirect('src/campaign/index.php');
}

// Check if the campaign is currently open for applications
$isOpen = isCampaignOpen($campaign);
$isInScreening = isCampaignInScreening($campaign);
$isPast = isCampaignPast($campaign);
$canManage = isLoggedIn() && canManageCampaign($campaign);

// Fetch applicants for this campaign
$applications = Database::query(
    "SELECT a.*, app.full_name as applicant_name, app.email, app.phone, app.gender, app.date_of_birth, u.role as applicant_role
     FROM applications a
     JOIN applicants app ON a.applicant_id = app.id
     JOIN users u ON app.user_id = u.id
     WHERE a.campaign_id = :campaign_id
     ORDER BY a.applied_at DESC",
    ['campaign_id' => $id]
);

// Count applications by status
$statusCounts = [];
foreach ($applications as $app) {
    $status = $app['status'];
    $statusCounts[$status] = ($statusCounts[$status] ?? 0) + 1;
}

// Total applicants
$totalApplicants = count($applications);

$page_title = 'Campaign Details';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Campaign Details</h1>
        <p class="description">View details for <?php echo htmlspecialchars($campaign['title']); ?> by <?php echo htmlspecialchars($campaign['org_name']); ?></p>
    </div>
    <div>
        <?php if ($isOpen && !isLoggedIn()): ?>
            <a href="<?php echo SORMS_URL; ?>src/auth/login.php" class="btn btn-success">Sign In to Apply</a>
        <?php elseif ($isOpen && userHasRole('student')): ?>
            <a href="apply.php?id=<?php echo $campaign['id']; ?>" class="btn btn-success">Apply Now</a>
        <?php elseif ($canManage): ?>
            <a href="manage.php?campaign_id=<?php echo $campaign['id']; ?>" class="btn btn-primary">Manage Screening</a>
        <?php elseif ($isPast): ?>
            <span class="badge bg-danger">Campaign Closed</span>
        <?php else: ?>
            <span class="badge bg-secondary">Not accepting applications</span>
        <?php endif; ?>
    </div>
</div>

<?php if ($isPast && $totalApplicants === 0): ?>
    <div class="empty-state">
        <div class="icon">📋</div>
        <h4>No active applicants</h4>
        <p>This campaign has closed. <a href="index.php">View all campaigns</a></p>
    </div>
<?php endif; ?>

<?php if (!$isPast): ?>
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Campaign Information</h3>
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Organization:</strong> <?php echo htmlspecialchars($campaign['org_name']); ?></p>
                    <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($campaign['description'] ?? '')); ?></p>
                    <p><strong>Eligibility Criteria:</strong> <?php echo $campaign['eligibility_criteria'] ? nl2br(htmlspecialchars($campaign['eligibility_criteria'])) : '<span class="text-muted">Not specified</span>'; ?></p>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3">
                        <div class="text-center">
                            <div class="badge bg-success"><?php echo (int)$campaign['total_positions']; ?> Positions</div>
                            <p class="mb-0 mt-2"><?php echo formatDate($campaign['recruitment_start']); ?> - <?php echo formatDate($campaign['recruitment_end']); ?></p>
                        </div>
                        <div class="text-center">
                            <span class="badge bg-<?php echo $isOpen ? 'success' : ($isInScreening ? 'info' : 'secondary'); ?>">
                                <?php if ($isOpen): ?>Currently Open<?php elseif ($isInScreening): ?>Screening<?php else: ?>Closed<?php endif; ?></span>
                            <p class="mb-0 mt-2"><?php echo $isOpen ? 'Open for applications' : 'No longer accepting applications'; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3>Application Statistics</h3>
        </div>
        <div class="card-body">
            <div class="row text-center">
                <div class="col-6 col-md-3">
                    <div class="stat-card">
                        <div class="icon">👥</div>
                        <div class="number"><?php echo $totalApplicants; ?></div>
                        <div class="label">Total Applicants</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card">
                        <div class="icon">✅</div>
                        <div class="number"><?php echo $statusCounts['approved'] ?? 0; ?></div>
                        <div class="label">Approved</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card">
                        <div class="icon">⏳</div>
                        <div class="number"><?php echo $statusCounts['reviewing'] ?? 0; ?></div>
                        <div class="label">Under Review</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card">
                        <div class="icon">📝</div>
                        <div class="number"><?php echo $statusCounts['applied'] ?? 0; ?></div>
                        <div class="label">Applied</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info">
        This campaign has closed. You can no longer apply.
    </div>
<?php endif; ?>

<?php if ($canManage && $totalApplicants > 0): ?>
    <div class="card mt-4">
        <div class="card-header">
            Applicants (<?php echo $totalApplicants; ?>)
        </div>
        <div class="card-body">
            <div class="table-wrapper">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Applicant</th>
                            <th>Contact</th>
                            <th>Applied</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $index => $app): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo htmlspecialchars($app['applicant_name']); ?></td>
                            <td><?php echo htmlspecialchars($app['email']); ?><br><small class="text-muted"><?php echo htmlspecialchars($app['phone'] ?? ''); ?></small></td>
                            <td><?php echo formatDateTime($app['applied_at']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo applicationStatusColor($app['status']); ?>">
                                    <?php echo applicationStatusLabel($app['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <?php if (userHasRole(['admin', 'recruiter'])): ?>
                                        <a href="manage.php?application_id=<?php echo $app['id']; ?>&campaign_id=<?php echo $campaign['id']; ?>" class="btn btn-sm btn-outline-primary">Review</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
