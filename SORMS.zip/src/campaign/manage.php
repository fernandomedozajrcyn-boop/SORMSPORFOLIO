<?php
/**
 * Campaign Management Page (Screening)
 *
 * Allows recruiters to manage screening, review, and approve/reject applications.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$campaign_id = $_GET['campaign_id'] ?? $_POST['campaign_id'] ?? null;
$application_id = $_POST['application_id'] ?? null;
$action = $_POST['action'] ?? null;

if (!$campaign_id) {
    setFlash('error', 'Campaign ID is required.');
    redirect('src/campaign/index.php');
}

$campaign = Database::fetch(
    'SELECT c.*, o.name as org_name FROM campaigns c JOIN organizations o ON c.organization_id = o.id WHERE c.id = :id',
    ['id' => $campaign_id]
);

if (!$campaign) {
    setFlash('error', 'Campaign not found.');
    redirect('src/campaign/index.php');
}

if (!canManageCampaign($campaign)) {
    setFlash('error', 'You do not have permission to manage this campaign.');
    redirect('src/campaign/index.php');
}

$org = Database::fetch('SELECT * FROM organizations WHERE id = :id', ['id' => $campaign['organization_id']]);

if ($action !== null && !verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    setFlash('error', 'Your session expired. Please try again.');
    redirect('src/campaign/manage.php?campaign_id=' . (int) $campaign_id);
}

if ($action === 'approve' && $application_id) {
    $app = Database::fetch('SELECT * FROM applications WHERE id = :id AND campaign_id = :campaign_id', ['id' => $application_id, 'campaign_id' => $campaign_id]);

    if ($app) {
        $applicant = Database::fetch('SELECT * FROM applicants WHERE id = :id', ['id' => $app['applicant_id']]);

        // Update application status
        $stmt = Database::getConnection()->prepare(
            "UPDATE applications SET status = 'approved', reviewed_at = NOW(), reviewed_by = :reviewer WHERE id = :id"
        );
        $stmt->execute([
            ':id' => $application_id,
            ':reviewer' => $_SESSION['user_id'],
        ]);

        // Create notification
        $notif = Database::getConnection()->prepare(
            "INSERT INTO notifications (user_id, type, title, message, link, is_read)
             VALUES (:student_id, 'application_approved', 'Your Application Approved!',
                     :message, :link, 0)"
        );
        $notif->execute([
            ':student_id' => $applicant['user_id'],
            ':message' => 'Congratulations! Your application to ' . $campaign['org_name'] . ' has been approved.',
            ':link' => SORMS_URL . 'src/applicant/index.php',
        ]);

        // Update positions remaining, but only when the application was not approved before
        if ($app['status'] !== 'approved') {
            $upd = Database::getConnection()->prepare(
                "UPDATE campaigns SET positions_remaining = GREATEST(positions_remaining - 1, 0) WHERE id = :id"
            );
            $upd->execute([':id' => $campaign_id]);
        }

        // Track the status change
        Database::execute(
            "INSERT INTO application_history (application_id, changed_by, old_status, new_status, note)
             VALUES (:application_id, :changed_by, :old_status, 'approved', :note)",
            [
                ':application_id' => $application_id,
                ':changed_by' => $_SESSION['user_id'],
                ':old_status' => $app['status'],
                ':note' => 'Application approved from the screening dashboard.',
            ]
        );

        setFlash('success', 'Application approved successfully!');
    } else {
        setFlash('error', 'Application not found.');
    }
} elseif ($action === 'reject' && $application_id) {
    $app = Database::fetch('SELECT * FROM applications WHERE id = :id AND campaign_id = :campaign_id', ['id' => $application_id, 'campaign_id' => $campaign_id]);

    if ($app) {
        $applicant = Database::fetch('SELECT * FROM applicants WHERE id = :id', ['id' => $app['applicant_id']]);

        // Update application status
        $stmt = Database::getConnection()->prepare(
            "UPDATE applications SET status = 'rejected', reviewed_at = NOW(), reviewed_by = :reviewer WHERE id = :id"
        );
        $stmt->execute([
            ':id' => $application_id,
            ':reviewer' => $_SESSION['user_id'],
        ]);

        // Create notification
        $notif = Database::getConnection()->prepare(
            "INSERT INTO notifications (user_id, type, title, message, link, is_read)
             VALUES (:student_id, 'application_rejected', 'Application Review Result',
                     :message, :link, 0)"
        );
        $notif->execute([
            ':student_id' => $applicant['user_id'],
            ':message' => 'Your application to ' . $campaign['org_name'] . ' has been reviewed. Unfortunately, you were not selected for this round.',
            ':link' => SORMS_URL . 'src/applicant/index.php',
        ]);

        // Give the position back when a previously approved application is rejected
        if ($app['status'] === 'approved') {
            $upd = Database::getConnection()->prepare(
                "UPDATE campaigns SET positions_remaining = LEAST(positions_remaining + 1, total_positions) WHERE id = :id"
            );
            $upd->execute([':id' => $campaign_id]);
        }

        Database::execute(
            "INSERT INTO application_history (application_id, changed_by, old_status, new_status, note)
             VALUES (:application_id, :changed_by, :old_status, 'rejected', :note)",
            [
                ':application_id' => $application_id,
                ':changed_by' => $_SESSION['user_id'],
                ':old_status' => $app['status'],
                ':note' => 'Application rejected from the screening dashboard.',
            ]
        );

        setFlash('success', 'Application rejected successfully!');
    } else {
        setFlash('error', 'Application not found.');
    }
} elseif ($action === 'withdraw' && $application_id) {
    $app = Database::fetch('SELECT * FROM applications WHERE id = :id AND campaign_id = :campaign_id', ['id' => $application_id, 'campaign_id' => $campaign_id]);

    if ($app) {
        // Update application status
        $stmt = Database::getConnection()->prepare(
            "UPDATE applications SET status = 'withdrawn', reviewed_at = NOW() WHERE id = :id"
        );
        $stmt->execute([':id' => $application_id]);

        Database::execute(
            "INSERT INTO application_history (application_id, changed_by, old_status, new_status, note)
             VALUES (:application_id, :changed_by, :old_status, 'withdrawn', :note)",
            [
                ':application_id' => $application_id,
                ':changed_by' => $_SESSION['user_id'],
                ':old_status' => $app['status'],
                ':note' => 'Application withdrawn.',
            ]
        );

        setFlash('success', 'Application withdrawn successfully!');
    } else {
        setFlash('error', 'Application not found.');
    }
}

// Get all applicants for this campaign
$applications = Database::query(
    "SELECT a.*, app.full_name as applicant_name, app.email, app.phone, app.gender, app.date_of_birth, app.address
     FROM applications a
     JOIN applicants app ON a.applicant_id = app.id
     WHERE a.campaign_id = :campaign_id
     ORDER BY a.applied_at DESC",
    ['campaign_id' => $campaign_id]
);

$page_title = 'Screening Dashboard - ' . $campaign['title'];
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Screening Dashboard</h1>
        <p class="description">Manage applications for <?php echo htmlspecialchars($campaign['title']); ?></p>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Organization:</strong> <?php echo htmlspecialchars($org['name'] ?? $campaign['org_name']); ?></p>
                <p><strong>Campaign:</strong> <?php echo htmlspecialchars($campaign['title']); ?></p>
                <p><strong>Positions:</strong> <?php echo (int)$campaign['total_positions']; ?> (Remaining: <?php echo (int)$campaign['positions_remaining']; ?>)</p>
                <p><strong>Start Date:</strong> <?php echo formatDate($campaign['recruitment_start']); ?></p>
                <p><strong>End Date:</strong> <?php echo formatDate($campaign['recruitment_end']); ?></p>
            </div>
            <div class="col-md-6">
                <div class="text-center p-3 bg-light rounded">
                    <div class="h1 mb-0"><?php echo count($applications); ?></div>
                    <div class="small text-muted">Total Applicants</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3>Applicants List</h3>
    </div>
    <div class="card-body">
        <?php if (empty($applications)): ?>
            <div class="empty-state">
                <div class="icon">📝</div>
                <h4>No applicants yet</h4>
                <p>No applications have been received for this campaign.</p>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Applicant</th>
                            <th>Contact</th>
                            <th>Applied</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $index => $app): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($app['applicant_name']); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars($app['email']); ?></small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($app['phone'] ?? ''); ?><br>
                                <small class="text-muted"><?php echo htmlspecialchars($app['address'] ?? ''); ?></small>
                            </td>
                            <td><?php echo formatDateTime($app['applied_at']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo applicationStatusColor($app['status']); ?>">
                                    <?php echo applicationStatusLabel($app['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <?php if ($app['status'] === 'applied' || $app['status'] === 'reviewing' || $app['status'] === 'shortlisted'): ?>
                                    <form method="POST" action="manage.php?campaign_id=<?php echo (int) $campaign_id; ?>" class="btn-group">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                        <input type="hidden" name="application_id" value="<?php echo (int) $app['id']; ?>">
                                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
                                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                                    </form>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Final Decision</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
