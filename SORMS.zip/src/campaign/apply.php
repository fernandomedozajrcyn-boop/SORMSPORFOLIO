<?php
/**
 * Campaign Apply Page
 *
 * Allows students to apply to a recruitment campaign.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('student');
requireLogin();

$id = $_GET['id'] ?? null;

if (!$id) {
    setFlash('error', 'Campaign ID is required.');
    redirect('src/campaign/index.php');
}

$campaign = Database::fetch('SELECT * FROM campaigns WHERE id = :id', ['id' => $id]);

if (!$campaign) {
    setFlash('error', 'Campaign not found.');
    redirect('src/campaign/index.php');
}

$isOpen = isCampaignOpen($campaign);
$isPast = isCampaignPast($campaign);

if ($isPast || !$isOpen) {
    setFlash('error', 'This campaign is not currently accepting applications.');
    redirect('src/campaign/index.php');
}

// Check if user already applied
$applicant = Database::fetch('SELECT * FROM applicants WHERE user_id = :user_id', ['user_id' => $_SESSION['user_id']]);

if (!$applicant) {
    setFlash('error', 'Please complete your applicant profile before applying.');
    redirect('src/applicant/profile.php');
}

// Check if already applied
$existing = Database::fetch(
    'SELECT id FROM applications WHERE applicant_id = :applicant_id AND campaign_id = :campaign_id',
    ['applicant_id' => $applicant['id'], 'campaign_id' => $id]
);

if ($existing) {
    setFlash('error', 'You have already applied to this campaign.');
    redirect('src/campaign/view.php?id=' . $id);
}

// Get organization for display
$organization = Database::fetch('SELECT name FROM organizations WHERE id = :id', ['id' => $campaign['organization_id']]);

$error = '';
$success = '';
$motivation_letter = '';
$additional_info = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motivation_letter = sanitize($_POST['motivation_letter'] ?? '');
    $additional_info = sanitize($_POST['additional_info'] ?? '');

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (empty($motivation_letter)) {
        $error = 'Please write a motivation letter.';
    } elseif (!validateString($motivation_letter, 20, 5000)) {
        $error = 'Your motivation letter must be between 20 and 5000 characters.';
    } else {
        try {
            $stmt = Database::getConnection()->prepare(
                "INSERT INTO applications (applicant_id, campaign_id, status, motivation_letter, additional_info, applied_at)
                 VALUES (:applicant_id, :campaign_id, 'applied', :motivation_letter, :additional_info, NOW())"
            );

            $stmt->execute([
                ':applicant_id' => $applicant['id'],
                ':campaign_id' => $id,
                ':motivation_letter' => $motivation_letter,
                ':additional_info' => $additional_info,
            ]);

            $applicationId = Database::getLastInsertId();

            // Notify the administrators and recruiters of the organization
            $notif = Database::getConnection()->prepare(
                "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                 SELECT u.id, 'application_received', 'New Application',
                        CONCAT(:applicant_name, ' has applied for your campaign.'),
                        :link, 0
                 FROM users u
                 WHERE u.role IN ('admin', 'recruiter') AND u.status = 'active'"
            );
            $notif->execute([
                ':applicant_name' => $applicant['full_name'],
                ':link' => SORMS_URL . 'src/campaign/manage.php?campaign_id=' . $id . '&application_id=' . $applicationId,
            ]);

            // Notify the applicant
            $ownNotif = Database::getConnection()->prepare(
                "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                 VALUES (:user_id, 'application_updated', 'Application Submitted',
                         :message, :link, 0)"
            );
            $ownNotif->execute([
                ':user_id' => $applicant['user_id'],
                ':message' => 'Your application for ' . $campaign['title'] . ' has been submitted successfully.',
                ':link' => SORMS_URL . 'src/applicant/index.php',
            ]);

            $success = 'Your application has been submitted successfully!';
            $motivation_letter = '';
            $additional_info = '';
        } catch (PDOException $e) {
            error_log('Apply error: ' . $e->getMessage());
            $error = 'Failed to submit application. Please try again.';
        }
    }
}

$page_title = 'Apply - ' . $campaign['title'];
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Apply to Campaign</h1>
        <p class="description">Apply for: <?php echo htmlspecialchars($campaign['title']); ?></p>
    </div>
    <a href="view.php?id=<?php echo $campaign['id']; ?>" class="btn btn-outline-secondary">Back to Campaign</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" role="alert">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<div class="form-section">
    <h2>Application Form</h2>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="mb-3">
            <label class="form-label" for="motivation_letter">Motivation Letter *</label>
            <textarea
                class="form-control"
                id="motivation_letter"
                name="motivation_letter"
                rows="6"
                required
                placeholder="Tell us why you want to join this organization, your relevant skills, and what you hope to contribute..."
            ><?php echo htmlspecialchars($motivation_letter); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label" for="additional_info">Additional Information <span class="text-muted">(Optional)</span></label>
            <textarea
                class="form-control"
                id="additional_info"
                name="additional_info"
                rows="4"
                placeholder="Any additional information, such as relevant experience, portfolio links, or special circumstances..."
            ><?php echo htmlspecialchars($additional_info); ?></textarea>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-success btn-lg">Submit Application</button>
            <a href="view.php?id=<?php echo $campaign['id']; ?>" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
