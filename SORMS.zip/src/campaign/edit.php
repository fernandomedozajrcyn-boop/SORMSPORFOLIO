<?php
/**
 * Campaign Edit Page
 *
 * Allows admins and verified recruiters to edit an existing campaign.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$error = '';
$success = '';
$id = $_GET['id'] ?? null;

if (!$id) {
    setFlash('error', 'Campaign ID is required.');
    redirect('src/campaign/index.php');
}

$campaign = Database::fetch(
    'SELECT c.*, o.name as org_name FROM campaigns c JOIN organizations o ON c.organization_id = o.id WHERE c.id = :id',
    ['id' => $id]
);

if (!$campaign) {
    setFlash('error', 'Campaign not found.');
    redirect('src/campaign/index.php');
}

if (!canManageCampaign($campaign)) {
    setFlash('error', 'You do not have permission to manage this campaign.');
    redirect('src/campaign/index.php');
}

// Pre-fill form with existing data
$title = $campaign['title'];
$description = $campaign['description'] ?? '';
$eligibility_criteria = $campaign['eligibility_criteria'] ?? '';
$recruitment_start = $campaign['recruitment_start'];
$recruitment_end = $campaign['recruitment_end'];
$screening_start = $campaign['screening_start'] ?? '';
$screening_end = $campaign['screening_end'] ?? '';
$total_positions = $campaign['total_positions'];
$featured = $campaign['featured'] ? true : false;
$priority = $campaign['priority'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $eligibility_criteria = sanitize($_POST['eligibility_criteria'] ?? '');
    $recruitment_start = $_POST['recruitment_start'] ?? '';
    $recruitment_end = $_POST['recruitment_end'] ?? '';
    $screening_start = $_POST['screening_start'] ?? '';
    $screening_end = $_POST['screening_end'] ?? '';
    $total_positions = (int)($_POST['total_positions'] ?? 1);
    $featured = isset($_POST['featured']) ? 1 : 0;
    $priority = (int)($_POST['priority'] ?? 0);

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (empty($title)) {
        $error = 'Campaign title is required.';
    } elseif (!validateString($title, 3, 200)) {
        $error = 'Campaign title must be between 3 and 200 characters.';
    } elseif (empty($recruitment_start)) {
        $error = 'Recruitment start date is required.';
    } elseif (empty($recruitment_end)) {
        $error = 'Recruitment end date is required.';
    } elseif ($recruitment_start > $recruitment_end) {
        $error = 'Recruitment end date must be after the start date.';
    } elseif (empty($total_positions) || $total_positions < 1) {
        $error = 'Total positions must be at least 1.';
    }

    if (empty($error)) {
        $sql = "UPDATE campaigns SET
                title = :title,
                description = :description,
                eligibility_criteria = :eligibility_criteria,
                recruitment_start = :recruitment_start,
                recruitment_end = :recruitment_end,
                screening_start = :screening_start,
                screening_end = :screening_end,
                total_positions = :total_positions,
                positions_remaining = :total_positions,
                featured = :featured,
                priority = :priority,
                updated_at = CURRENT_TIMESTAMP
                WHERE id = :id";

        $stmt = Database::getConnection()->prepare($sql);

        try {
            $stmt->execute([
                ':title' => $title,
                ':description' => $description,
                ':eligibility_criteria' => $eligibility_criteria,
                ':recruitment_start' => $recruitment_start,
                ':recruitment_end' => $recruitment_end,
                ':screening_start' => $screening_start ?: null,
                ':screening_end' => $screening_end ?: null,
                ':total_positions' => $total_positions,
                ':featured' => $featured,
                ':priority' => $priority,
                ':id' => $id,
            ]);

            $success = 'Campaign has been updated successfully.';
        } catch (PDOException $e) {
            error_log('Update campaign error: ' . $e->getMessage());
            $error = 'Failed to update campaign. Please try again.';
        }
    }
}

$page_title = 'Edit Campaign';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Edit Campaign</h1>
        <p class="description">Update campaign details for <?php echo htmlspecialchars($campaign['title']); ?></p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back to List</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" role="alert">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<div class="form-section">
    <h2>Campaign Details</h2>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="title">Campaign Title *</label>
                <input
                    type="text"
                    class="form-control"
                    id="title"
                    name="title"
                    value="<?php echo htmlspecialchars($title); ?>"
                    required
                    placeholder="e.g. Spring Internship Recruitment 2026"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="organization_id">Organization</label>
                <select class="form-select" id="organization_id" name="organization_id" disabled>
                    <option value="<?php echo $campaign['organization_id']; ?>" selected>
                        <?php echo htmlspecialchars($campaign['org_name']); ?>
                    </option>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="description">Campaign Description</label>
            <textarea
                class="form-control"
                id="description"
                name="description"
                rows="3"
                placeholder="Describe the campaign, what the organization does, and what to expect"
            ><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label" for="eligibility_criteria">Eligibility Criteria <span class="text-muted">(Optional)</span></label>
            <textarea
                class="form-control"
                id="eligibility_criteria"
                name="eligibility_criteria"
                rows="3"
                placeholder="e.g. Year 2 or above, relevant major, willingness to commit 5 hours/week"
            ><?php echo htmlspecialchars($eligibility_criteria); ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label" for="recruitment_start">Recruitment Start Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="recruitment_start"
                    name="recruitment_start"
                    value="<?php echo htmlspecialchars($recruitment_start); ?>"
                    required
                >
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="recruitment_end">Recruitment End Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="recruitment_end"
                    name="recruitment_end"
                    value="<?php echo htmlspecialchars($recruitment_end); ?>"
                    required
                >
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="total_positions">Total Positions *</label>
                <input
                    type="number"
                    class="form-control"
                    id="total_positions"
                    name="total_positions"
                    value="<?php echo htmlspecialchars($total_positions); ?>"
                    min="1"
                    required
                >
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="screening_start">Screening Start Date</label>
                <input
                    type="date"
                    class="form-control"
                    id="screening_start"
                    name="screening_start"
                    value="<?php echo htmlspecialchars($screening_start); ?>"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="screening_end">Screening End Date</label>
                <input
                    type="date"
                    class="form-control"
                    id="screening_end"
                    name="screening_end"
                    value="<?php echo htmlspecialchars($screening_end); ?>"
                >
            </div>
        </div>

        <div class="mb-3">
            <div class="form-check">
                <input
                    class="form-check-input"
                    type="checkbox"
                    id="featured"
                    name="featured"
                    <?php echo $featured ? 'checked' : ''; ?>
                >
                <label class="form-check-label" for="featured">
                    <span class="text-muted">Featured Campaign</span>
                </label>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="priority">Priority <span class="text-muted">(0 = lowest, 10 = highest)</span></label>
            <input
                type="number"
                class="form-control"
                id="priority"
                name="priority"
                value="<?php echo htmlspecialchars($priority); ?>"
                min="0"
                max="10"
            >
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg">Update Campaign</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
