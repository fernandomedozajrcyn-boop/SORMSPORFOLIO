<?php
/**
 * Campaign Create Page
 *
 * Allows admins and verified recruiters to create new recruitment campaigns.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole(['admin', 'recruiter']);
requireLogin();

$error = '';
$success = '';
$title = '';
$description = '';
$eligibility = '';
$recruitment_start = '';
$recruitment_end = '';
$screening_start = '';
$screening_end = '';
$total_positions = '';
$organization_id = '';
$featured = false;
$priority = 0;

$organizations = getManageableOrganizations(true);
$organizationIds = array_map('intval', array_column($organizations, 'id'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $eligibility = sanitize($_POST['eligibility_criteria'] ?? '');
    $recruitment_start = $_POST['recruitment_start'] ?? '';
    $recruitment_end = $_POST['recruitment_end'] ?? '';
    $screening_start = $_POST['screening_start'] ?? '';
    $screening_end = $_POST['screening_end'] ?? '';
    $total_positions = (int)($_POST['total_positions'] ?? 1);
    $organization_id = (int)($_POST['organization_id'] ?? 0);
    $featured = isset($_POST['featured']) ? 1 : 0;
    $priority = (int)($_POST['priority'] ?? 0);

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } elseif (empty($title)) {
        $error = 'Campaign title is required.';
    } elseif (!validateString($title, 3, 200)) {
        $error = 'Campaign title must be between 3 and 200 characters.';
    } elseif (empty($recruitment_start)) {
        $error = 'Recruitment start date is required.';
    } elseif (empty($recruitment_end)) {
        $error = 'Recruitment end date is required.';
    } elseif ($recruitment_start > $recruitment_end) {
        $error = 'Recruitment end date must be after the start date.';
    } elseif (empty($organization_id)) {
        $error = 'Please select an organization.';
    } elseif (!in_array($organization_id, $organizationIds, true)) {
        $error = 'You can only create campaigns for organizations you manage.';
    } elseif (empty($total_positions) || $total_positions < 1) {
        $error = 'Total positions must be at least 1.';
    }

    if (empty($error)) {
        $slug = generateSlug($title) . '-' . date('YmdHis');

        $existing = Database::fetch('SELECT id FROM campaigns WHERE slug = :slug LIMIT 1', ['slug' => $slug]);
        if (!empty($existing)) {
            $slug = $slug . '-' . (int)$existing['id'];
        }

        $sql = "INSERT INTO campaigns
                (organization_id, title, slug, description, eligibility_criteria,
                 recruitment_start, recruitment_end, screening_start, screening_end,
                 total_positions, positions_remaining, status, featured, priority, created_by)
                VALUES
                (:organization_id, :title, :slug, :description, :eligibility,
                 :recruitment_start, :recruitment_end, :screening_start, :screening_end,
                 :total_positions, :positions_remaining, 'open', :featured, :priority, :created_by)";

        $stmt = Database::getConnection()->prepare($sql);

        try {
            $stmt->execute([
                ':organization_id' => $organization_id,
                ':title' => $title,
                ':slug' => $slug,
                ':description' => $description,
                ':eligibility' => $eligibility,
                ':recruitment_start' => $recruitment_start,
                ':recruitment_end' => $recruitment_end,
                ':screening_start' => $screening_start ?: null,
                ':screening_end' => $screening_end ?: null,
                ':total_positions' => $total_positions,
                ':positions_remaining' => $total_positions,
                ':featured' => $featured,
                ':priority' => $priority,
                ':created_by' => $_SESSION['user_id'],
            ]);

            $campaignId = Database::getLastInsertId();

            $notif = Database::getConnection()->prepare(
                "INSERT INTO notifications (user_id, type, title, message, link, is_read)
                 SELECT u.id, 'campaign_created', 'New Campaign Created',
                        CONCAT(:title, ' has been created for the ', o.name, ' organization.'),
                        :link, 0
                 FROM users u
                 CROSS JOIN organizations o
                 WHERE u.role IN ('admin', 'recruiter') AND o.id = :organization_id"
            );
            $notif->execute([
                ':title' => $title,
                ':organization_id' => $organization_id,
                ':link' => SORMS_URL . 'src/campaign/view.php?id=' . $campaignId,
            ]);

            $success = 'Campaign "' . $title . '" has been created successfully.';
            $title = '';
            $description = '';
            $eligibility = '';
            $recruitment_start = '';
            $recruitment_end = '';
            $screening_start = '';
            $screening_end = '';
            $total_positions = '';
            $organization_id = '';
            $featured = false;
            $priority = 0;
        } catch (PDOException $e) {
            error_log('Create campaign error: ' . $e->getMessage());
            $error = 'Failed to create campaign. Please try again.';
        }
    }
}

$page_title = 'Create Campaign';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Create New Campaign</h1>
        <p class="description">Create a recruitment campaign for a student organization</p>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back to List</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" role="alert">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if (empty($organizations)): ?>
    <div class="alert alert-info">
        <?php if (userHasRole('admin')): ?>
            No verified organizations are available. <a href="<?php echo SORMS_URL; ?>src/org/create.php">Create and verify an organization</a> before creating a campaign.
        <?php else: ?>
            You need a verified organization before you can create a campaign. Ask an administrator to review and approve your organization request.
        <?php endif; ?>
    </div>
<?php else: ?>
<div class="form-section">
    <h2>Campaign Details</h2>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="title">Campaign Title *</label>
                <input
                    type="text"
                    class="form-control"
                    id="title"
                    name="title"
                    value="<?php echo htmlspecialchars($title); ?>"
                    required
                    placeholder="e.g. Spring Internship Recruitment 2026"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="organization_id">Organization *</label>
                <select class="form-select" id="organization_id" name="organization_id" required>
                    <option value="">Select an organization...</option>
                    <?php foreach ($organizations as $org): ?>
                        <option value="<?php echo $org['id']; ?>" <?php echo $organization_id == $org['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($org['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="description">Campaign Description</label>
            <textarea
                class="form-control"
                id="description"
                name="description"
                rows="3"
                placeholder="Describe the campaign, what the organization does, and what to expect"
            ><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label" for="eligibility_criteria">Eligibility Criteria <span class="text-muted">(Optional)</span></label>
            <textarea
                class="form-control"
                id="eligibility_criteria"
                name="eligibility_criteria"
                rows="3"
                placeholder="e.g. Year 2 or above, relevant major, willingness to commit 5 hours/week"
            ><?php echo htmlspecialchars($eligibility); ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label" for="recruitment_start">Recruitment Start Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="recruitment_start"
                    name="recruitment_start"
                    value="<?php echo htmlspecialchars($recruitment_start); ?>"
                    required
                >
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="recruitment_end">Recruitment End Date *</label>
                <input
                    type="date"
                    class="form-control"
                    id="recruitment_end"
                    name="recruitment_end"
                    value="<?php echo htmlspecialchars($recruitment_end); ?>"
                    required
                >
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="total_positions">Total Positions *</label>
                <input
                    type="number"
                    class="form-control"
                    id="total_positions"
                    name="total_positions"
                    value="<?php echo htmlspecialchars($total_positions); ?>"
                    min="1"
                    required
                >
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="screening_start">Screening Start Date</label>
                <input
                    type="date"
                    class="form-control"
                    id="screening_start"
                    name="screening_start"
                    value="<?php echo htmlspecialchars($screening_start); ?>"
                >
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="screening_end">Screening End Date</label>
                <input
                    type="date"
                    class="form-control"
                    id="screening_end"
                    name="screening_end"
                    value="<?php echo htmlspecialchars($screening_end); ?>"
                >
            </div>
        </div>

        <div class="mb-3">
            <div class="form-check">
                <input
                    class="form-check-input"
                    type="checkbox"
                    id="featured"
                    name="featured"
                    <?php echo $featured ? 'checked' : ''; ?>
                >
                <label class="form-check-label" for="featured">
                    <span class="text-muted">Featured Campaign</span>
                </label>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label" for="priority">Priority <span class="text-muted">(0 = lowest, 10 = highest)</span></label>
            <input
                type="number"
                class="form-control"
                id="priority"
                name="priority"
                value="<?php echo htmlspecialchars($priority); ?>"
                min="0"
                max="10"
            >
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg">Create Campaign</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
