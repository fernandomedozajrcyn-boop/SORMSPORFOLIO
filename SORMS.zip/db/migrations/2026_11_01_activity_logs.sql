CREATE TABLE IF NOT EXISTS activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    event_type VARCHAR(64) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(1000) NULL,
    device_type VARCHAR(30) NULL,
    operating_system VARCHAR(100) NULL,
    browser VARCHAR(100) NULL,
    browser_version VARCHAR(30) NULL,
    referrer VARCHAR(500) NULL,
    metadata JSON NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_activity_event_created (event_type, created_at),
    INDEX idx_activity_ip_event_created (ip_address, event_type, created_at),
    INDEX idx_activity_user_created (user_id, created_at)
);
