<?php
/**
 * Demo data seeder
 *
 * Creates a recruiter, a student, an organization, an open campaign, and
 * one sample application so the system can be explored right away.
 *
 * Safe to run more than once: existing records are reused.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

function demoEnsureUser(string $username, string $email, string $password, string $fullName, string $role): int
{
    $existing = Database::fetch(
        'SELECT id FROM users WHERE username = :username OR email = :email',
        ['username' => $username, 'email' => $email]
    );

    if ($existing) {
        Database::execute(
            "UPDATE users SET password_hash = :hash, role = :role, status = 'active' WHERE id = :id",
            [
                'hash' => password_hash($password, PASSWORD_DEFAULT),
                'role' => $role,
                'id' => $existing['id'],
            ]
        );

        return (int) $existing['id'];
    }

    Database::execute(
        "INSERT INTO users (username, email, password_hash, full_name, role, status)
         VALUES (:username, :email, :hash, :full_name, :role, 'active')",
        [
            'username' => $username,
            'email' => $email,
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'full_name' => $fullName,
            'role' => $role,
        ]
    );

    return Database::getLastInsertId();
}

function demoEnsureApplicant(int $userId, string $fullName, string $email): int
{
    $existing = Database::fetch('SELECT id FROM applicants WHERE user_id = :user_id', ['user_id' => $userId]);

    if ($existing) {
        return (int) $existing['id'];
    }

    Database::execute(
        "INSERT INTO applicants (user_id, full_name, email, phone, gender, address)
         VALUES (:user_id, :full_name, :email, '555-0200', 'other', 'Main Campus')",
        ['user_id' => $userId, 'full_name' => $fullName, 'email' => $email]
    );

    return Database::getLastInsertId();
}

function demoEnsureOrganization(int $ownerId): int
{
    $name = 'Computer Science Society';

    $existing = Database::fetch('SELECT id FROM organizations WHERE name = :name', ['name' => $name]);

    if ($existing) {
        return (int) $existing['id'];
    }

    Database::execute(
        "INSERT INTO organizations
            (name, description, founder_user_id, admin_user_id, established_date, color_theme, status)
         VALUES
            (:name, :description, :founder, :admin, '2020-08-15', '#1a73e8', 'active')",
        [
            'name' => $name,
            'description' => 'A community of students who build software, share ideas, and join tech events.',
            'founder' => $ownerId,
            'admin' => $ownerId,
        ]
    );

    return Database::getLastInsertId();
}

function demoEnsureCampaign(int $organizationId, int $createdBy): int
{
    $title = 'CS Society Recruitment 2026';

    $existing = Database::fetch('SELECT id FROM campaigns WHERE title = :title', ['title' => $title]);

    if ($existing) {
        return (int) $existing['id'];
    }

    $start = (new DateTime('today'))->modify('-7 days')->format('Y-m-d');
    $end = (new DateTime('today'))->modify('+21 days')->format('Y-m-d');
    $screeningStart = (new DateTime('today'))->modify('+22 days')->format('Y-m-d');
    $screeningEnd = (new DateTime('today'))->modify('+35 days')->format('Y-m-d');

    Database::execute(
        "INSERT INTO campaigns
            (organization_id, title, slug, description, eligibility_criteria,
             recruitment_start, recruitment_end, screening_start, screening_end,
             total_positions, positions_remaining, status, featured, priority, created_by)
         VALUES
            (:organization_id, :title, :slug, :description, :eligibility,
             :recruitment_start, :recruitment_end, :screening_start, :screening_end,
             5, 5, 'open', 1, 5, :created_by)",
        [
            'organization_id' => $organizationId,
            'title' => $title,
            'slug' => generateSlug($title) . '-' . date('Ymd'),
            'description' => 'Join the Computer Science Society for workshops, hackathons, and peer learning.',
            'eligibility' => 'Open to all currently enrolled students with an interest in technology.',
            'recruitment_start' => $start,
            'recruitment_end' => $end,
            'screening_start' => $screeningStart,
            'screening_end' => $screeningEnd,
            'created_by' => $createdBy,
        ]
    );

    return Database::getLastInsertId();
}

function demoEnsureApplication(int $applicantId, int $campaignId): void
{
    $existing = Database::fetch(
        'SELECT id FROM applications WHERE applicant_id = :applicant_id AND campaign_id = :campaign_id',
        ['applicant_id' => $applicantId, 'campaign_id' => $campaignId]
    );

    if ($existing) {
        return;
    }

    Database::execute(
        "INSERT INTO applications (applicant_id, campaign_id, status, motivation_letter, additional_info)
         VALUES (:applicant_id, :campaign_id, 'applied', :motivation_letter, :additional_info)",
        [
            'applicant_id' => $applicantId,
            'campaign_id' => $campaignId,
            'motivation_letter' => 'I want to join the Computer Science Society to learn from fellow students, contribute to projects, and take part in hackathons.',
            'additional_info' => 'I have experience with PHP, MySQL, and basic front-end development.',
        ]
    );
}

$admin = Database::fetch("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1");

if (!$admin) {
    echo "No admin account found. Run db/seed.php first.\n";
    exit(1);
}

$adminId = (int) $admin['id'];

$recruiterId = demoEnsureUser('recruiter', 'recruiter@soroms.com', 'recruiter123', 'Riley Recruiter', 'recruiter');
$studentId = demoEnsureUser('student', 'student@soroms.com', 'student123', 'Sam Student', 'student');
$applicantId = demoEnsureApplicant($studentId, 'Sam Student', 'student@soroms.com');

$organizationId = demoEnsureOrganization($recruiterId);
$campaignId = demoEnsureCampaign($organizationId, $adminId);

demoEnsureApplication($applicantId, $campaignId);

echo "Demo data is ready.\n";
echo "Admin:     admin / admin123\n";
echo "Recruiter: recruiter / recruiter123\n";
echo "Student:   student / student123\n";
echo "Login at:  " . SORMS_URL . "src/auth/login.php\n";
