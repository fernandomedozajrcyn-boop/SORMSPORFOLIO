<?php
/**
 * Database Seed File
 *
 * Run this file once to create the default admin account.
 * Make sure the database is already created and the schema is applied.
 * After running this, delete this file for security.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Check if admin user already exists
$existing = Database::fetch("SELECT id FROM users WHERE username = 'admin' OR email = 'admin@soroms.com'");

if ($existing) {
    // Keep the password in sync with the credentials printed below
    Database::execute(
        "UPDATE users SET password_hash = :hash, role = 'admin', status = 'active' WHERE id = :id",
        [':hash' => password_hash('admin123', PASSWORD_DEFAULT), ':id' => $existing['id']]
    );

    echo "Admin account already exists. Password reset to admin123.\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";
    echo "Login at: " . SORMS_URL . "src/auth/login.php\n";
    exit;
}

// Create admin user
$passwordHash = password_hash('admin123', PASSWORD_DEFAULT);

$stmt = Database::getConnection()->prepare(
    "INSERT INTO users (username, email, password_hash, full_name, role, status, phone)
     VALUES ('admin', 'admin@soroms.com', :password_hash, 'System Administrator', 'admin', 'active', '555-0100')"
);

try {
    $stmt->execute([
        ':password_hash' => $passwordHash,
    ]);

    $adminId = Database::getLastInsertId();
    echo "Admin account created successfully!\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";
    echo "Login at: " . SORMS_URL . "src/auth/login.php\n";
} catch (PDOException $e) {
    error_log('Seed error: ' . $e->getMessage());
    echo "Error creating admin account: " . $e->getMessage() . "\n";
}

