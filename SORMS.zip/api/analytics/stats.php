<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/analytics.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
requireAdminAccess(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

$period = (string) ($_GET['period'] ?? 'daily');
if (!in_array($period, ['daily', 'weekly', 'monthly'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Unsupported reporting period.']);
    exit;
}

echo json_encode(getAnalyticsDashboardData($period), JSON_INVALID_UTF8_SUBSTITUTE);
