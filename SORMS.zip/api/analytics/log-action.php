<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
startSession();

function respondWithJson(int $status, array $response): void
{
    http_response_code($status);
    echo json_encode($response, JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respondWithJson(405, ['error' => 'Method not allowed.']);
}

$requestBody = file_get_contents('php://input');
if ($requestBody === false || strlen($requestBody) > 4096) {
    respondWithJson(413, ['error' => 'The request payload is too large.']);
}

$payload = json_decode($requestBody, true);
if (
    !is_array($payload)
    || !in_array($payload['event_type'] ?? '', ['PAGE_VIEW', 'PORTFOLIO_PDF_DOWNLOAD'], true)
) {
    respondWithJson(400, ['error' => 'Unsupported activity event.']);
}

$eventType = $payload['event_type'];
if (!verifyCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) {
    respondWithJson(403, ['error' => 'The request could not be verified.']);
}

$rateLimit = $eventType === 'PAGE_VIEW'
    ? consumeRateLimit('page_view_analytics', $eventType, 120, 600, 3600)
    : consumeRateLimit('portfolio_analytics', $eventType, 20, 100, 3600);
if (!$rateLimit) {
    respondWithJson(429, ['error' => 'Too many activity requests.']);
}

$metadata = [];
$pagePath = $payload['page_path'] ?? '';
if ($eventType === 'PAGE_VIEW') {
    if (
        !is_string($pagePath)
        || !str_starts_with($pagePath, '/')
        || strlen($pagePath) > 255
        || str_starts_with($pagePath, '/api/')
    ) {
        respondWithJson(400, ['error' => 'Invalid page path.']);
    }
    $metadata['page_path'] = $pagePath;
}

$screenResolution = $payload['screen_resolution'] ?? '';
if (is_string($screenResolution) && preg_match('/^\d{1,5}x\d{1,5}$/', $screenResolution)) {
    $metadata['screen_resolution'] = $screenResolution;
}

$referrer = $payload['referrer'] ?? '';
if (is_string($referrer) && $referrer !== '') {
    $referrerPath = parse_url($referrer, PHP_URL_PATH);
    if (is_string($referrerPath) && str_starts_with($referrerPath, '/')) {
        $metadata['client_referrer_path'] = mb_substr($referrerPath, 0, 255);
    }
}

if (!logActivity($eventType, $metadata, getUserId())) {
    respondWithJson(503, ['error' => 'Activity tracking is temporarily unavailable.']);
}

if ($eventType === 'PAGE_VIEW') {
    http_response_code(202);
    echo json_encode(['recorded' => true]);
    exit;
}

$now = time();
$downloadTokens = $_SESSION['portfolio_download_tokens'] ?? [];
$downloadTokens = array_filter(
    is_array($downloadTokens) ? $downloadTokens : [],
    static function ($createdAt) use ($now): bool {
        return is_int($createdAt) && $createdAt >= $now - 120;
    }
);
$downloadToken = bin2hex(random_bytes(24));
$downloadTokens[$downloadToken] = $now;
$_SESSION['portfolio_download_tokens'] = $downloadTokens;
http_response_code(202);
echo json_encode(['recorded' => true, 'download_token' => $downloadToken]);
