<?php

function writeXlsxArchive(string $destination, array $files): void
{
    $output = fopen($destination, 'wb');
    if ($output === false) {
        throw new RuntimeException('Unable to create the workbook file.');
    }

    $centralDirectory = '';
    $offset = 0;
    $compressedPaths = [];
    $dosTime = ((int) date('H') << 11) | ((int) date('i') << 5) | (int) (date('s') / 2);
    $dosDate = (((int) date('Y') - 1980) << 9) | ((int) date('n') << 5) | (int) date('j');

    try {
        foreach ($files as $name => $source) {
            $compressedPath = tempnam(sys_get_temp_dir(), 'sorms-xlsx-deflate-');
            if ($compressedPath === false) {
                throw new RuntimeException('Unable to allocate a compressed workbook component.');
            }
            $compressedPaths[] = $compressedPath;

            $sourceStream = is_array($source) && isset($source['path'])
                ? fopen((string) $source['path'], 'rb')
                : fopen('php://temp', 'w+b');
            if ($sourceStream === false) {
                throw new RuntimeException('Unable to read a workbook component.');
            }
            if (!is_array($source) && fwrite($sourceStream, (string) $source) === false) {
                fclose($sourceStream);
                throw new RuntimeException('Unable to prepare a workbook component.');
            }
            if (!is_array($source)) {
                rewind($sourceStream);
            }

            $compressedStream = fopen($compressedPath, 'wb');
            if ($compressedStream === false) {
                fclose($sourceStream);
                throw new RuntimeException('Unable to write a compressed workbook component.');
            }
            $deflater = deflate_init(ZLIB_ENCODING_RAW, ['level' => 6]);
            if ($deflater === false) {
                fclose($sourceStream);
                fclose($compressedStream);
                throw new RuntimeException('Unable to initialize workbook compression.');
            }

            $checksum = hash_init('crc32b');
            $uncompressedSize = 0;
            while (!feof($sourceStream)) {
                $chunk = fread($sourceStream, 65536);
                if ($chunk === false) {
                    fclose($sourceStream);
                    fclose($compressedStream);
                    throw new RuntimeException('Unable to read a workbook component.');
                }
                if ($chunk === '') {
                    continue;
                }
                $uncompressedSize += strlen($chunk);
                hash_update($checksum, $chunk);
                $compressedChunk = deflate_add($deflater, $chunk, ZLIB_NO_FLUSH);
                if ($compressedChunk === false || fwrite($compressedStream, $compressedChunk) === false) {
                    fclose($sourceStream);
                    fclose($compressedStream);
                    throw new RuntimeException('Unable to compress a workbook component.');
                }
            }
            $finalChunk = deflate_add($deflater, '', ZLIB_FINISH);
            if ($finalChunk === false || fwrite($compressedStream, $finalChunk) === false) {
                fclose($sourceStream);
                fclose($compressedStream);
                throw new RuntimeException('Unable to finish workbook compression.');
            }
            fclose($sourceStream);
            fclose($compressedStream);

            $compressedSize = filesize($compressedPath);
            if ($compressedSize === false) {
                throw new RuntimeException('Unable to inspect compressed workbook data.');
            }
            $crc = hexdec(hash_final($checksum));
            $name = (string) $name;
            $nameLength = strlen($name);
            $localHeader = pack(
                'VvvvvvVVVvv',
                0x04034b50,
                20,
                0,
                8,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                $nameLength,
                0
            );
            $entryOffset = $offset;
            $localData = $localHeader . $name;
            if (fwrite($output, $localData) !== strlen($localData)) {
                throw new RuntimeException('Unable to write the workbook archive.');
            }
            $offset += strlen($localData);

            $compressedStream = fopen($compressedPath, 'rb');
            if ($compressedStream === false) {
                throw new RuntimeException('Unable to read compressed workbook data.');
            }
            while (!feof($compressedStream)) {
                $chunk = fread($compressedStream, 65536);
                if ($chunk === false) {
                    fclose($compressedStream);
                    throw new RuntimeException('Unable to read compressed workbook data.');
                }
                if ($chunk !== '') {
                    if (fwrite($output, $chunk) !== strlen($chunk)) {
                        fclose($compressedStream);
                        throw new RuntimeException('Unable to write compressed workbook data.');
                    }
                    $offset += strlen($chunk);
                }
            }
            fclose($compressedStream);

            $centralDirectory .= pack(
                'VvvvvvvVVVvvvvvVV',
                0x02014b50,
                20,
                20,
                0,
                8,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                $nameLength,
                0,
                0,
                0,
                0,
                0,
                $entryOffset
            ) . $name;
        }

        $directoryOffset = $offset;
        if (fwrite($output, $centralDirectory) !== strlen($centralDirectory)) {
            throw new RuntimeException('Unable to write the workbook directory.');
        }
        $directorySize = strlen($centralDirectory);
        $endRecord = pack(
            'VvvvvVVv',
            0x06054b50,
            0,
            0,
            count($files),
            count($files),
            $directorySize,
            $directoryOffset,
            0
        );
        if (fwrite($output, $endRecord) !== strlen($endRecord)) {
            throw new RuntimeException('Unable to finish the workbook archive.');
        }
    } finally {
        fclose($output);
        foreach ($compressedPaths as $path) {
            if (is_file($path)) {
                unlink($path);
            }
        }
    }
}
