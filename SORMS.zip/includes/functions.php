<?php
/**
 * Generate a slug from a string
 *
 * @param string $text
 * @return string
 */
function generateSlug(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
    $text = trim($text, '-');
    return $text;
}

/**
 * Generate a unique slug for a campaign
 *
 * @param string $baseSlug
 * @param int $organizationId
 * @return string
 */
function generateUniqueSlug(string $baseSlug, int $organizationId): string
{
    $slug = $baseSlug;
    $counter = 1;

    while (true) {
        $sql = 'SELECT id FROM campaigns WHERE slug = :slug LIMIT 1';
        $existing = Database::fetch($sql, ['slug' => $slug]);

        if (!$existing) {
            break;
        }

        $slug = $baseSlug . '-' . $counter;
        $counter++;
    }

    return $slug;
}

/**
 * Format a date for display
 *
 * @param string $date
 * @param string $format
 * @return string
 */
function formatDate(string $date, string $format = 'M d, Y'): string
{
    try {
        $d = new DateTime($date);
        return $d->format($format);
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * Format a date-time for display
 */
function formatDateTime(string $datetime, string $format = 'M d, Y g:i A'): string
{
    try {
        $dt = new DateTime($datetime);
        return $dt->format($format);
    } catch (Exception $e) {
        return $datetime;
    }
}

/**
 * Get the user's full name from their ID (for display in views)
 */
function getUserNameById(int $userId): string
{
    $user = Database::fetch('SELECT full_name FROM users WHERE id = :id', ['id' => $userId]);
    return $user['full_name'] ?? 'Unknown';
}

/**
 * Get the user role name from their ID
 */
function getUserRoleById(int $userId): string
{
    $user = Database::fetch('SELECT role FROM users WHERE id = :id', ['id' => $userId]);
    return $user['role'] ?? 'student';
}

/**
 * Ensure user is logged in, redirect to login if not
 *
 * @param string $redirectUrl
 */
function requireLogin(string $redirectUrl = '/'): void
{
    if (!isLoggedIn()) {
        setFlash('error', 'Please login to continue.');
        redirect('src/auth/login.php');
    }
}

/**
 * Ensure user has a specific role
 *
 * @param string|array $roles
 * @param string $redirectUrl
 */
function requireRole($roles, string $redirectUrl = '/'): void
{
    if (!isLoggedIn()) {
        setFlash('error', 'Please login to continue.');
        redirect('src/auth/login.php');
    }

    if (!userHasRole($roles)) {
        setFlash('error', 'You do not have permission to access this page.');
        redirect($redirectUrl);
    }
}

/**
 * Restrict analytics routes to administrators without redirecting API clients.
 */
function requireAdminAccess(bool $jsonResponse = false): void
{
    if (!userHasRole('admin')) {
        http_response_code(403);
        if ($jsonResponse) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'Forbidden.']);
        } else {
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Forbidden';
        }
        exit;
    }
}

/**
 * Check if a campaign is in the application period
 *
 * @param array $campaign
 * @return bool
 */
function isCampaignOpen(array $campaign): bool
{
    if (empty($campaign['recruitment_start']) || empty($campaign['recruitment_end'])) {
        return false;
    }

    if (!validateDate($campaign['recruitment_start']) || !validateDate($campaign['recruitment_end'])) {
        return false;
    }

    $today = new DateTime('today');
    $start = new DateTime($campaign['recruitment_start']);
    $end = new DateTime($campaign['recruitment_end']);

    return $today >= $start && $today <= $end && $campaign['status'] === 'open';
}

/**
 * Check if a campaign is currently in screening phase
 *
 * @param array $campaign
 * @return bool
 */
function isCampaignInScreening(array $campaign): bool
{
    $screeningStart = $campaign['screening_start'] ?? '';
    $screeningEnd = $campaign['screening_end'] ?? '';

    if (!validateDate((string) $screeningStart) || !validateDate((string) $screeningEnd)) {
        return false;
    }

    $today = new DateTime('today');
    $start = new DateTime($screeningStart);
    $end = new DateTime($screeningEnd);

    return $today >= $start && $today <= $end && $campaign['status'] === 'open';
}

/**
 * Check if campaign is in the past (closed or completed)
 *
 * @param array $campaign
 * @return bool
 */
function isCampaignPast(array $campaign): bool
{
    if (empty($campaign['recruitment_end']) || !validateDate($campaign['recruitment_end'])) {
        return false;
    }

    $today = new DateTime('today');
    $end = new DateTime($campaign['recruitment_end']);

    return $today > $end;
}

/**
 * Get campaign status label
 *
 * @param string $status
 * @return string
 */
function campaignStatusLabel(string $status): string
{
    $labels = [
        'draft'    => 'Draft',
        'open'     => 'Open',
        'closed'   => 'Closed',
        'completed'=> 'Completed',
    ];

    return $labels[$status] ?? $status;
}

/**
 * Get position status label for applications
 *
 * @param string $status
 * @return string
 */
function applicationStatusLabel(string $status): string
{
    $labels = [
        'applied'       => 'Applied',
        'reviewing'     => 'Under Review',
        'shortlisted'   => 'Shortlisted',
        'approved'      => 'Approved',
        'rejected'      => 'Rejected',
        'withdrawn'     => 'Withdrawn',
    ];

    return $labels[$status] ?? $status;
}

/**
 * Get position status color
 *
 * @param string $status
 * @return string
 */
function applicationStatusColor(string $status): string
{
    $colors = [
        'applied'       => 'info',
        'reviewing'     => 'warning',
        'shortlisted'   => 'primary',
        'approved'      => 'success',
        'rejected'      => 'danger',
        'withdrawn'     => 'secondary',
    ];

    return $colors[$status] ?? 'secondary';
}

// ------------------------------------------------------------------
// INPUT HANDLING
// ------------------------------------------------------------------

/**
 * Clean a raw value coming from user input before it is stored in the
 * database. Output escaping is done separately with e().
 *
 * @param mixed $value
 * @return string
 */
function sanitize($value): string
{
    if ($value === null || is_array($value) || is_object($value)) {
        return '';
    }

    $value = strip_tags((string) $value);
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value);

    return trim($value);
}

/**
 * Escape a value for safe output inside HTML.
 *
 * @param mixed $value
 * @return string
 */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// ------------------------------------------------------------------
// SESSION AND AUTHENTICATION
// ------------------------------------------------------------------

/**
 * Start the session if it is not already running
 */
function startSession(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        $trustedProxies = array_filter(array_map('trim', explode(',', SORMS_TRUSTED_PROXIES)));
        $isSecureRequest = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        if (
            !$isSecureRequest
            && in_array((string) ($_SERVER['REMOTE_ADDR'] ?? ''), $trustedProxies, true)
            && strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
        ) {
            $isSecureRequest = true;
        }
        ini_set(
            'session.cookie_secure',
            $isSecureRequest ? '1' : '0'
        );
        session_start();
    }
}

/**
 * Check whether a user is currently signed in
 *
 * @return bool
 */
function isLoggedIn(): bool
{
    startSession();

    return isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0;
}

/**
 * Get the id of the signed in user
 *
 * @return int|null
 */
function getUserId(): ?int
{
    return isLoggedIn() ? (int) $_SESSION['user_id'] : null;
}

/**
 * Get the display name of the signed in user
 *
 * @return string
 */
function getUserName(): string
{
    startSession();

    if (!empty($_SESSION['user_name'])) {
        return (string) $_SESSION['user_name'];
    }

    if (isLoggedIn()) {
        $user = Database::fetch('SELECT full_name FROM users WHERE id = :id', ['id' => getUserId()]);
        if (!empty($user['full_name'])) {
            $_SESSION['user_name'] = $user['full_name'];
            return $user['full_name'];
        }
    }

    return 'Guest';
}

/**
 * Get the role of the signed in user
 *
 * @return string
 */
function getUserRole(): string
{
    startSession();

    return (string) ($_SESSION['user_role'] ?? 'student');
}

/**
 * Check whether the signed in user has one of the given roles
 *
 * @param string|array $roles
 * @return bool
 */
function userHasRole($roles): bool
{
    if (!isLoggedIn()) {
        return false;
    }

    $userRole = getUserRole();

    if (is_array($roles)) {
        return in_array($userRole, $roles, true);
    }

    return $userRole === $roles;
}

/**
 * Get the landing page of the application for a given role
 *
 * @param string|null $role
 * @return string
 */
function homeUrlForRole(?string $role = null): string
{
    $role = $role ?? getUserRole();

    switch ($role) {
        case 'admin':
            return 'src/screening/dashboard.php';
        case 'recruiter':
            return 'src/campaign/index.php';
        default:
            return 'src/applicant/index.php';
    }
}

// ------------------------------------------------------------------
// FLASH MESSAGES
// ------------------------------------------------------------------

/**
 * Store a one-time message for the next rendered page
 *
 * @param string $type
 * @param string $message
 */
function setFlash(string $type, string $message): void
{
    startSession();
    $_SESSION['flash'][$type] = $message;
}

/**
 * Read a flash message. Repeated calls in the same request return the
 * same value, the message is removed from the session afterwards.
 *
 * @param string $type
 * @return string|null
 */
function getFlash(string $type): ?string
{
    startSession();

    static $read = [];

    if (array_key_exists($type, $read)) {
        return $read[$type];
    }

    $message = $_SESSION['flash'][$type] ?? null;

    if ($message !== null) {
        $read[$type] = $message;
        unset($_SESSION['flash'][$type]);
    }

    return $message;
}

// ------------------------------------------------------------------
// NOTIFICATIONS
// ------------------------------------------------------------------

/**
 * Count unread notifications for a user
 *
 * @param int|null $userId Defaults to the signed in user
 * @return int
 */
function getUnreadNotificationCount(?int $userId = null): int
{
    $userId = $userId ?? getUserId();

    if (!$userId) {
        return 0;
    }

    return (int) Database::value(
        'SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND is_read = 0',
        ['user_id' => $userId]
    );
}

// ------------------------------------------------------------------
// LOGIN ACTIVITY
// ------------------------------------------------------------------

/**
 * Get the best available IP address for the current request
 *
 * @return string
 */
function getClientIp(): string
{
    $remoteAddress = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

    if (!filter_var($remoteAddress, FILTER_VALIDATE_IP)) {
        return '0.0.0.0';
    }

    $trustedProxies = array_filter(array_map('trim', explode(',', SORMS_TRUSTED_PROXIES)));
    if (!in_array($remoteAddress, $trustedProxies, true)) {
        return $remoteAddress;
    }

    $forwarded = (string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? '');
    $candidates = array_map('trim', explode(',', $forwarded));
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        array_unshift($candidates, trim((string) $_SERVER['HTTP_CF_CONNECTING_IP']));
    }
    $candidates[] = $remoteAddress;

    foreach (array_reverse($candidates) as $candidate) {
        if (
            filter_var($candidate, FILTER_VALIDATE_IP)
            && !in_array($candidate, $trustedProxies, true)
        ) {
            return $candidate;
        }
    }

    return $remoteAddress;
}

/**
 * Reduce an IP address to a coarse network prefix for privacy-conscious logs.
 */
function anonymizeIpAddress(string $ipAddress): string
{
    if (!SORMS_ANONYMIZE_IP) {
        return $ipAddress;
    }

    $packedAddress = @inet_pton($ipAddress);
    if ($packedAddress === false) {
        return '0.0.0.0';
    }

    if (strlen($packedAddress) === 4) {
        return inet_ntop(substr($packedAddress, 0, 3) . "\0") ?: '0.0.0.0';
    }

    return inet_ntop(substr($packedAddress, 0, 8) . str_repeat("\0", 8)) ?: '::';
}

/**
 * Store an application event with server-derived network and device details.
 *
 * @param array<string, mixed> $metadata
 */
function logActivity(string $eventType, array $metadata = [], ?int $userId = null): bool
{
    if (!preg_match('/^[A-Z][A-Z0-9_]{2,63}$/', $eventType)) {
        throw new InvalidArgumentException('Unsupported activity event type.');
    }

    try {
        $ipAddress = getClientIp();
        $userAgent = mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 1000);
        $device = parseUserAgent($userAgent);
        $browserVersion = 'Unknown';

        if (preg_match('/(?:edg|opr|chrome|crios|firefox|fxios|version|msie)[\\s\\/]([0-9.]+)/i', $userAgent, $matches)) {
            $browserVersion = mb_substr($matches[1], 0, 30);
        }

        if (SORMS_ENABLE_IP_GEOLOCATION && !isset($metadata['geolocation'])) {
            $location = lookupIpLocation($ipAddress);
            $metadata['geolocation'] = [
                'country' => $location['country'],
                'region' => $location['region'],
                'city' => $location['city'],
            ];
        }
        $metadata['timestamp_utc'] = gmdate(DATE_ATOM);

        $encodedMetadata = json_encode($metadata, JSON_INVALID_UTF8_SUBSTITUTE);
        if ($encodedMetadata === false) {
            throw new RuntimeException('Unable to encode activity metadata.');
        }

        $referrerPath = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_PATH);
        Database::execute(
            "INSERT INTO activity_logs
                (user_id, event_type, ip_address, user_agent, device_type,
                 operating_system, browser, browser_version, referrer, metadata, created_at)
             VALUES
                (:user_id, :event_type, :ip_address, :user_agent, :device_type,
                 :operating_system, :browser, :browser_version, :referrer, :metadata, :created_at)",
            [
                'user_id' => $userId,
                'event_type' => $eventType,
                'ip_address' => anonymizeIpAddress($ipAddress),
                'user_agent' => $userAgent,
                'device_type' => $device['device_type'],
                'operating_system' => $device['operating_system'],
                'browser' => $device['browser'],
                'browser_version' => $browserVersion,
                'referrer' => is_string($referrerPath) ? mb_substr($referrerPath, 0, 500) : null,
                'metadata' => $encodedMetadata,
                'created_at' => gmdate('Y-m-d H:i:s'),
            ]
        );
        return true;
    } catch (Throwable $e) {
        error_log('Activity log error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Parse a user agent string into device, browser, and operating system
 *
 * @param string $userAgent
 * @return array{device_type: string, browser: string, operating_system: string}
 */
function parseUserAgent(string $userAgent): array
{
    $ua = strtolower($userAgent);

    if (preg_match('/bot|crawler|spider|crawling/', $ua)) {
        $deviceType = 'Bot';
    } elseif (preg_match('/ipad|tablet|playbook|silk/', $ua)) {
        $deviceType = 'Tablet';
    } elseif (preg_match('/mobile|iphone|ipod|windows phone|android.*mobile/', $ua)) {
        $deviceType = 'Mobile';
    } else {
        $deviceType = 'Desktop';
    }

    if (preg_match('/edg\//', $ua)) {
        $browser = 'Microsoft Edge';
    } elseif (preg_match('/opr\/|opera/', $ua)) {
        $browser = 'Opera';
    } elseif (preg_match('/chrome|crios/', $ua)) {
        $browser = 'Chrome';
    } elseif (preg_match('/firefox|fxios/', $ua)) {
        $browser = 'Firefox';
    } elseif (preg_match('/safari/', $ua) && preg_match('/version\//', $ua)) {
        $browser = 'Safari';
    } elseif (preg_match('/msie|trident/', $ua)) {
        $browser = 'Internet Explorer';
    } else {
        $browser = 'Unknown';
    }

    if (preg_match('/windows nt 10/', $ua)) {
        $operatingSystem = 'Windows 10/11';
    } elseif (preg_match('/windows nt 6\.3/', $ua)) {
        $operatingSystem = 'Windows 8.1';
    } elseif (preg_match('/windows/', $ua)) {
        $operatingSystem = 'Windows';
    } elseif (preg_match('/android/', $ua)) {
        $operatingSystem = 'Android';
    } elseif (preg_match('/iphone|ipad|ipod/', $ua)) {
        $operatingSystem = 'iOS';
    } elseif (preg_match('/mac os x|macintosh/', $ua)) {
        $operatingSystem = 'macOS';
    } elseif (preg_match('/linux/', $ua)) {
        $operatingSystem = 'Linux';
    } else {
        $operatingSystem = 'Unknown';
    }

    return [
        'device_type' => $deviceType,
        'browser' => $browser,
        'operating_system' => $operatingSystem,
    ];
}

/**
 * Look up approximate location and network information for an IP address
 *
 * Public IP addresses are resolved through ipwho.is. Private addresses
 * (localhost, school LANs) are not sent anywhere and return empty values.
 *
 * @param string $ipAddress
 * @return array{country: ?string, region: ?string, city: ?string, isp: ?string, latitude: ?float, longitude: ?float}
 */
function lookupIpLocation(string $ipAddress): array
{
    $empty = [
        'country' => null,
        'region' => null,
        'city' => null,
        'isp' => null,
        'latitude' => null,
        'longitude' => null,
    ];

    if (
        $ipAddress === ''
        || filter_var(
            $ipAddress,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false
    ) {
        return $empty;
    }

    $url = 'https://ipwho.is/' . rawurlencode($ipAddress)
        . '?fields=success,country,region,city,connection.isp,latitude,longitude';

    $context = stream_context_create([
        'http' => [
            'timeout' => 2,
            'ignore_errors' => true,
            'user_agent' => 'SORMS/' . SORMS_VERSION,
        ],
    ]);

    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        error_log('IP geolocation provider request failed.');
        return $empty;
    }

    $data = json_decode($response, true);

    if (!is_array($data) || ($data['success'] ?? false) !== true) {
        error_log('IP geolocation provider returned an unsuccessful response.');
        return $empty;
    }

    $connection = is_array($data['connection'] ?? null) ? $data['connection'] : [];

    return [
        'country' => $data['country'] ?? null,
        'region' => $data['region'] ?? null,
        'city' => $data['city'] ?? null,
        'isp' => $connection['isp'] ?? null,
        'latitude' => isset($data['latitude']) ? (float) $data['latitude'] : null,
        'longitude' => isset($data['longitude']) ? (float) $data['longitude'] : null,
    ];
}

/**
 * Apply a lightweight per-session sliding-window rate limit.
 */
function consumeSessionRateLimit(string $key, int $limit, int $windowSeconds): bool
{
    startSession();
    $now = time();
    $key = preg_replace('/[^a-z0-9_-]/i', '', $key);
    $timestamps = $_SESSION['rate_limits'][$key] ?? [];
    $timestamps = array_values(array_filter(
        $timestamps,
        static function ($timestamp) use ($now, $windowSeconds): bool {
            return is_int($timestamp) && $timestamp > $now - $windowSeconds;
        }
    ));

    if (count($timestamps) >= $limit) {
        $_SESSION['rate_limits'][$key] = $timestamps;
        return false;
    }

    $timestamps[] = $now;
    $_SESSION['rate_limits'][$key] = $timestamps;
    return true;
}

/**
 * Combine a session limit with a persistent, anonymized network limit.
 */
function consumeRateLimit(
    string $key,
    string $eventType,
    int $sessionLimit,
    int $networkLimit,
    int $windowSeconds
): bool {
    if (!consumeSessionRateLimit($key, $sessionLimit, $windowSeconds)) {
        return false;
    }

    try {
        $count = Database::value(
            'SELECT COUNT(*) FROM activity_logs
             WHERE event_type = :event_type
               AND ip_address = :ip_address
               AND created_at >= :window_start',
            [
                'event_type' => $eventType,
                'ip_address' => anonymizeIpAddress(getClientIp()),
                'window_start' => gmdate('Y-m-d H:i:s', time() - $windowSeconds),
            ]
        );

        return (int) $count < $networkLimit;
    } catch (Throwable $e) {
        error_log('Network rate limit check error: ' . $e->getMessage());
        return true;
    }
}

/**
 * Store a login attempt (successful or failed) with device and network data
 *
 * @param int|null $userId
 * @param string $username
 * @param string $status "success" or "failed"
 */
function recordLoginAttempt(?int $userId, string $username, string $status): void
{
    try {
        $ipAddress = getClientIp();
        $userAgent = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $device = parseUserAgent($userAgent);
        $location = SORMS_ENABLE_IP_GEOLOCATION
            ? lookupIpLocation($ipAddress)
            : [
                'country' => null,
                'region' => null,
                'city' => null,
                'isp' => null,
                'latitude' => null,
                'longitude' => null,
            ];
        $refererPath = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_PATH);
        $referer = is_string($refererPath) ? mb_substr($refererPath, 0, 255) : '';

        Database::execute(
            "INSERT INTO login_logs
                (user_id, username_attempted, status, ip_address, user_agent,
                 device_type, browser, operating_system, country, region, city,
                 isp, latitude, longitude, referer)
             VALUES
                (:user_id, :username, :status, :ip_address, :user_agent,
                 :device_type, :browser, :operating_system, :country, :region, :city,
                 :isp, :latitude, :longitude, :referer)",
            [
                'user_id' => $userId,
                'username' => mb_substr($username, 0, 100),
                'status' => $status,
                'ip_address' => anonymizeIpAddress($ipAddress),
                'user_agent' => $userAgent,
                'device_type' => $device['device_type'],
                'browser' => $device['browser'],
                'operating_system' => $device['operating_system'],
                'country' => $location['country'],
                'region' => $location['region'],
                'city' => $location['city'],
                'isp' => $location['isp'],
                'latitude' => $location['latitude'],
                'longitude' => $location['longitude'],
                'referer' => $referer !== '' ? $referer : null,
            ]
        );

        $activityMetadata = ['status' => $status];
        if (SORMS_ENABLE_IP_GEOLOCATION) {
            $activityMetadata['geolocation'] = [
                'country' => $location['country'],
                'region' => $location['region'],
                'city' => $location['city'],
            ];
        }
        logActivity('USER_LOGIN', $activityMetadata, $userId);
    } catch (Throwable $e) {
        // Logging must never block a login attempt.
        error_log('Login log error: ' . $e->getMessage());
    }
}

// ------------------------------------------------------------------
// ORGANIZATION OWNERSHIP AND PERMISSIONS
// ------------------------------------------------------------------

/**
 * Check whether the current user can manage an organization
 *
 * Admins can manage every organization. Recruiters can manage the
 * organizations they founded, administer, or requested.
 *
 * @param int $organizationId
 * @param int|null $userId
 * @return bool
 */
function canManageOrganization(int $organizationId, ?int $userId = null): bool
{
    $userId = $userId ?? getUserId();

    if (!$userId) {
        return false;
    }

    if (userHasRole('admin')) {
        return true;
    }

    $organization = Database::fetch(
        'SELECT admin_user_id, founder_user_id, requested_by
         FROM organizations WHERE id = :id',
        ['id' => $organizationId]
    );

    if (!$organization) {
        return false;
    }

    foreach (['admin_user_id', 'founder_user_id', 'requested_by'] as $column) {
        if (!empty($organization[$column]) && (int) $organization[$column] === $userId) {
            return true;
        }
    }

    return false;
}

/**
 * Check whether the current user can manage a campaign
 *
 * @param array $campaign
 * @return bool
 */
function canManageCampaign(array $campaign): bool
{
    if (userHasRole('admin')) {
        return true;
    }

    if (!userHasRole('recruiter') || empty($campaign['organization_id'])) {
        return false;
    }

    return canManageOrganization((int) $campaign['organization_id']);
}

/**
 * Get the organizations the current user is allowed to run campaigns for
 *
 * @param bool $onlyActive
 * @return array
 */
function getManageableOrganizations(bool $onlyActive = true): array
{
    $conditions = [];
    $params = [];

    if ($onlyActive) {
        $conditions[] = "status = 'active'";
    }

    if (!userHasRole('admin')) {
        $userId = getUserId();

        if (!$userId) {
            return [];
        }

        $conditions[] = '(admin_user_id = :owner_id OR founder_user_id = :founder_id OR requested_by = :requester_id)';
        $params['owner_id'] = $userId;
        $params['founder_id'] = $userId;
        $params['requester_id'] = $userId;
    }

    $sql = 'SELECT * FROM organizations';

    if ($conditions) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' ORDER BY name ASC';

    return Database::query($sql, $params);
}

/**
 * Human readable file size
 *
 * @param int $bytes
 * @return string
 */
function formatFileSize(int $bytes): string
{
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' MB';
    }

    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1) . ' KB';
    }

    return $bytes . ' B';
}

// ------------------------------------------------------------------
// URL HELPERS
// ------------------------------------------------------------------

/**
 * Resolve a URL to an absolute address inside the application
 *
 * Application-root paths (src/..., assets/...) are resolved from the
 * project root, everything else is resolved relative to the current page.
 *
 * @param string $url
 * @return string
 */
function resolveUrl(string $url): string
{
    if (preg_match('#^(https?:)?//#i', $url)) {
        return $url;
    }

    $base = rtrim(SORMS_URL, '/');

    if ($url === '') {
        return $base . '/';
    }

    if ($url[0] === '/') {
        return $base . $url;
    }

    foreach (['src/', 'templates/', 'assets/', 'db/', 'index.php'] as $appRoot) {
        if (strpos($url, $appRoot) === 0) {
            return $base . '/' . $url;
        }
    }

    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

    // Remove the application base path so it is not added twice.
    if ($base !== '' && strpos($scriptDir, $base) === 0) {
        $scriptDir = rtrim(substr($scriptDir, strlen($base)), '/');
    }

    return $base . $scriptDir . '/' . $url;
}

/**
 * Redirect the browser to another page and stop the script
 *
 * @param string $url
 */
function redirect(string $url): void
{
    if (!headers_sent()) {
        header('Location: ' . resolveUrl($url));
    }

    exit;
}

/**
 * Get the full URL of the current request
 *
 * @return string
 */
function currentUrl(): string
{
    $https = isset($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $uri = $_SERVER['REQUEST_URI'] ?? '/';

    return $scheme . '://' . $host . $uri;
}

// ------------------------------------------------------------------
// VALIDATION
// ------------------------------------------------------------------

/**
 * Validate an email address
 *
 * @param string $email
 * @return bool
 */
function validateEmail(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate a phone number
 *
 * @param string $phone
 * @return bool
 */
function validatePhone(string $phone): bool
{
    return (bool) preg_match('/^[0-9+][0-9\s\-().]{6,19}$/', $phone);
}

/**
 * Validate the length of a string
 *
 * @param string $value
 * @param int $min
 * @param int $max
 * @return bool
 */
function validateString(string $value, int $min = 1, int $max = 255): bool
{
    $length = mb_strlen(trim($value));

    return $length >= $min && $length <= $max;
}

/**
 * Validate a date in Y-m-d format
 *
 * @param string $date
 * @return bool
 */
function validateDate(string $date): bool
{
    if (trim($date) === '') {
        return false;
    }

    $parsed = DateTime::createFromFormat('Y-m-d', $date);

    return $parsed !== false && $parsed->format('Y-m-d') === $date;
}

/**
 * Check whether a table already contains a row matching the conditions
 *
 * @param string $table
 * @param array $conditions
 * @return bool
 */
function tableHasRows(string $table, array $conditions = []): bool
{
    $allowedTables = [
        'users', 'organizations', 'campaigns',
        'applicants', 'applications', 'notifications', 'application_history',
    ];

    if (!in_array($table, $allowedTables, true)) {
        throw new InvalidArgumentException('Invalid table name: ' . $table);
    }

    $conditionsSql = [];
    $params = [];

    foreach ($conditions as $column => $value) {
        if (!preg_match('/^[a-z_]+$/', (string) $column)) {
            throw new InvalidArgumentException('Invalid column name: ' . $column);
        }

        $conditionsSql[] = $column . ' = :' . $column;
        $params[':' . $column] = $value;
    }

    $sql = 'SELECT COUNT(*) FROM ' . $table;

    if ($conditionsSql) {
        $sql .= ' WHERE ' . implode(' AND ', $conditionsSql);
    }

    return (int) Database::value($sql, $params) > 0;
}

// ------------------------------------------------------------------
// SECURITY
// ------------------------------------------------------------------

/**
 * Get (and create when needed) the CSRF token of the current session
 *
 * @return string
 */
function csrfToken(): string
{
    startSession();

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * Verify a submitted CSRF token
 *
 * @param mixed $token
 * @return bool
 */
function verifyCsrfToken($token): bool
{
    startSession();

    if (empty($_SESSION['csrf_token']) || !is_string($token) || $token === '') {
        return false;
    }

    return hash_equals($_SESSION['csrf_token'], $token);
}
