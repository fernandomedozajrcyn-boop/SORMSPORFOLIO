<?php
require_once __DIR__ . '/functions.php';
defined('SORMS_VERSION') or define('SORMS_VERSION', '1.0.0');

// ✅ Initialize defaults so the page never crashes
$error = '';
$isRegistrationEnabled = true;   // default assumption

// ------------------------------------------------------------------
// DATABASE CONFIGURATION
// ------------------------------------------------------------------

// For local development with XAMPP/MySQL
define('DB_HOST', getenv('SORMS_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('SORMS_DB_NAME') ?: 'soroms_db');
define('DB_USER', getenv('SORMS_DB_USER') ?: 'root');
define('DB_PASS', getenv('SORMS_DB_PASS') ?: '');

// Configure production database credentials through the SORMS_DB_* environment variables.

// ------------------------------------------------------------------
// APPLICATION DEFAULTS
// ------------------------------------------------------------------

define('SORMS_SITE_NAME', 'Student Organization Recruitment System');
define('SORMS_TIMEZONE', 'Asia/Manila'); // Change to your timezone
date_default_timezone_set(SORMS_TIMEZONE);

// Private storage for uploaded verification documents
define('SORMS_STORAGE_PATH', __DIR__ . '/../storage');
define('SORMS_ORG_DOCUMENTS_PATH', SORMS_STORAGE_PATH . '/org_documents');
define('SORMS_MAX_DOCUMENT_SIZE', 5 * 1024 * 1024);
define('SORMS_ALLOWED_DOCUMENT_TYPES', [
    'application/pdf' => 'pdf',
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
]);
/**
 * Work out the URL path the application is served from.
 *
 * This is based on the requested script (SCRIPT_NAME) instead of the
 * filesystem path so that it keeps working when the project is reached
 * through a Windows junction/symlink in the Apache document root.
 */
$applicationUrlPath = '/';

if (PHP_SAPI !== 'cli') {
    $requestScript = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $requestDirectory = rtrim(str_replace('\\', '/', dirname($requestScript)), '/');

    if ($requestDirectory !== '' && $requestDirectory !== '.' && $requestDirectory !== '/') {
        $applicationUrlPath = $requestDirectory . '/';

        foreach (['/src/', '/templates/', '/db/', '/includes/'] as $marker) {
            $position = strpos($applicationUrlPath, $marker);
            if ($position !== false) {
                $applicationUrlPath = substr($applicationUrlPath, 0, $position + 1);
                break;
            }
        }
    }
}

define('SORMS_URL', $applicationUrlPath);
define('SORMS_ADMIN_EMAIL', 'admin@soroms.com');
define('SORMS_MAX_APPLICATIONS_PER_CAMPAIGN', 100);
defined('SORMS_REGISTRATION_ENABLED') or define('SORMS_REGISTRATION_ENABLED', true);
$sormsAnonymizeIp = getenv('SORMS_ANONYMIZE_IP');
defined('SORMS_ANONYMIZE_IP') or define(
    'SORMS_ANONYMIZE_IP',
    filter_var($sormsAnonymizeIp === false ? 'true' : $sormsAnonymizeIp, FILTER_VALIDATE_BOOLEAN)
);
$sormsEnableGeolocation = getenv('SORMS_ENABLE_IP_GEOLOCATION');
defined('SORMS_ENABLE_IP_GEOLOCATION') or define(
    'SORMS_ENABLE_IP_GEOLOCATION',
    filter_var($sormsEnableGeolocation === false ? 'false' : $sormsEnableGeolocation, FILTER_VALIDATE_BOOLEAN)
);
defined('SORMS_TRUSTED_PROXIES') or define(
    'SORMS_TRUSTED_PROXIES',
    (string) (getenv('SORMS_TRUSTED_PROXIES') ?: '')
);

// Session security
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Lax');

$sormsDebugValue = getenv('SORMS_DEBUG');
$sormsDebug = filter_var($sormsDebugValue === false ? 'false' : $sormsDebugValue, FILTER_VALIDATE_BOOLEAN);
error_reporting(E_ALL);
ini_set('display_errors', $sormsDebug ? '1' : '0');

// Autoloader
function soroms_autoload($class) {
    $prefix = 'Sorms\\';
    $base_dir = __DIR__ . '/../src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
}

spl_autoload_register('soroms_autoload');
