<?php
/**
 * Database connection handler for Student Organization Recruitment Management System
 */

require_once __DIR__ . '/config.php';

class Database
{
    private static $connection = null;

    /**
     * Get a single database connection instance (PDO)
     *
     * @return PDO
     * @throws PDOException
     */
    public static function getConnection(): PDO
    {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
            ];

            try {
                self::$connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                // In production, log the error instead of displaying it
                error_log('Database connection failed: ' . $e->getMessage());
                throw new PDOException('Database connection is currently unavailable.');
            }
        }

        return self::$connection;
    }

    /**
     * Get the last inserted ID
     *
     * @return int
     */
    public static function getLastInsertId(): int
    {
        return (int) self::getConnection()->lastInsertId();
    }

    /**
     * Begin a database transaction
     */
    public static function beginTransaction(): bool
    {
        return self::getConnection()->beginTransaction();
    }

    /**
     * Commit a database transaction
     */
    public static function commit(): bool
    {
        return self::getConnection()->commit();
    }

    /**
     * Rollback a database transaction
     */
    public static function rollBack(): bool
    {
        return self::getConnection()->rollBack();
    }

    /**
     * Execute a query and return the result
     *
     * @param string $sql
     * @param array $params
     * @param int $fetchMode
     * @return array
     */
    public static function query(string $sql, array $params = [], int $fetchMode = PDO::FETCH_ASSOC): array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll($fetchMode);
    }

    /**
     * Execute a query and return a single row
     *
     * @param string $sql
     * @param array $params
     * @return array|null
     */
    public static function fetch(string $sql, array $params = []): ?array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();

        return $row === false ? null : $row;
    }

    /**
     * Execute a query and return a single value
     *
     * @param string $sql
     * @param array $params
     * @return mixed
     */
    public static function value(string $sql, array $params = []): mixed
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn();
    }

    /**
     * Execute a statement (INSERT/UPDATE/DELETE)
     *
     * @param string $sql
     * @param array $params
     * @return int Number of affected rows
     */
    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }
}
