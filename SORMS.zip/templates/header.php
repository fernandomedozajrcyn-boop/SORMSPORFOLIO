<?php
/**
 * Header template
 */

$currentScript = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$applicationBase = rtrim(SORMS_URL, '/');
$currentPage = ltrim(substr($currentScript, strlen($applicationBase)), '/');

if ($currentPage === '') {
    $currentPage = 'index.php';
}

$activeClass = static function (string $path) use ($currentPage): string {
    return $currentPage === $path ? 'active' : '';
};

$unreadNotifications = isLoggedIn() ? getUnreadNotificationCount() : 0;
?>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo SORMS_URL; ?>">
            <?php echo SORMS_SITE_NAME; ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php if (isLoggedIn()): ?>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $activeClass('index.php'); ?>" href="<?php echo SORMS_URL; ?>">Home</a>
                    </li>
                    <?php if (userHasRole(['admin', 'recruiter'])): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/org/index.php'); ?>" href="<?php echo SORMS_URL; ?>src/org/index.php">Organizations</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $activeClass('src/campaign/index.php'); ?>" href="<?php echo SORMS_URL; ?>src/campaign/index.php">Campaigns</a>
                    </li>
                    <?php if (userHasRole(['admin', 'recruiter'])): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/screening/dashboard.php'); ?>" href="<?php echo SORMS_URL; ?>src/screening/dashboard.php">Screening</a>
                        </li>
                    <?php endif; ?>
                    <?php if (userHasRole(['admin', 'student'])): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/applicant/index.php'); ?>" href="<?php echo SORMS_URL; ?>src/applicant/index.php">My Applications</a>
                        </li>
                    <?php endif; ?>
                    <?php if (userHasRole('student')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/org/request.php'); ?>" href="<?php echo SORMS_URL; ?>src/org/request.php">Request Organization</a>
                        </li>
                    <?php endif; ?>
                    <?php if (userHasRole('admin')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/report/index.php'); ?>" href="<?php echo SORMS_URL; ?>src/report/index.php">Reports</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $activeClass('src/report/analytics.php'); ?>" href="<?php echo SORMS_URL; ?>src/report/analytics.php">Analytics</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $activeClass('src/notifications/index.php'); ?>" href="<?php echo SORMS_URL; ?>src/notifications/index.php">
                            Notifications
                            <?php if ($unreadNotifications > 0): ?>
                                <span class="badge bg-danger"><?php echo $unreadNotifications; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <?php echo htmlspecialchars(getUserName()); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (userHasRole(['admin', 'student'])): ?>
                                <li><a class="dropdown-item" href="<?php echo SORMS_URL; ?>src/applicant/profile.php">My Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo SORMS_URL; ?>src/auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            <?php else: ?>
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <?php if (in_array($currentPage, ['src/auth/login.php', 'src/auth/register.php'], true)): ?>
                        <li class="nav-item me-lg-2">
                            <a class="btn btn-outline-secondary btn-sm" href="<?php echo SORMS_URL; ?>">Home</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-primary btn-sm" href="<?php echo SORMS_URL; ?>src/auth/login.php">Login</a>
                    </li>
                    <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                        <a class="btn btn-primary btn-sm" href="<?php echo SORMS_URL; ?>src/auth/register.php">Register</a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>
