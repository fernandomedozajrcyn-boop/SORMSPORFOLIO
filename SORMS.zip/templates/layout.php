<?php
/**
 * Main layout template
 *
 * Usage:
 *   $page_title = 'My Page Title';
 *   $page_content = 'Your HTML here';
 *   include __DIR__ . '/layout.php';
 */

$page_title = $page_title ?? 'Student Organization Recruitment System';
$page_content = $page_content ?? '';
$page_csrf_token = $page_csrf_token ?? csrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(SORMS_SITE_NAME . ' - ' . $page_title); ?></title>
    <meta name="csrf-token" content="<?php echo htmlspecialchars($page_csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
    <meta name="analytics-endpoint" content="<?php echo htmlspecialchars(SORMS_URL . 'api/analytics/log-action.php', ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo SORMS_URL; ?>assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏛</text></svg>">
</head>
<body>
    <?php include __DIR__ . '/header.php'; ?>

    <main class="main-content <?php echo htmlspecialchars($page_main_class ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        <?php if (!empty(getFlash('success'))): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars(getFlash('success')); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty(getFlash('error'))): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars(getFlash('error')); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php echo $page_content; ?>
    </main>

    <?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
