<footer class="footer bg-dark text-light mt-5">
    <div class="container text-center">
        <p class="mb-0">
            &copy; <?php echo date('Y'); ?> <?php echo SORMS_SITE_NAME; ?>
            &nbsp;|&nbsp; Version <?php echo SORMS_VERSION; ?>
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo SORMS_URL; ?>assets/js/script.js"></script>
<?php echo $page_scripts ?? ''; ?>
