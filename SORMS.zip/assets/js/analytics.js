document.addEventListener('DOMContentLoaded', function () {
    const config = window.sormsAnalyticsConfig;
    const periodSelect = document.getElementById('analytics-period');
    const errorBox = document.getElementById('analytics-error');
    const loading = document.getElementById('analytics-loading');
    const updated = document.getElementById('analytics-updated');
    const colors = ['#1a73e8', '#34a853', '#f9ab00', '#d93025', '#7e57c2', '#00acc1', '#6c757d'];
    let trafficChart;
    let deviceChart;
    let osChart;

    function percentage(value, total) {
        return total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
    }

    function renderBreakdown(containerId, rows) {
        const container = document.getElementById(containerId);
        const total = rows.reduce(function (sum, row) { return sum + row.total; }, 0);
        container.replaceChildren();
        if (rows.length === 0) {
            const empty = document.createElement('p');
            empty.className = 'text-muted small mb-0';
            empty.textContent = 'No tracked data yet.';
            container.appendChild(empty);
            return;
        }
        rows.forEach(function (row, index) {
            const line = document.createElement('div');
            line.className = 'analytics-breakdown-row';
            const label = document.createElement('span');
            label.textContent = row.label;
            const value = document.createElement('strong');
            value.textContent = percentage(row.total, total) + '%';
            line.append(label, value);
            container.appendChild(line);
        });
    }

    function renderDoughnut(existingChart, canvasId, rows) {
        if (existingChart) {
            existingChart.destroy();
        }
        return new Chart(document.getElementById(canvasId), {
            type: 'doughnut',
            data: {
                labels: rows.map(function (row) { return row.label; }),
                datasets: [{
                    data: rows.map(function (row) { return row.total; }),
                    backgroundColor: rows.map(function (_, index) { return colors[index % colors.length]; }),
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '68%',
                plugins: {
                    legend: { position: 'bottom', labels: { usePointStyle: true, padding: 18 } },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                const total = context.dataset.data.reduce(function (sum, item) { return sum + item; }, 0);
                                return context.label + ': ' + percentage(context.raw, total) + '% (' + context.raw + ')';
                            }
                        }
                    }
                }
            }
        });
    }

    function updateDashboard(data) {
        const summary = data.summary;
        document.getElementById('metric-visitors').textContent = Number(summary.total_visitors).toLocaleString();
        document.getElementById('metric-downloads').textContent = Number(summary.total_downloads).toLocaleString();
        document.getElementById('metric-users').textContent = Number(summary.total_users).toLocaleString();
        document.getElementById('metric-conversion').textContent = summary.visitor_conversion_rate + '%';
        document.getElementById('metric-signup-rate').textContent = summary.signup_completion_rate + '%';
        document.getElementById('metric-login-rate').textContent = summary.login_success_rate + '%';

        if (trafficChart) {
            trafficChart.destroy();
        }
        trafficChart = new Chart(document.getElementById('traffic-chart'), {
            type: 'bar',
            data: {
                labels: data.trend.labels,
                datasets: [
                    {
                        type: 'line',
                        label: 'Page views',
                        data: data.trend.visitors,
                        borderColor: '#1a73e8',
                        backgroundColor: '#1a73e8',
                        tension: 0.3,
                        yAxisID: 'y',
                        pointRadius: 2
                    },
                    {
                        label: 'PDF downloads',
                        data: data.trend.downloads,
                        backgroundColor: '#34a853',
                        borderRadius: 4,
                        yAxisID: 'y'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: { legend: { position: 'bottom' } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });

        deviceChart = renderDoughnut(deviceChart, 'device-chart', data.devices);
        osChart = renderDoughnut(osChart, 'os-chart', data.operating_systems);
        renderBreakdown('device-breakdown', data.devices);
        renderBreakdown('os-breakdown', data.operating_systems);
        const timestamp = new Date(data.generated_at);
        updated.textContent = 'Updated ' + timestamp.toLocaleTimeString();
        loading.hidden = true;
        errorBox.hidden = true;
    }

    async function loadDashboard() {
        errorBox.hidden = true;
        try {
            const response = await fetch(config.api_url + '?period=' + encodeURIComponent(periodSelect.value), {
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                cache: 'no-store'
            });
            const result = await response.json().catch(function () { return {}; });
            if (!response.ok) {
                throw new Error(result.error || 'Unable to load analytics.');
            }
            updateDashboard(result);
        } catch (error) {
            errorBox.textContent = error.message || 'Unable to load analytics. Please try again.';
            errorBox.hidden = false;
            loading.hidden = true;
        }
    }

    periodSelect.addEventListener('change', loadDashboard);
    loadDashboard();
    window.setInterval(loadDashboard, 60000);
});
