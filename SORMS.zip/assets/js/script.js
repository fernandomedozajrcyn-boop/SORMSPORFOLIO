/**
 * Student Organization Recruitment Management System - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    const analyticsEndpoint = document.querySelector('meta[name="analytics-endpoint"]')?.content;
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
    if (analyticsEndpoint && csrfToken) {
        fetch(analyticsEndpoint, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                event_type: 'PAGE_VIEW',
                page_path: window.location.pathname
            })
        }).catch(function () {});
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function (tooltipEl) {
        new bootstrap.Tooltip(tooltipEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.forEach(function (popoverEl) {
        new bootstrap.Popover(popoverEl);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        const timer = setTimeout(function () {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);

        // Reset timer if alert is clicked (for dismissible alerts)
        alert.addEventListener('click', function () {
            clearTimeout(timer);
        });
    });

    const navbarToggle = document.querySelector('.navbar-toggler[data-bs-target]');
    if (navbarToggle && (!window.bootstrap || !window.bootstrap.Collapse)) {
        const navbar = document.querySelector(navbarToggle.getAttribute('data-bs-target'));
        if (navbar) {
            navbarToggle.addEventListener('click', function () {
                const isOpen = navbar.classList.toggle('show');
                navbarToggle.setAttribute('aria-expanded', String(isOpen));
            });
        }
    }

    const accessTabs = Array.from(document.querySelectorAll('[data-access-target]'));
    accessTabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            const targetId = tab.getAttribute('data-access-target');
            accessTabs.forEach(function (item) {
                const selected = item === tab;
                item.classList.toggle('active', selected);
                item.setAttribute('aria-selected', String(selected));
                item.tabIndex = selected ? 0 : -1;
            });
            document.querySelectorAll('.access-panel').forEach(function (panel) {
                panel.hidden = panel.id !== targetId;
            });
        });

        tab.addEventListener('keydown', function (event) {
            if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                const currentIndex = accessTabs.indexOf(tab);
                const direction = event.key === 'ArrowRight' ? 1 : -1;
                const nextTab = accessTabs[(currentIndex + direction + accessTabs.length) % accessTabs.length];
                nextTab.focus();
                nextTab.click();
            }
        });
    });

    const tutorialTabs = Array.from(document.querySelectorAll('.tutorial-tabs [role="tab"]'));
    tutorialTabs.forEach(function (tab) {
        const panel = document.getElementById(tab.getAttribute('aria-controls'));
        if (panel && !tab.classList.contains('active')) {
            panel.hidden = true;
        }

        tab.addEventListener('click', function () {
            tutorialTabs.forEach(function (item) {
                const selected = item === tab;
                item.classList.toggle('active', selected);
                item.setAttribute('aria-selected', String(selected));
                item.tabIndex = selected ? 0 : -1;
                const itemPanel = document.getElementById(item.getAttribute('aria-controls'));
                if (itemPanel) {
                    itemPanel.hidden = !selected;
                    itemPanel.classList.toggle('active', selected);
                    itemPanel.classList.toggle('show', selected);
                }
            });
        });

        tab.addEventListener('keydown', function (event) {
            if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                const currentIndex = tutorialTabs.indexOf(tab);
                const direction = event.key === 'ArrowRight' ? 1 : -1;
                const nextTab = tutorialTabs[(currentIndex + direction + tutorialTabs.length) % tutorialTabs.length];
                nextTab.focus();
                nextTab.click();
            }
        });
    });

    const passwordInput = document.querySelector('#password[data-password-strength]');
    const strengthMeter = document.querySelector('#password-strength-meter');
    const strengthLabel = document.querySelector('#password-strength');
    if (passwordInput && strengthMeter && strengthLabel) {
        passwordInput.addEventListener('input', function () {
            const value = passwordInput.value;
            const score = [
                value.length >= 8,
                /[A-Za-z]/.test(value),
                /\d/.test(value),
                value.length >= 12 && /[^A-Za-z0-9]/.test(value)
            ].filter(Boolean).length;
            const labels = ['Use at least 8 characters, a letter, and a number.', 'Weak', 'Fair', 'Good', 'Strong'];
            strengthMeter.style.width = (score * 25) + '%';
            strengthMeter.setAttribute('aria-valuenow', String(score));
            strengthMeter.className = 'progress-bar strength-' + score;
            strengthLabel.textContent = labels[score];
        });
    }

    document.querySelectorAll('.portfolio-download-link').forEach(function (link) {
        link.addEventListener('click', function (event) {
            event.preventDefault();
            const trackUrl = link.getAttribute('data-track-url');
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
            const downloadUrl = link.href;
            const download = function (trackingToken) {
                if (typeof trackingToken === 'string' && /^[a-f0-9]{48}$/.test(trackingToken)) {
                    const separator = downloadUrl.includes('?') ? '&' : '?';
                    window.location.assign(downloadUrl + separator + 'tracking_token=' + encodeURIComponent(trackingToken));
                    return;
                }
                window.location.assign(downloadUrl);
            };

            link.setAttribute('aria-busy', 'true');
            fetch(trackUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken || ''
                },
                body: JSON.stringify({
                    event_type: 'PORTFOLIO_PDF_DOWNLOAD',
                    screen_resolution: window.screen.width + 'x' + window.screen.height,
                    referrer: window.location.href
                })
            }).then(function (response) {
                if (!response.ok) {
                    download();
                    return;
                }
                return response.json().then(function (result) {
                    download(result.download_token);
                });
            }).catch(function () {
                download();
            });
        });
    });
});
