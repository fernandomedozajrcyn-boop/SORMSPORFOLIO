<?php

function analyticsPercent(float $numerator, float $denominator): float
{
    return $denominator > 0 ? round(($numerator / $denominator) * 100, 1) : 0.0;
}

/**
 * Return the admin dashboard metrics and a zero-filled activity series.
 *
 * @return array<string, mixed>
 */
function getAnalyticsDashboardData(string $period = 'daily'): array
{
    $period = in_array($period, ['daily', 'weekly', 'monthly'], true) ? $period : 'daily';
    $today = new DateTimeImmutable('today', new DateTimeZone('UTC'));

    if ($period === 'weekly') {
        $start = $today->modify('monday this week')->modify('-11 weeks');
        $bucketExpression = "DATE_SUB(DATE(created_at), INTERVAL WEEKDAY(created_at) DAY)";
        $bucketCount = 12;
        $bucketStep = 'week';
    } elseif ($period === 'monthly') {
        $start = $today->modify('first day of this month')->modify('-11 months');
        $bucketExpression = "DATE_FORMAT(created_at, '%Y-%m-01')";
        $bucketCount = 12;
        $bucketStep = 'month';
    } else {
        $start = $today->modify('-29 days');
        $bucketExpression = 'DATE(created_at)';
        $bucketCount = 30;
        $bucketStep = 'day';
    }

    $summary = [
        'total_visitors' => (int) Database::value(
            "SELECT COUNT(*) FROM activity_logs WHERE event_type = 'PAGE_VIEW'"
        ),
        'total_downloads' => (int) Database::value(
            "SELECT COUNT(*) FROM activity_logs WHERE event_type = 'PORTFOLIO_PDF_DOWNLOAD'"
        ),
        'total_users' => (int) Database::value('SELECT COUNT(*) FROM users'),
    ];

    $loginMetrics = Database::fetch(
        "SELECT COUNT(*) AS attempts,
                COALESCE(SUM(JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.status')) = 'success'), 0) AS successes
         FROM activity_logs
         WHERE event_type = 'USER_LOGIN'"
    );
    $signupMetrics = Database::fetch(
        "SELECT COUNT(*) AS attempts,
                COALESCE(SUM(JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.status')) = 'success'), 0) AS successes
         FROM activity_logs
         WHERE event_type = 'USER_SIGNUP'"
    );
    $networkMetrics = Database::fetch(
        "SELECT COUNT(*) AS visitor_networks,
                COALESCE(SUM(downloaded = 1), 0) AS downloader_networks
         FROM (
             SELECT ip_address,
                    MAX(event_type = 'PAGE_VIEW') AS visited,
                    MAX(event_type = 'PORTFOLIO_PDF_DOWNLOAD') AS downloaded
             FROM activity_logs
             WHERE event_type IN ('PAGE_VIEW', 'PORTFOLIO_PDF_DOWNLOAD')
               AND ip_address IS NOT NULL
             GROUP BY ip_address
         ) AS visitor_activity
         WHERE visited = 1"
    );

    $summary['login_success_rate'] = analyticsPercent(
        (float) ($loginMetrics['successes'] ?? 0),
        (float) ($loginMetrics['attempts'] ?? 0)
    );
    $summary['signup_completion_rate'] = analyticsPercent(
        (float) ($signupMetrics['successes'] ?? 0),
        (float) ($signupMetrics['attempts'] ?? 0)
    );
    $summary['visitor_conversion_rate'] = analyticsPercent(
        (float) ($networkMetrics['downloader_networks'] ?? 0),
        (float) ($networkMetrics['visitor_networks'] ?? 0)
    );
    $summary['tracked_visitor_networks'] = (int) ($networkMetrics['visitor_networks'] ?? 0);

    $devices = Database::query(
        "SELECT COALESCE(NULLIF(device_type, ''), 'Unknown') AS label, COUNT(*) AS total
         FROM activity_logs
         WHERE event_type = 'PAGE_VIEW'
         GROUP BY COALESCE(NULLIF(device_type, ''), 'Unknown')
         ORDER BY total DESC, label ASC"
    );
    $operatingSystems = Database::query(
        "SELECT COALESCE(NULLIF(operating_system, ''), 'Unknown') AS label, COUNT(*) AS total
         FROM activity_logs
         WHERE event_type = 'PAGE_VIEW'
         GROUP BY COALESCE(NULLIF(operating_system, ''), 'Unknown')
         ORDER BY total DESC, label ASC"
    );
    $trendRows = Database::query(
        "SELECT {$bucketExpression} AS bucket,
                SUM(event_type = 'PAGE_VIEW') AS visitors,
                SUM(event_type = 'PORTFOLIO_PDF_DOWNLOAD') AS downloads
         FROM activity_logs
         WHERE event_type IN ('PAGE_VIEW', 'PORTFOLIO_PDF_DOWNLOAD')
           AND created_at >= :start_at
         GROUP BY bucket
         ORDER BY bucket ASC",
        ['start_at' => $start->format('Y-m-d 00:00:00')]
    );
    $trendByBucket = [];
    foreach ($trendRows as $row) {
        $trendByBucket[(string) $row['bucket']] = [
            'visitors' => (int) $row['visitors'],
            'downloads' => (int) $row['downloads'],
        ];
    }

    $labels = [];
    $visitors = [];
    $downloads = [];
    $cursor = $start;
    for ($index = 0; $index < $bucketCount; $index++) {
        $bucket = $cursor->format('Y-m-d');
        $labels[] = $period === 'monthly' ? $cursor->format('M Y') : $cursor->format('M j');
        $visitors[] = $trendByBucket[$bucket]['visitors'] ?? 0;
        $downloads[] = $trendByBucket[$bucket]['downloads'] ?? 0;
        $cursor = $bucketStep === 'week'
            ? $cursor->modify('+1 week')
            : ($bucketStep === 'month' ? $cursor->modify('+1 month') : $cursor->modify('+1 day'));
    }

    return [
        'generated_at' => gmdate(DATE_ATOM),
        'period' => $period,
        'summary' => $summary,
        'devices' => array_map(static function (array $row): array {
            return ['label' => $row['label'], 'total' => (int) $row['total']];
        }, $devices),
        'operating_systems' => array_map(static function (array $row): array {
            return ['label' => $row['label'], 'total' => (int) $row['total']];
        }, $operatingSystems),
        'trend' => [
            'labels' => $labels,
            'visitors' => $visitors,
            'downloads' => $downloads,
        ],
    ];
}
