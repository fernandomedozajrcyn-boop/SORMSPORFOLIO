<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');
startSession();

const SORMS_BACKUP_MAX_UPLOAD_BYTES = 104857600;
const SORMS_BACKUP_MAX_ARCHIVE_BYTES = 536870912;
const SORMS_BACKUP_MAX_ENTRIES = 10000;

$requestMethod = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
if (!in_array($requestMethod, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    http_response_code(405);
    exit('Method not allowed.');
}

function backupTableNames(): array
{
    $rows = Database::query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    $names = [];
    foreach ($rows as $row) {
        $name = (string) reset($row);
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
            throw new RuntimeException('The database contains an unsupported table name.');
        }
        $names[] = $name;
    }
    sort($names);
    return $names;
}

function backupTableColumns(string $table): array
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        throw new RuntimeException('The backup contains an invalid table name.');
    }
    return array_map(
        static fn (array $column): string => (string) $column['Field'],
        Database::query('SHOW COLUMNS FROM `' . $table . '`')
    );
}

function backupAddStorageFiles(ZipArchive $zip, string $storageRoot): array
{
    $root = realpath($storageRoot);
    if ($root === false || !is_dir($root)) {
        throw new RuntimeException('The private storage directory is unavailable.');
    }

    $files = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($iterator as $item) {
        $path = $item->getPathname();
        if (is_link($path)) {
            throw new RuntimeException('Private storage contains a symbolic link; backup stopped.');
        }
        if (!$item->isFile()) {
            continue;
        }
        $relative = substr($path, strlen($root) + 1);
        $relative = str_replace(DIRECTORY_SEPARATOR, '/', $relative);
        if (
            $relative === '.htaccess'
            || strpos($relative, '/.htaccess') !== false
            || $relative === 'backups'
            || strpos($relative, 'backups/') === 0
        ) {
            continue;
        }

        $archiveName = 'uploads/' . $relative;
        if (!$zip->addFile($path, $archiveName)) {
            throw new RuntimeException('A private upload could not be added to the backup.');
        }
        $files[] = $archiveName;
    }
    sort($files);
    return $files;
}

function createSystemBackup(string $destination): void
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('The PHP zip extension is required for backup and restore.');
    }

    $zip = new ZipArchive();
    if ($zip->open($destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('Unable to create the backup archive.');
    }
    $temporaryFiles = [];
    try {
        $tables = [];
        $connection = Database::getConnection();
        foreach (backupTableNames() as $table) {
            $columns = backupTableColumns($table);
            $temporaryFile = tempnam(sys_get_temp_dir(), 'sorms-table-');
            if ($temporaryFile === false) {
                throw new RuntimeException('Unable to stage database backup data.');
            }
            $temporaryFiles[] = $temporaryFile;
            $output = fopen($temporaryFile, 'wb');
            if ($output === false) {
                throw new RuntimeException('Unable to write database backup data.');
            }
            $statement = $connection->query('SELECT * FROM `' . $table . '`');
            while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                $encodedRow = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
                if ($encodedRow === false || fwrite($output, $encodedRow . "\n") === false) {
                    fclose($output);
                    throw new RuntimeException('Unable to serialize database backup data.');
                }
            }
            fclose($output);

            $archiveName = 'database/' . $table . '.jsonl';
            if (!$zip->addFile($temporaryFile, $archiveName)) {
                throw new RuntimeException('Unable to add database data to the backup.');
            }
            $tables[] = ['name' => $table, 'columns' => $columns, 'file' => $archiveName];
        }

        $storageFiles = backupAddStorageFiles($zip, SORMS_STORAGE_PATH);
        $manifest = [
            'format' => 'sorms-backup',
            'version' => 1,
            'created_at_utc' => gmdate('Y-m-d\TH:i:s\Z'),
            'tables' => $tables,
            'uploads' => $storageFiles,
        ];
        if (!$zip->addFromString('manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
            throw new RuntimeException('Unable to write the backup manifest.');
        }
        if (!$zip->close()) {
            throw new RuntimeException('Unable to finish the backup archive.');
        }
    } catch (Throwable $exception) {
        $zip->close();
        throw $exception;
    } finally {
        foreach ($temporaryFiles as $temporaryFile) {
            if (is_file($temporaryFile)) {
                unlink($temporaryFile);
            }
        }
    }
}

function backupRemoveDirectory(string $path): void
{
    if (!is_dir($path) || is_link($path)) {
        if (file_exists($path) || is_link($path)) {
            unlink($path);
        }
        return;
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isDir() && !$item->isLink()) {
            rmdir($item->getPathname());
        } else {
            unlink($item->getPathname());
        }
    }
    rmdir($path);
}

function backupCopyDirectory(string $source, string $destination): void
{
    if (!is_dir($source)) {
        return;
    }
    if (!is_dir($destination) && !mkdir($destination, 0700, true) && !is_dir($destination)) {
        throw new RuntimeException('Unable to preserve existing recovery backups.');
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isLink()) {
            throw new RuntimeException('The backup directory contains a symbolic link.');
        }
        $relative = substr($item->getPathname(), strlen($source) + 1);
        $target = $destination . DIRECTORY_SEPARATOR . $relative;
        if ($item->isDir()) {
            if (!is_dir($target) && !mkdir($target, 0700, true) && !is_dir($target)) {
                throw new RuntimeException('Unable to preserve existing recovery backups.');
            }
        } elseif (!copy($item->getPathname(), $target)) {
            throw new RuntimeException('Unable to preserve an existing recovery backup.');
        }
    }
}

function backupValidateAndStage(string $archivePath, string $stageRoot): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('The PHP zip extension is required for backup and restore.');
    }
    $zip = new ZipArchive();
    if ($zip->open($archivePath) !== true) {
        throw new RuntimeException('The uploaded file is not a readable ZIP archive.');
    }

    try {
        if ($zip->numFiles < 1 || $zip->numFiles > SORMS_BACKUP_MAX_ENTRIES) {
            throw new RuntimeException('The backup archive has an unsupported number of files.');
        }
        $manifestContent = $zip->getFromName('manifest.json');
        $manifest = is_string($manifestContent) ? json_decode($manifestContent, true) : null;
        if (
            !is_array($manifest)
            || ($manifest['format'] ?? '') !== 'sorms-backup'
            || ($manifest['version'] ?? 0) !== 1
            || !is_array($manifest['tables'] ?? null)
            || !is_array($manifest['uploads'] ?? null)
        ) {
            throw new RuntimeException('The archive is not a supported system backup.');
        }

        $expectedEntries = ['manifest.json' => true];
        $tableMap = [];
        foreach ($manifest['tables'] as $tableInfo) {
            if (
                !is_array($tableInfo)
                || !is_string($tableInfo['name'] ?? null)
                || !preg_match('/^[A-Za-z0-9_]+$/', $tableInfo['name'])
                || !is_array($tableInfo['columns'] ?? null)
                || ($tableInfo['file'] ?? '') !== 'database/' . $tableInfo['name'] . '.jsonl'
                || isset($tableMap[$tableInfo['name']])
            ) {
                throw new RuntimeException('The backup manifest contains an invalid table definition.');
            }
            foreach ($tableInfo['columns'] as $column) {
                if (!is_string($column) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
                    throw new RuntimeException('The backup manifest contains an invalid column name.');
                }
            }
            $tableMap[$tableInfo['name']] = $tableInfo;
            $expectedEntries[$tableInfo['file']] = true;
        }

        $uploadNames = [];
        foreach ($manifest['uploads'] as $uploadName) {
            if (
                !is_string($uploadName)
                || !str_starts_with($uploadName, 'uploads/')
                || strpos($uploadName, '\\') !== false
                || preg_match('~(^|/)\.\.?(/|$)|(^/)|:|\x00~', $uploadName)
                || str_starts_with($uploadName, 'uploads/backups/')
                || substr($uploadName, -1) === '/'
                || strpos($uploadName, '/.htaccess') !== false
                || basename($uploadName) === '.htaccess'
                || isset($expectedEntries[$uploadName])
            ) {
                throw new RuntimeException('The backup manifest contains an invalid upload path.');
            }
            $uploadNames[$uploadName] = true;
            $expectedEntries[$uploadName] = true;
        }

        $totalUncompressedBytes = 0;
        $seenEntries = [];
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $name = $zip->getNameIndex($index);
            $stat = $zip->statIndex($index);
            if (
                !is_string($name)
                || !is_array($stat)
                || !isset($expectedEntries[$name])
                || isset($seenEntries[$name])
                || strpos($name, '\\') !== false
            ) {
                throw new RuntimeException('The archive contains an unexpected or duplicate entry.');
            }
            $seenEntries[$name] = true;
            $totalUncompressedBytes += (int) ($stat['size'] ?? 0);
            if ($totalUncompressedBytes > SORMS_BACKUP_MAX_ARCHIVE_BYTES) {
                throw new RuntimeException('The uncompressed backup exceeds the allowed size.');
            }
            if (method_exists($zip, 'getExternalAttributesIndex')) {
                $system = 0;
                $attributes = 0;
                if ($zip->getExternalAttributesIndex($index, $system, $attributes) && $system === ZipArchive::OPSYS_UNIX) {
                    $fileType = ($attributes >> 16) & 0170000;
                    if ($fileType !== 0 && $fileType !== 0100000) {
                        throw new RuntimeException('The archive contains an unsupported special file.');
                    }
                }
            }
        }
        if (count($seenEntries) !== count($expectedEntries)) {
            throw new RuntimeException('The archive is missing one or more declared files.');
        }

        $currentTables = backupTableNames();
        $archiveTables = array_keys($tableMap);
        sort($archiveTables);
        if ($currentTables !== $archiveTables) {
            throw new RuntimeException('The backup database schema does not match this installation.');
        }
        foreach ($tableMap as $table => $tableInfo) {
            if (backupTableColumns($table) !== $tableInfo['columns']) {
                throw new RuntimeException('The backup database schema does not match this installation.');
            }
        }

        $uploadStage = $stageRoot . DIRECTORY_SEPARATOR . 'uploads';
        if (!mkdir($uploadStage, 0700, true) && !is_dir($uploadStage)) {
            throw new RuntimeException('Unable to create a private restore staging directory.');
        }
        $stagedTableFiles = [];
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $name = $zip->getNameIndex($index);
            if ($name === 'manifest.json') {
                continue;
            }
            $relative = substr($name, strlen('uploads/'));
            $target = str_starts_with($name, 'uploads/')
                ? $uploadStage . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative)
                : $stageRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $name);
            $parent = dirname($target);
            if (!is_dir($parent) && !mkdir($parent, 0700, true) && !is_dir($parent)) {
                throw new RuntimeException('Unable to stage a backup file.');
            }
            $source = $zip->getStream($name);
            $output = fopen($target, 'wb');
            if ($source === false || $output === false) {
                if (is_resource($source)) {
                    fclose($source);
                }
                throw new RuntimeException('Unable to read a file from the backup archive.');
            }
            $copiedBytes = stream_copy_to_stream($source, $output, SORMS_BACKUP_MAX_ARCHIVE_BYTES + 1);
            fclose($source);
            fclose($output);
            if ($copiedBytes === false || $copiedBytes !== (int) $zip->statName($name)['size']) {
                throw new RuntimeException('A backup file could not be extracted completely.');
            }
            if (str_starts_with($name, 'database/')) {
                $table = substr($name, strlen('database/'), -strlen('.jsonl'));
                $stagedTableFiles[$table] = $target;
            }
        }

        foreach ($tableMap as $table => $tableInfo) {
            $file = $stagedTableFiles[$table] ?? '';
            if ($file === '' || !is_file($file)) {
                throw new RuntimeException('A database table backup is missing.');
            }
            $input = fopen($file, 'rb');
            if ($input === false) {
                throw new RuntimeException('Unable to validate database backup data.');
            }
            while (($line = fgets($input)) !== false) {
                $row = json_decode($line, true);
                if (
                    !is_array($row)
                    || array_keys($row) !== $tableInfo['columns']
                ) {
                    fclose($input);
                    throw new RuntimeException('Database backup data does not match the current schema.');
                }
                foreach ($row as $value) {
                    if (!is_scalar($value) && $value !== null) {
                        fclose($input);
                        throw new RuntimeException('The backup contains an unsupported database value.');
                    }
                }
            }
            fclose($input);
        }

        $zip->close();
        return [
            'manifest' => $manifest,
            'table_files' => $stagedTableFiles,
            'upload_stage' => $uploadStage,
        ];
    } catch (Throwable $exception) {
        $zip->close();
        throw $exception;
    }
}

function restoreSystemBackup(array $staged, string $recoveryArchive): void
{
    $storageRoot = realpath(SORMS_STORAGE_PATH);
    if ($storageRoot === false || !is_dir($storageRoot)) {
        throw new RuntimeException('The private storage directory is unavailable.');
    }
    $backupDirectory = $storageRoot . DIRECTORY_SEPARATOR . 'backups';
    if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0700, true) && !is_dir($backupDirectory)) {
        throw new RuntimeException('Unable to create the private recovery-backup directory.');
    }
    createSystemBackup($recoveryArchive);

    $stageRoot = dirname($staged['upload_stage']);
    $newStorage = $staged['upload_stage'];
    backupCopyDirectory($backupDirectory, $newStorage . DIRECTORY_SEPARATOR . 'backups');
    $rootProtection = $storageRoot . DIRECTORY_SEPARATOR . '.htaccess';
    if (is_file($rootProtection) && !copy($rootProtection, $newStorage . DIRECTORY_SEPARATOR . '.htaccess')) {
        throw new RuntimeException('Unable to preserve private storage access controls.');
    }
    $protectionIterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($storageRoot, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($protectionIterator as $item) {
        if ($item->isLink()) {
            throw new RuntimeException('Private storage contains a symbolic link; restore stopped.');
        }
        if ($item->isFile() && $item->getFilename() === '.htaccess') {
            $relative = substr($item->getPathname(), strlen($storageRoot) + 1);
            $target = $newStorage . DIRECTORY_SEPARATOR . $relative;
            $targetDirectory = dirname($target);
            if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0700, true) && !is_dir($targetDirectory)) {
                throw new RuntimeException('Unable to preserve private storage access controls.');
            }
            if (!copy($item->getPathname(), $target)) {
                throw new RuntimeException('Unable to preserve private storage access controls.');
            }
        }
    }

    $oldStorage = $stageRoot . DIRECTORY_SEPARATOR . 'previous-storage';
    $connection = Database::getConnection();
    $connection->exec('SET FOREIGN_KEY_CHECKS=0');
    $storageMoved = false;
    $newStorageInstalled = false;
    try {
        $connection->beginTransaction();
        foreach ($staged['manifest']['tables'] as $tableInfo) {
            $table = $tableInfo['name'];
            $connection->exec('DELETE FROM `' . $table . '`');
        }
        foreach ($staged['manifest']['tables'] as $tableInfo) {
            $table = $tableInfo['name'];
            $columns = $tableInfo['columns'];
            $columnSql = implode(', ', array_map(static fn (string $column): string => '`' . $column . '`', $columns));
            $placeholders = implode(', ', array_fill(0, count($columns), '?'));
            $insert = $connection->prepare('INSERT INTO `' . $table . '` (' . $columnSql . ') VALUES (' . $placeholders . ')');
            $input = fopen($staged['table_files'][$table], 'rb');
            if ($input === false) {
                throw new RuntimeException('Unable to read staged database data.');
            }
            while (($line = fgets($input)) !== false) {
                $row = json_decode($line, true);
                $insert->execute(array_values($row));
            }
            fclose($input);
        }

        if (!rename($storageRoot, $oldStorage)) {
            throw new RuntimeException('Unable to stage the current private uploads for replacement.');
        }
        $storageMoved = true;
        if (!rename($newStorage, $storageRoot)) {
            rename($oldStorage, $storageRoot);
            $storageMoved = false;
            throw new RuntimeException('Unable to install the restored private uploads.');
        }
        $newStorageInstalled = true;
        $connection->commit();
    } catch (Throwable $exception) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        if ($newStorageInstalled) {
            backupRemoveDirectory($storageRoot);
        }
        if ($storageMoved && is_dir($oldStorage)) {
            rename($oldStorage, $storageRoot);
        }
        throw $exception;
    } finally {
        try {
            $connection->exec('SET FOREIGN_KEY_CHECKS=1');
        } catch (Throwable $resetException) {
            error_log('Unable to reset foreign key checks after restore: ' . $resetException->getMessage());
        }
    }

    try {
        backupRemoveDirectory($oldStorage);
    } catch (Throwable $cleanupException) {
        error_log('Unable to remove the previous storage directory after restore: ' . $cleanupException->getMessage());
    }
}

$errorMessage = '';
$successMessage = '';
$zipAvailable = class_exists('ZipArchive');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && ($_GET['action'] ?? '') === 'download') {
    $temporaryArchive = '';
    try {
        $temporaryArchive = tempnam(sys_get_temp_dir(), 'sorms-backup-');
        if ($temporaryArchive === false) {
            throw new RuntimeException('Unable to allocate a temporary backup archive.');
        }
        createSystemBackup($temporaryArchive);
        $archiveStream = fopen($temporaryArchive, 'rb');
        if ($archiveStream === false) {
            throw new RuntimeException('Unable to read the completed backup archive.');
        }
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="sorms-backup-' . gmdate('Y-m-d-His') . '.zip"');
        header('Content-Length: ' . filesize($temporaryArchive));
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        fpassthru($archiveStream);
        fclose($archiveStream);
        unlink($temporaryArchive);
        exit;
    } catch (Throwable $exception) {
        if ($temporaryArchive !== '' && is_file($temporaryArchive)) {
            unlink($temporaryArchive);
        }
        error_log('System backup failed: ' . $exception->getMessage());
        if (!class_exists('ZipArchive')) {
            http_response_code(503);
            exit('Backup is unavailable because the PHP zip extension is disabled. Enable extension=zip and restart Apache.');
        }
        http_response_code(500);
        exit('Unable to create the backup. Check the server log for details.');
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        $errorMessage = 'The request could not be verified. Reload the page and try again.';
    } elseif (!$zipAvailable) {
        $errorMessage = 'Backup and restore require the PHP zip extension to be enabled.';
    } elseif (($_POST['confirmation'] ?? '') !== 'RESTORE') {
        $errorMessage = 'Type RESTORE exactly to confirm replacing the current database and uploaded files.';
    } elseif (
        !isset($_FILES['backup_file'])
        || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK
        || (int) $_FILES['backup_file']['size'] > SORMS_BACKUP_MAX_UPLOAD_BYTES
        || !is_uploaded_file($_FILES['backup_file']['tmp_name'])
    ) {
        $errorMessage = 'Select a valid backup ZIP no larger than 100 MB.';
    } else {
        $stageRoot = '';
        $recoveryArchive = '';
        try {
            $stageRoot = tempnam(dirname(SORMS_STORAGE_PATH), '.sorms-restore-');
            if ($stageRoot === false || !unlink($stageRoot) || !mkdir($stageRoot, 0700)) {
                throw new RuntimeException('Unable to create a private restore staging directory.');
            }
            file_put_contents($stageRoot . DIRECTORY_SEPARATOR . '.htaccess', "Require all denied\n", LOCK_EX);
            if (!is_file($stageRoot . DIRECTORY_SEPARATOR . '.htaccess')) {
                throw new RuntimeException('Unable to protect the private restore staging directory.');
            }
            $archive = backupValidateAndStage($_FILES['backup_file']['tmp_name'], $stageRoot);

            $storageRoot = realpath(SORMS_STORAGE_PATH);
            if ($storageRoot === false) {
                throw new RuntimeException('The private storage directory is unavailable.');
            }
            $backupDirectory = $storageRoot . DIRECTORY_SEPARATOR . 'backups';
            if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0700, true) && !is_dir($backupDirectory)) {
                throw new RuntimeException('Unable to create the private recovery-backup directory.');
            }
            $recoveryArchive = $backupDirectory . DIRECTORY_SEPARATOR . 'pre-restore-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.zip';
            restoreSystemBackup($archive, $recoveryArchive);
            $successMessage = 'Restore completed. A pre-restore safety archive was saved in the private storage/backups directory.';
        } catch (Throwable $exception) {
            error_log('System restore failed: ' . $exception->getMessage());
            $errorMessage = 'Restore failed. The system attempted to preserve the existing database and uploads; check the server log and recovery archive before retrying.';
        } finally {
            if ($stageRoot !== '' && is_dir($stageRoot)) {
                backupRemoveDirectory($stageRoot);
            }
        }
    }
}

$page_title = 'Backup and Restore';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Backup and Restore</h1>
        <p class="description">Create an archive of database records and private uploads, or restore a compatible archive.</p>
    </div>
</div>

<?php if ($errorMessage !== ''): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>
<?php if ($successMessage !== ''): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($successMessage, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>
<?php if (!$zipAvailable): ?>
    <div class="alert alert-warning">Enable the PHP zip extension in the web server's PHP configuration to use backup and restore.</div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header"><h2>Create Backup</h2></div>
            <div class="card-body">
                <p>The ZIP contains database table data and files in private storage. Keep the downloaded archive in a secure location.</p>
                <a class="btn btn-primary <?php echo $zipAvailable ? '' : 'disabled'; ?>" href="?action=download" <?php echo $zipAvailable ? '' : 'aria-disabled="true"'; ?>>Download Backup ZIP</a>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header"><h2>Restore Backup</h2></div>
            <div class="card-body">
                <p class="text-danger">Restore replaces all current database records and private uploaded files. Use an archive from a schema-compatible version of this system.</p>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="mb-3">
                        <label class="form-label" for="backup_file">Backup ZIP (maximum 100 MB)</label>
                        <input class="form-control" type="file" id="backup_file" name="backup_file" accept=".zip,application/zip" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="confirmation">Type RESTORE to confirm replacement</label>
                        <input class="form-control" type="text" id="confirmation" name="confirmation" autocomplete="off" required>
                    </div>
                    <button class="btn btn-danger" type="submit" <?php echo $zipAvailable ? '' : 'disabled'; ?>>Restore Backup</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
