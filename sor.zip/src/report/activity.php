<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');

$eventFilter = trim((string) ($_GET['event_type'] ?? ''));
$eventFilter = mb_substr($eventFilter, 0, 64);
$userFilter = filter_var($_GET['user_id'] ?? 0, FILTER_VALIDATE_INT);
$userFilter = $userFilter !== false && $userFilter > 0 ? $userFilter : 0;
$fromDate = trim((string) ($_GET['from'] ?? ''));
$toDate = trim((string) ($_GET['to'] ?? ''));
$exportCsv = ($_GET['export'] ?? '') === 'csv';
$errors = [];
$activityLogError = '';

foreach (['from' => &$fromDate, 'to' => &$toDate] as $label => &$date) {
    if ($date === '') {
        continue;
    }

    $parsedDate = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    if (!$parsedDate || $parsedDate->format('Y-m-d') !== $date) {
        $errors[] = 'Enter dates using the YYYY-MM-DD format.';
        $date = '';
    }
}
unset($date, $label);

if ($fromDate !== '' && $toDate !== '' && $fromDate > $toDate) {
    $errors[] = 'The start date must be on or before the end date.';
}

$conditions = [];
$params = [];
if ($eventFilter !== '') {
    $conditions[] = 'l.event_type = :event_type';
    $params['event_type'] = $eventFilter;
}
if ($userFilter > 0) {
    $conditions[] = 'l.user_id = :user_id';
    $params['user_id'] = $userFilter;
}
if ($fromDate !== '') {
    $conditions[] = 'l.created_at >= :from_date';
    $params['from_date'] = $fromDate . ' 00:00:00';
}
if ($toDate !== '') {
    $conditions[] = 'l.created_at < :to_date';
    $params['to_date'] = (new DateTimeImmutable($toDate))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';
}
$whereSql = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
if ($errors) {
    $whereSql = 'WHERE 1 = 0';
}
$limit = $exportCsv ? 10000 : 250;

try {
    $logs = Database::query(
        "SELECT l.id, l.event_type, l.ip_address, l.device_type, l.operating_system,
                l.browser, l.referrer, l.metadata, l.created_at,
                u.full_name, u.username
         FROM activity_logs l
         LEFT JOIN users u ON u.id = l.user_id
         $whereSql
         ORDER BY l.created_at DESC, l.id DESC
         LIMIT $limit",
        $params
    );
    $users = Database::query('SELECT id, username, full_name FROM users ORDER BY full_name, username');
} catch (PDOException $exception) {
    if ((string) $exception->getCode() !== '42S02') {
        throw $exception;
    }
    error_log('Activity log report unavailable because activity_logs is missing: ' . $exception->getMessage());
    $logs = [];
    $users = [];
    $activityLogError = 'Activity logging is not installed yet. Apply the activity_logs migration before using this report.';
}

if ($exportCsv) {
    if ($activityLogError !== '') {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
        exit($activityLogError);
    }
    if ($errors) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=utf-8');
        exit(implode(' ', $errors));
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="activity-log-' . gmdate('Y-m-d') . '.csv"');
    header('Cache-Control: no-store');
    $output = fopen('php://output', 'wb');
    if ($output === false) {
        http_response_code(500);
        exit('Unable to create the CSV export.');
    }
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, ['ID', 'Event', 'User', 'Username', 'Timestamp', 'IP address', 'Device', 'Operating system', 'Browser', 'Referrer', 'Metadata']);
    foreach ($logs as $log) {
        $metadata = is_string($log['metadata']) ? $log['metadata'] : '';
        $values = [
            $log['id'],
            $log['event_type'],
            $log['full_name'] ?? 'Deleted user',
            $log['username'] ?? '',
            $log['created_at'],
            $log['ip_address'],
            $log['device_type'],
            $log['operating_system'],
            trim((string) $log['browser']),
            $log['referrer'],
            $metadata,
        ];
        $values = array_map(static function ($value): string {
            $value = (string) ($value ?? '');
            return preg_match('/^[\s]*[=+\-@]/', $value) ? "'" . $value : $value;
        }, $values);
        fputcsv($output, $values);
    }
    fclose($output);
    exit;
}

$page_title = 'Activity Log';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Activity Log</h1>
        <p class="description">Recent recorded system activity. Showing up to 250 matching events.</p>
    </div>
</div>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-warning"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endforeach; ?>
<?php if ($activityLogError !== ''): ?>
    <div class="alert alert-warning"><?php echo htmlspecialchars($activityLogError, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label" for="event_type">Event type</label>
                <input class="form-control" id="event_type" name="event_type" maxlength="64" value="<?php echo htmlspecialchars($eventFilter, ENT_QUOTES, 'UTF-8'); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label" for="user_id">User</label>
                <select class="form-select" id="user_id" name="user_id">
                    <option value="0">All users</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo (int) $user['id']; ?>" <?php echo $userFilter === (int) $user['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['username'] . ')', ENT_QUOTES, 'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label" for="from">From</label>
                <input class="form-control" type="date" id="from" name="from" value="<?php echo htmlspecialchars($fromDate, ENT_QUOTES, 'UTF-8'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label" for="to">Through</label>
                <input class="form-control" type="date" id="to" name="to" value="<?php echo htmlspecialchars($toDate, ENT_QUOTES, 'UTF-8'); ?>">
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button class="btn btn-primary" type="submit">Filter</button>
                <a class="btn btn-outline-secondary" href="activity.php">Reset</a>
            </div>
            <div class="col-12">
                <button class="btn btn-outline-primary" type="submit" name="export" value="csv">Export CSV</button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-body">
        <?php if (!$logs): ?>
            <p class="text-muted mb-0">No activity events match the selected filters.</p>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Event</th>
                            <th>User</th>
                            <th>Device</th>
                            <th>IP address</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><?php echo htmlspecialchars((string) $log['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars((string) $log['event_type'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($log['full_name'] ?? 'Deleted user', ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars(trim((string) $log['device_type'] . ' ' . (string) $log['browser']), ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars((string) $log['ip_address'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td>
                                    <details>
                                        <summary>View</summary>
                                        <pre class="mb-0"><?php echo htmlspecialchars((string) ($log['metadata'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></pre>
                                    </details>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
