<?php
/**
 * Reports Overview (admin only)
 *
 * Gives administrators a single view of recruitment activity across all
 * organizations, campaigns, and applications.
 */

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

requireRole('admin');

$userCounts = [
    'admin' => 0,
    'recruiter' => 0,
    'student' => 0,
];

foreach (Database::query("SELECT role, COUNT(*) AS total FROM users GROUP BY role") as $row) {
    if (isset($userCounts[$row['role']])) {
        $userCounts[$row['role']] = (int) $row['total'];
    }
}

$totalUsers = array_sum($userCounts);
$totalOrganizations = (int) Database::value('SELECT COUNT(*) FROM organizations');
$totalCampaigns = (int) Database::value('SELECT COUNT(*) FROM campaigns');
$totalApplications = (int) Database::value('SELECT COUNT(*) FROM applications');
$pendingDecisionCount = (int) Database::value(
    "SELECT COUNT(*) FROM applications WHERE status IN ('applied', 'reviewing', 'shortlisted')"
);
$applicantGenderCounts = [
    'male' => 0,
    'female' => 0,
    'other' => 0,
    'unknown' => 0,
];
foreach (Database::query(
    "SELECT COALESCE(gender, 'unknown') AS gender, COUNT(*) AS total
     FROM applicants
     GROUP BY gender"
) as $row) {
    if (isset($applicantGenderCounts[$row['gender']])) {
        $applicantGenderCounts[$row['gender']] = (int) $row['total'];
    }
}

$applicationStatusCounts = [
    'applied' => 0,
    'reviewing' => 0,
    'shortlisted' => 0,
    'approved' => 0,
    'rejected' => 0,
    'withdrawn' => 0,
];

foreach (Database::query('SELECT status, COUNT(*) AS total FROM applications GROUP BY status') as $row) {
    if (isset($applicationStatusCounts[$row['status']])) {
        $applicationStatusCounts[$row['status']] = (int) $row['total'];
    }
}

$campaignStatusCounts = [
    'draft' => 0,
    'open' => 0,
    'closed' => 0,
    'completed' => 0,
];

foreach (Database::query('SELECT status, COUNT(*) AS total FROM campaigns GROUP BY status') as $row) {
    if (isset($campaignStatusCounts[$row['status']])) {
        $campaignStatusCounts[$row['status']] = (int) $row['total'];
    }
}

$organizationReport = Database::query(
    "SELECT o.id, o.name, o.status,
            COUNT(DISTINCT c.id) AS campaign_count,
            COUNT(a.id) AS application_count,
            COALESCE(SUM(CASE WHEN a.status = 'approved' THEN 1 ELSE 0 END), 0) AS approved_count
     FROM organizations o
     LEFT JOIN campaigns c ON c.organization_id = o.id
     LEFT JOIN applications a ON a.campaign_id = c.id
     GROUP BY o.id, o.name, o.status
     ORDER BY application_count DESC, o.name ASC"
);

$recentApplications = Database::query(
    "SELECT a.id, a.status, a.applied_at,
            app.full_name AS applicant_name,
            c.title AS campaign_title,
            o.name AS organization_name
     FROM applications a
     JOIN applicants app ON a.applicant_id = app.id
     JOIN campaigns c ON a.campaign_id = c.id
     JOIN organizations o ON c.organization_id = o.id
     ORDER BY a.applied_at DESC
     LIMIT 10"
);

$page_title = 'Reports';
ob_start();
?>
<div class="page-header">
    <div>
        <h1>Reports</h1>
        <p class="description">Recruitment activity across the whole system</p>
    </div>
    <div class="d-flex gap-2 flex-wrap no-print">
        <button type="button" class="btn btn-outline-secondary" onclick="window.print()">Print Report</button>
        <a href="analytics.php" class="btn btn-primary">Analytics Dashboard</a>
        <a href="logins.php" class="btn btn-outline-secondary">Login Activity</a>
        <a href="activity.php" class="btn btn-outline-secondary">Activity Log</a>
        <a href="export.php" class="btn btn-outline-primary">Export Applications (CSV)</a>
        <a href="backup.php" class="btn btn-outline-secondary">Backup and Restore</a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header">
        <h3>Decision Support</h3>
    </div>
    <div class="card-body">
        <ul class="mb-0">
            <?php if ($campaignStatusCounts['open'] === 0): ?>
                <li>No campaigns are currently open. Review the recruitment calendar and publish campaigns when ready.</li>
            <?php endif; ?>
            <?php if ($pendingDecisionCount > 0): ?>
                <li><?php echo $pendingDecisionCount; ?> applications are awaiting a decision. Review the queue and update applicant statuses.</li>
            <?php else: ?>
                <li>No applications are currently awaiting a decision.</li>
            <?php endif; ?>
            <?php if ($totalApplications === 0): ?>
                <li>No applications have been recorded yet. Confirm that at least one campaign is open and visible to students.</li>
            <?php endif; ?>
            <?php if ($totalApplications > 0): ?>
                <li>
                    <?php echo number_format(($applicationStatusCounts['approved'] / $totalApplications) * 100, 1); ?>%
                    of recorded applications are approved. Use this as a review metric, not as an automatic selection rule.
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<div class="dashboard-grid">
    <div class="stat-card">
        <div class="number"><?php echo $totalUsers; ?></div>
        <div class="label">Registered Users</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo $totalOrganizations; ?></div>
        <div class="label">Organizations</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo $totalCampaigns; ?></div>
        <div class="label">Campaigns</div>
    </div>
    <div class="stat-card">
        <div class="number"><?php echo $totalApplications; ?></div>
        <div class="label">Applications</div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header">
                <h3>Applications by Status</h3>
            </div>
            <div class="card-body">
                <div class="table-wrapper">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th class="text-end">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($applicationStatusCounts as $status => $count): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-<?php echo applicationStatusColor($status); ?>">
                                        <?php echo applicationStatusLabel($status); ?>
                                    </span>
                                </td>
                                <td class="text-end"><?php echo $count; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header">
                <h3>Campaigns by Status</h3>
            </div>
            <div class="card-body">
                <div class="table-wrapper">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th class="text-end">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($campaignStatusCounts as $status => $count): ?>
                            <tr>
                                <td><?php echo campaignStatusLabel($status); ?></td>
                                <td class="text-end"><?php echo $count; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <p class="text-muted small mb-0 mt-3">
                    Admins: <?php echo $userCounts['admin']; ?>,
                    Recruiters: <?php echo $userCounts['recruiter']; ?>,
                    Students: <?php echo $userCounts['student']; ?>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-2">
    <div class="card-header">
        <h3>Organization Activity</h3>
    </div>
    <div class="card-body">
        <?php if (empty($organizationReport)): ?>
            <p class="text-muted mb-0">No organizations have been created yet.</p>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Organization</th>
                            <th>Status</th>
                            <th class="text-end">Campaigns</th>
                            <th class="text-end">Applications</th>
                            <th class="text-end">Approved</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($organizationReport as $index => $org): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo htmlspecialchars($org['name']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $org['status'] === 'active' ? 'success' : ($org['status'] === 'pending' ? 'warning' : 'secondary'); ?>">
                                    <?php echo strtoupper($org['status']); ?>
                                </span>
                            </td>
                            <td class="text-end"><?php echo (int) $org['campaign_count']; ?></td>
                            <td class="text-end"><?php echo (int) $org['application_count']; ?></td>
                            <td class="text-end"><?php echo (int) $org['approved_count']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3>Applicant Gender Distribution</h3>
    </div>
    <div class="card-body">
        <p class="text-muted">Counts are based on applicant profiles; blank gender values are shown as Unknown.</p>
        <div class="table-wrapper">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Gender</th>
                        <th class="text-end">Applicants</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applicantGenderCounts as $gender => $count): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(ucfirst($gender)); ?></td>
                        <td class="text-end"><?php echo $count; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3>Recent Applications</h3>
    </div>
    <div class="card-body">
        <?php if (empty($recentApplications)): ?>
            <p class="text-muted mb-0">No applications have been submitted yet.</p>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Applicant</th>
                            <th>Campaign</th>
                            <th>Organization</th>
                            <th>Status</th>
                            <th>Applied</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentApplications as $application): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($application['applicant_name']); ?></td>
                            <td><?php echo htmlspecialchars($application['campaign_title']); ?></td>
                            <td><?php echo htmlspecialchars($application['organization_name']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo applicationStatusColor($application['status']); ?>">
                                    <?php echo applicationStatusLabel($application['status']); ?>
                                </span>
                            </td>
                            <td><?php echo formatDateTime($application['applied_at']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../../templates/layout.php';
