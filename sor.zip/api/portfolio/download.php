<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

startSession();

function respondWithJson(int $status, array $response): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($response, JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    exit('Method not allowed.');
}

$portfolioPath = __DIR__ . '/../../public/docs/portfolio.pdf';
if (!is_file($portfolioPath)) {
    respondWithJson(404, ['success' => false, 'message' => 'File not found']);
}

$portfolioFile = fopen($portfolioPath, 'rb');
if ($portfolioFile === false) {
    respondWithJson(500, ['success' => false, 'message' => 'Unable to download file']);
}

if (!consumeRateLimit('portfolio_download', 'PORTFOLIO_PDF_DOWNLOAD', 10, 100, 3600)) {
    fclose($portfolioFile);
    http_response_code(429);
    exit('Download limit reached. Please try again later.');
}

$downloadToken = $_GET['tracking_token'] ?? '';
$downloadTokens = $_SESSION['portfolio_download_tokens'] ?? [];
$trackedAt = is_string($downloadToken)
    && preg_match('/^[a-f0-9]{48}$/', $downloadToken)
    && is_array($downloadTokens)
    ? ($downloadTokens[$downloadToken] ?? 0)
    : 0;
if (is_array($downloadTokens) && is_string($downloadToken)) {
    unset($downloadTokens[$downloadToken]);
    $_SESSION['portfolio_download_tokens'] = $downloadTokens;
}

if (
    (!is_int($trackedAt) || $trackedAt < time() - 120)
    && !logActivity('PORTFOLIO_PDF_DOWNLOAD', ['source' => 'download_endpoint'], getUserId())
) {
    fclose($portfolioFile);
    http_response_code(503);
    exit('The portfolio is temporarily unavailable. Please try again later.');
}

header('Content-Type: application/pdf');
$viewPortfolio = isset($_GET['view']) && $_GET['view'] === '1';
header('Content-Disposition: ' . ($viewPortfolio ? 'inline' : 'attachment') . '; filename="portfolio.pdf"');
header('Content-Length: ' . filesize($portfolioPath));
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
fpassthru($portfolioFile);
fclose($portfolioFile);
